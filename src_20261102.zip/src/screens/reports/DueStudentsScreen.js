import React, {useCallback, useState} from 'react';
import {
  ActivityIndicator, FlatList, Pressable, RefreshControl,
  StyleSheet, Text, View,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import api from '../../api/api';
import {COLORS} from '../../constants/colors';

const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;

const DueStudentsScreen = ({navigation}) => {
  const [dues, setDues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadDues = async () => {
    try {
      const res = await api.get('/api/reports/due-students');
      if (res.data?.status?.code === 200) {
        setDues(res.data.data || []);
      }
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadDues();
    }, []),
  );

  const renderItem = ({item}) => (
    <Pressable 
      style={styles.card}
      onPress={() => navigation.navigate('StudentDetails', { studentId: item.student_id })}
    >
      <View style={styles.row}>
        <View>
          <Text style={styles.name}>{item.full_name}</Text>
          <Text style={styles.meta}>{item.student_code} • {item.plan_name}</Text>
        </View>
        <Text style={styles.amount}>{formatMoney(item.due_amount)}</Text>
      </View>
      <View style={styles.dateRow}>
        <Text style={styles.dateText}>Start: {item.start_date}</Text>
        <Text style={styles.dateText}>Due Since: {item.start_date}</Text>
      </View>
    </Pressable>
  );

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ Back</Text>
        </Pressable>
        <Text style={styles.title}>Due Students</Text>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{marginTop: 40}} />
      ) : (
        <FlatList
          data={dues}
          keyExtractor={item => String(item.membership_id)}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadDues(); }} />}
          ListEmptyComponent={<Text style={styles.empty}>No pending dues! Everyone is up to date.</Text>}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  header: { padding: 20, paddingTop: 20 },
  back: { color: COLORS.primary, fontSize: 15, fontWeight: '700', marginBottom: 10 },
  title: { fontSize: 28, fontWeight: '800', color: COLORS.text },
  list: { padding: 20, paddingTop: 0 },
  card: { backgroundColor: COLORS.white, padding: 14, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, marginBottom: 10 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  name: { fontSize: 15, fontWeight: '800', color: COLORS.text },
  meta: { fontSize: 12, color: COLORS.textSecondary, marginTop: 3 },
  amount: { fontSize: 18, fontWeight: '900', color: COLORS.danger },
  dateRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#F1F1F1' },
  dateText: { fontSize: 11, color: COLORS.textSecondary, fontWeight: '600' },
  empty: { textAlign: 'center', color: COLORS.textSecondary, marginTop: 40 },
});

export default DueStudentsScreen;