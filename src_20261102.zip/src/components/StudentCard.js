import React from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import {COLORS} from '../constants/colors';
import StatusBadge from './StatusBadge';

const StudentCard = ({
  student,
  onPress,
}) => {
  const name = student?.full_name || 'Unknown Student';

  const initial = name
    .trim()
    .charAt(0)
    .toUpperCase();

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      style={styles.card}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>{initial}</Text>
      </View>

      <View style={styles.info}>
        <View style={styles.nameRow}>
          <Text
            style={styles.name}
            numberOfLines={1}>
            {name}
          </Text>
        </View>

        <Text style={styles.code}>
          {student?.student_code || 'No code'}
        </Text>

        <View style={styles.metaRow}>
          <Text style={styles.meta}>
            {student?.mobile || '-'}
          </Text>

          <View style={styles.dotSeparator} />

          <Text style={styles.meta}>
            {student?.gender || '-'}
          </Text>
        </View>
      </View>

      <View style={styles.right}>
        <StatusBadge status={student?.status || 'ACTIVE'} />

        <Text style={styles.arrow}>›</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 17,
    padding: 13,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 15,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: '900',
  },
  info: {
    flex: 1,
    marginLeft: 12,
    minWidth: 0,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  name: {
    flex: 1,
    color: COLORS.text,
    fontSize: 14,
    fontWeight: '800',
  },
  code: {
    color: COLORS.primary,
    fontSize: 10,
    fontWeight: '800',
    marginTop: 3,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  meta: {
    color: COLORS.textSecondary,
    fontSize: 10,
  },
  dotSeparator: {
    width: 3,
    height: 3,
    borderRadius: 2,
    backgroundColor: COLORS.textLight,
    marginHorizontal: 6,
  },
  right: {
    alignItems: 'flex-end',
    marginLeft: 8,
  },
  arrow: {
    color: COLORS.textLight,
    fontSize: 23,
    marginTop: 5,
  },
});

export default StudentCard;