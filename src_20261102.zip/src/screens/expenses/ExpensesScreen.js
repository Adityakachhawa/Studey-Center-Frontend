// import React from 'react';
// import {
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// const ExpensesScreen = () => {
//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>
//         Expenses
//       </Text>

//       <Text style={styles.subtitle}>
//         Track study center expenses.
//       </Text>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#F7F8FA',
//     padding: 20,
//     paddingTop: 30,
//   },

//   title: {
//     fontSize: 28,
//     fontWeight: '800',
//     color: '#111827',
//   },

//   subtitle: {
//     color: '#6B7280',
//     marginTop: 6,
//   },
// });

// export default ExpensesScreen;
import React, {useCallback, useState} from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';

import { getExpensesApi } from '../../api/expenses';
import { COLORS } from '../../constants/colors';

const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;
const formatDate = value => {
  if (!value) return '—';
  return String(value).slice(0, 10);
};

const ExpensesScreen = ({navigation}) => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadExpenses = useCallback(async (showLoader = false) => {
    if (showLoader) setLoading(true);
    try {
      const response = await getExpensesApi();
      if (response?.status?.code === 200) {
        setExpenses(response.data || []);
      }
    } catch (error) {
      console.log('Expenses error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadExpenses(expenses.length === 0);
    }, [loadExpenses]),
  );

  const renderExpense = ({item}) => (
    <Pressable 
      style={styles.card}
      onPress={() => navigation.navigate('AddExpense', { expense: item })} // 👈 Navigate with data
    >
      <View style={styles.topRow}>
        <View>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.meta}>{item.category} • {formatDate(item.expense_date)}</Text>
        </View>
        <Text style={styles.amount}>{formatMoney(item.amount)}</Text>
      </View>
      <Text style={styles.method}>{item.method_name || 'CASH'}</Text>
    </Pressable>
  );

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View>
          <Text style={styles.pageTitle}>Expenses</Text>
          <Text style={styles.subtitle}>Manage your library expenses</Text>
        </View>
        <Pressable style={styles.addBtn} onPress={() => navigation.navigate('AddExpense')}>
          <Text style={styles.addBtnText}>+</Text>
        </Pressable>
      </View>

      {loading ? (
        <View style={styles.loader}><ActivityIndicator size="large" color={COLORS.primary} /></View>
      ) : (
        <FlatList
          data={expenses}
          keyExtractor={item => String(item.id)}
          renderItem={renderExpense}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadExpenses(); }} />}
          ListEmptyComponent={<Text style={styles.empty}>No expenses recorded yet.</Text>}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  header: {padding: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'},
  pageTitle: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
  addBtn: {width: 46, height: 46, borderRadius: 14, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center'},
  addBtnText: {color: COLORS.white, fontSize: 28, lineHeight: 30},
  list: {padding: 20, paddingTop: 0},
  card: {backgroundColor: COLORS.white, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border, padding: 14, marginBottom: 10},
  topRow: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start'},
  title: {fontSize: 15, fontWeight: '800', color: COLORS.text},
  meta: {fontSize: 11, color: COLORS.textSecondary, marginTop: 3},
  amount: {fontSize: 16, fontWeight: '900', color: COLORS.danger},
  method: {fontSize: 11, color: COLORS.textLight, marginTop: 8, fontWeight: '600'},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  empty: {textAlign: 'center', color: COLORS.textSecondary, marginTop: 40},
});

export default ExpensesScreen;
// import React, {
//   useCallback,
//   useState,
// } from 'react';

// import {
//   ActivityIndicator,
//   FlatList,
//   Pressable,
//   RefreshControl,
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {getExpensesApi} from '../../api/expenses';

// import {COLORS} from '../../constants/colors';

// const ExpensesScreen = ({
//   navigation,
// }) => {
//   const [expenses, setExpenses] =
//     useState([]);

//   const [loading, setLoading] =
//     useState(true);

//   const [refreshing, setRefreshing] =
//     useState(false);

//   const loadExpenses = async () => {
//     try {
//       const response =
//         await getExpensesApi();

//       if (
//         response?.status?.code === 200
//       ) {
//         setExpenses(
//           response.data || [],
//         );
//       }
//     } catch (error) {
//       console.log(
//         'Expenses error:',
//         error,
//       );
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
//   };

//   useFocusEffect(
//     useCallback(() => {
//       loadExpenses();
//     }, []),
//   );

//   const renderExpense = ({
//     item,
//   }) => {
//     return (
//       <View style={styles.card}>
//         <View style={styles.icon}>
//           <Text style={styles.iconText}>
//             ₹
//           </Text>
//         </View>

//         <View style={styles.info}>
//           <Text style={styles.titleText}>
//             {item.title}
//           </Text>

//           <Text style={styles.category}>
//             {item.category}
//           </Text>

//           <Text style={styles.details}>
//             {item.expense_number}
//             {item.method_name
//               ? ` • ${item.method_name}`
//               : ''}
//           </Text>

//           <Text style={styles.date}>
//             {item.expense_date}
//           </Text>
//         </View>

//         <Text style={styles.amount}>
//           ₹
//           {Number(
//             item.amount || 0,
//           ).toLocaleString('en-IN')}
//         </Text>
//       </View>
//     );
//   };

//   return (
//     <View style={styles.screen}>
//       <View style={styles.header}>
//         <View>
//           <Text style={styles.title}>
//             Expenses
//           </Text>

//           <Text style={styles.subtitle}>
//             Track study center expenses
//           </Text>
//         </View>

//         <Pressable
//           style={styles.addButton}
//           onPress={() =>
//             navigation.navigate(
//               'AddExpense',
//             )
//           }>
//           <Text style={styles.addText}>
//             +
//           </Text>
//         </Pressable>
//       </View>

//       {loading ? (
//         <View style={styles.loader}>
//           <ActivityIndicator
//             size="large"
//             color={COLORS.primary}
//           />
//         </View>
//       ) : (
//         <FlatList
//           data={expenses}
//           keyExtractor={item =>
//             String(item.id)
//           }
//           renderItem={
//             renderExpense
//           }
//           contentContainerStyle={
//             styles.list
//           }
//           refreshControl={
//             <RefreshControl
//               refreshing={
//                 refreshing
//               }
//               onRefresh={() => {
//                 setRefreshing(
//                   true,
//                 );
//                 loadExpenses();
//               }}
//             />
//           }
//           ListEmptyComponent={
//             <View
//               style={
//                 styles.empty
//               }>
//               <Text
//                 style={
//                   styles.emptyTitle
//                 }>
//                 No expenses yet
//               </Text>

//               <Text
//                 style={
//                   styles.emptyText
//                 }>
//                 Add your first expense.
//               </Text>
//             </View>
//           }
//         />
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   screen: {
//     flex: 1,
//     backgroundColor:
//       COLORS.background,
//   },

//   header: {
//     paddingHorizontal: 20,
//     paddingTop: 20,
//     paddingBottom: 16,
//     flexDirection: 'row',
//     justifyContent:
//       'space-between',
//     alignItems: 'center',
//   },

//   title: {
//     fontSize: 28,
//     fontWeight: '800',
//     color: COLORS.text,
//   },

//   subtitle: {
//     color: COLORS.textSecondary,
//     fontSize: 13,
//     marginTop: 4,
//   },

//   addButton: {
//     width: 46,
//     height: 46,
//     borderRadius: 14,
//     backgroundColor:
//       COLORS.primary,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },

//   addText: {
//     color: COLORS.white,
//     fontSize: 28,
//     lineHeight: 30,
//   },

//   list: {
//     padding: 20,
//     paddingTop: 4,
//     paddingBottom: 40,
//   },

//   card: {
//     backgroundColor: COLORS.white,
//     borderRadius: 17,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     padding: 14,
//     marginBottom: 10,
//     flexDirection: 'row',
//     alignItems: 'center',
//   },

//   icon: {
//     width: 46,
//     height: 46,
//     borderRadius: 14,
//     backgroundColor:
//       COLORS.dangerBg,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },

//   iconText: {
//     color: COLORS.danger,
//     fontSize: 19,
//     fontWeight: '800',
//   },

//   info: {
//     flex: 1,
//     marginLeft: 12,
//   },

//   titleText: {
//     color: COLORS.text,
//     fontSize: 14,
//     fontWeight: '800',
//   },

//   category: {
//     color: COLORS.primary,
//     fontSize: 11,
//     fontWeight: '700',
//     marginTop: 3,
//   },

//   details: {
//     color: COLORS.textSecondary,
//     fontSize: 11,
//     marginTop: 4,
//   },

//   date: {
//     color: COLORS.textLight,
//     fontSize: 10,
//     marginTop: 3,
//   },

//   amount: {
//     color: COLORS.danger,
//     fontSize: 15,
//     fontWeight: '800',
//     marginLeft: 8,
//   },

//   loader: {
//     flex: 1,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },

//   empty: {
//     alignItems: 'center',
//     paddingTop: 100,
//   },

//   emptyTitle: {
//     color: COLORS.text,
//     fontSize: 18,
//     fontWeight: '800',
//   },

//   emptyText: {
//     color: COLORS.textSecondary,
//     marginTop: 6,
//   },
// });

// export default ExpensesScreen;