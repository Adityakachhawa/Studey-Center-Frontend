// import React, {
//   useCallback,
//   useState,
// } from 'react';

// import {
//   RefreshControl,
//   ScrollView,
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {getDashboardApi} from '../../api/dashboard';

// import {COLORS} from '../../constants/colors';

// const StatCard = ({
//   title,
//   value,
//   subtitle,
//   accent,
// }) => {
//   return (
//     <View style={styles.statCard}>
//       <View
//         style={[
//           styles.statDot,
//           {backgroundColor: accent},
//         ]}
//       />

//       <Text style={styles.statTitle}>
//         {title}
//       </Text>

//       <Text style={styles.statValue}>
//         {value}
//       </Text>

//       {subtitle ? (
//         <Text style={styles.statSubtitle}>
//           {subtitle}
//         </Text>
//       ) : null}
//     </View>
//   );
// };

// const DashboardScreen = ({
//   navigation,
// }) => {
//   const [dashboard, setDashboard] =
//     useState(null);

//   const [refreshing, setRefreshing] =
//     useState(false);

//   const loadDashboard = async () => {
//     try {
//       const response =
//         await getDashboardApi();

//       if (
//         response?.status?.code === 200
//       ) {
//         setDashboard(
//           response.data,
//         );
//       }
//     } catch (error) {
//       console.log(
//         'Dashboard error:',
//         error,
//       );
//     }
//   };

//   useFocusEffect(
//     useCallback(() => {
//       loadDashboard();
//     }, []),
//   );

//   const refresh = async () => {
//     setRefreshing(true);

//     await loadDashboard();

//     setRefreshing(false);
//   };

//   const data = dashboard || {};

//   return (
//     <ScrollView
//       style={styles.screen}
//       contentContainerStyle={
//         styles.content
//       }
//       refreshControl={
//         <RefreshControl
//           refreshing={refreshing}
//           onRefresh={refresh}
//         />
//       }>
//       <View style={styles.header}>
//         <View>
//           <Text style={styles.eyebrow}>
//             OVERVIEW
//           </Text>

//           <Text style={styles.title}>
//             Dashboard
//           </Text>
//         </View>

//         <View style={styles.avatar}>
//           <Text style={styles.avatarText}>
//             SC
//           </Text>
//         </View>
//       </View>

//       <View style={styles.hero}>
//         <Text style={styles.heroLabel}>
//           THIS MONTH
//         </Text>

//         <Text style={styles.heroAmount}>
//           ₹
//           {Number(
//             data.month_collection || 0,
//           ).toLocaleString('en-IN')}
//         </Text>

//         <Text style={styles.heroSub}>
//           Total fee collection
//         </Text>
//       </View>

//       <View style={styles.grid}>
//         <StatCard
//           title="Students"
//           value={
//             data.students || 0
//           }
//           subtitle="Active students"
//           accent={COLORS.primary}
//         />

//         <StatCard
//           title="Available"
//           value={
//             data.seats?.available ||
//             0
//           }
//           subtitle={`of ${
//             data.seats?.total || 0
//           } seats`}
//           accent={COLORS.success}
//         />

//         <StatCard
//           title="Occupied"
//           value={
//             data.seats?.occupied ||
//             0
//           }
//           subtitle="Currently occupied"
//           accent={COLORS.purple}
//         />

//         <StatCard
//           title="Due"
//           value={`₹${Number(
//             data.total_due || 0,
//           ).toLocaleString('en-IN')}`}
//           subtitle="Pending fees"
//           accent={COLORS.warning}
//         />
//       </View>

//       <View style={styles.section}>
//         <Text style={styles.sectionTitle}>
//           Financial snapshot
//         </Text>

//         <View style={styles.financialCard}>
//           <View>
//             <Text
//               style={
//                 styles.financialLabel
//               }>
//               Today's collection
//             </Text>

//             <Text
//               style={
//                 styles.financialValue
//               }>
//               ₹
//               {Number(
//                 data.today_collection ||
//                   0,
//               ).toLocaleString(
//                 'en-IN',
//               )}
//             </Text>
//           </View>

//           <View style={styles.divider} />

//           <View>
//             <Text
//               style={
//                 styles.financialLabel
//               }>
//               Monthly expense
//             </Text>

//             <Text
//               style={
//                 styles.financialValue
//               }>
//               ₹
//               {Number(
//                 data.month_expense ||
//                   0,
//               ).toLocaleString(
//                 'en-IN',
//               )}
//             </Text>
//           </View>
//         </View>
//       </View>

//       <View style={styles.section}>
//         <Text style={styles.sectionTitle}>
//           Quick actions
//         </Text>

//         <View style={styles.actions}>
//           <ActionButton
//             title="Students"
//             onPress={() =>
//               navigation.navigate(
//                 'Students',
//               )
//             }
//           />

//           <ActionButton
//             title="Seats"
//             onPress={() =>
//               navigation.navigate(
//                 'Seats',
//               )
//             }
//           />

//           <ActionButton
//             title="Payments"
//             onPress={() =>
//               navigation.navigate(
//                 'Payments',
//               )
//             }
//           />

//           <ActionButton
//             title="Expenses"
//             onPress={() =>
//               navigation.navigate(
//                 'Expenses',
//               )
//             }
//           />
//         </View>
//       </View>
//     </ScrollView>
//   );
// };

// const ActionButton = ({
//   title,
//   onPress,
// }) => (
//   <View
//     style={styles.actionWrapper}>
//     <Text
//       onPress={onPress}
//       style={styles.actionButton}>
//       {title}
//     </Text>
//   </View>
// );

// const styles = StyleSheet.create({
//   screen: {
//     flex: 1,
//     backgroundColor: COLORS.background,
//   },

//   content: {
//     padding: 20,
//     paddingBottom: 40,
//   },

//   header: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     marginBottom: 22,
//   },

//   eyebrow: {
//     fontSize: 11,
//     fontWeight: '800',
//     letterSpacing: 1.5,
//     color: COLORS.primary,
//     marginBottom: 4,
//   },

//   title: {
//     fontSize: 28,
//     fontWeight: '800',
//     color: COLORS.text,
//   },

//   avatar: {
//     width: 46,
//     height: 46,
//     borderRadius: 15,
//     backgroundColor: COLORS.primary,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },

//   avatarText: {
//     color: COLORS.white,
//     fontWeight: '800',
//     fontSize: 13,
//   },

//   hero: {
//     backgroundColor: COLORS.primary,
//     borderRadius: 22,
//     padding: 24,
//     marginBottom: 18,
//   },

//   heroLabel: {
//     color: '#DBEAFE',
//     fontSize: 11,
//     fontWeight: '800',
//     letterSpacing: 1.2,
//   },

//   heroAmount: {
//     color: COLORS.white,
//     fontSize: 36,
//     fontWeight: '800',
//     marginTop: 8,
//   },

//   heroSub: {
//     color: '#DBEAFE',
//     fontSize: 13,
//     marginTop: 5,
//   },

//   grid: {
//     flexDirection: 'row',
//     flexWrap: 'wrap',
//     gap: 12,
//   },

//   statCard: {
//     width: '48%',
//     backgroundColor: COLORS.white,
//     borderRadius: 18,
//     padding: 16,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//   },

//   statDot: {
//     width: 8,
//     height: 8,
//     borderRadius: 4,
//     marginBottom: 13,
//   },

//   statTitle: {
//     color: COLORS.textSecondary,
//     fontSize: 13,
//     fontWeight: '600',
//   },

//   statValue: {
//     color: COLORS.text,
//     fontSize: 25,
//     fontWeight: '800',
//     marginTop: 5,
//   },

//   statSubtitle: {
//     color: COLORS.textLight,
//     fontSize: 11,
//     marginTop: 5,
//   },

//   section: {
//     marginTop: 28,
//   },

//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: COLORS.text,
//     marginBottom: 13,
//   },

//   financialCard: {
//     backgroundColor: COLORS.white,
//     borderRadius: 18,
//     padding: 18,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//   },

//   financialLabel: {
//     color: COLORS.textSecondary,
//     fontSize: 12,
//   },

//   financialValue: {
//     color: COLORS.text,
//     fontSize: 20,
//     fontWeight: '800',
//     marginTop: 5,
//   },

//   divider: {
//     width: 1,
//     backgroundColor: COLORS.border,
//   },

//   actions: {
//     flexDirection: 'row',
//     flexWrap: 'wrap',
//     gap: 10,
//   },

//   actionWrapper: {
//     width: '48%',
//   },

//   actionButton: {
//     backgroundColor: COLORS.white,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     borderRadius: 14,
//     padding: 17,
//     textAlign: 'center',
//     color: COLORS.text,
//     fontWeight: '700',
//   },
// });

// export default DashboardScreen;
import React, {useCallback, useState} from 'react';
import {
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import api from '../../api/api';
import {getDashboardApi} from '../../api/dashboard';
import {COLORS} from '../../constants/colors';

const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;

const StatCard = ({title, value, subtitle, accent, onPress}) => {
  const Wrap = onPress ? Pressable : View;
  return (
    <Wrap style={styles.statCard} {...(onPress ? {onPress} : {})}>
      <View style={[styles.statDot, {backgroundColor: accent}]} />
      <Text style={styles.statTitle}>{title}</Text>
      <Text style={styles.statValue}>{value}</Text>
      {subtitle ? <Text style={styles.statSubtitle}>{subtitle}</Text> : null}
    </Wrap>
  );
};

const DashboardScreen = ({navigation}) => {
  const [dashboard, setDashboard] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      api.post('/api/maintenance/expire-memberships').catch(() => {});
      const response = await getDashboardApi();
      if (response?.status?.code === 200) {
        setDashboard(response.data);
      }
    } catch (error) {
      console.log('Dashboard error:', error);
    }
  };

  useFocusEffect(useCallback(() => { load(); }, []));

  const refresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const data = dashboard || {};
  const profit = Number(data.month_profit || 0);
  const profitPositive = profit >= 0;

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}>
      
      <View style={styles.header}>
        <View>
          <Text style={styles.eyebrow}>GYAN GANGA LIBRARY</Text>
          <Text style={styles.title}>Dashboard</Text>
        </View>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>GG</Text>
        </View>
      </View>

      <View style={styles.hero}>
        <Text style={styles.heroLabel}>THIS MONTH • COLLECTION</Text>
        <Text style={styles.heroAmount}>{formatMoney(data.month_collection)}</Text>
        <View style={styles.heroRow}>
          <Text style={styles.heroSub}>Expense {formatMoney(data.month_expense)}</Text>
          <View style={styles.heroDivider} />
          <Text style={[styles.heroSub, {color: profitPositive ? '#BBF7D0' : '#FECACA'}]}>
            {profitPositive ? 'Profit' : 'Loss'} {formatMoney(Math.abs(profit))}
          </Text>
        </View>
      </View>

      <View style={styles.grid}>
        <StatCard
          title="Students"
          value={data.students || 0}
          subtitle="Active students"
          accent={COLORS.primary}
          onPress={() => navigation.navigate('Students', {screen: 'StudentsList'})}
        />
        
        {/* 👉 Updated labels for Seats */}
        <StatCard
          title="Free Seats"
          value={data.seats?.available || 0}
          subtitle={`of ${data.seats?.total || 0} total`}
          accent={COLORS.success}
          onPress={() => navigation.navigate('Reports', {screen: 'Seats'})}
        />
        
        <StatCard
          title="Booked Seats"
          value={data.seats?.occupied || 0}
          subtitle="Any slot"
          accent={COLORS.purple}
          onPress={() => navigation.navigate('Reports', {screen: 'Seats'})}
        />

        <StatCard
          title="Total Due"
          value={formatMoney(data.total_due)}
          subtitle="Pending fees"
          accent={COLORS.warning}
        />
        <StatCard
          title="Active Memberships"
          value={data.active_memberships || 0}
          subtitle="Current subscriptions"
          accent={COLORS.primary}
        />
        <StatCard
          title="Today"
          value={formatMoney(data.today_collection)}
          subtitle="Collected today"
          accent={COLORS.success}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Quick actions</Text>
        <View style={styles.actionsGrid}>
          <Pressable style={styles.actionPrimary} onPress={() => navigation.navigate('Students', {screen: 'AddStudent'})}>
            <Text style={styles.actionPrimaryText}>+ Add Student</Text>
          </Pressable>
          <Pressable style={styles.actionPrimary} onPress={() => navigation.navigate('AddMembership')}>
            <Text style={styles.actionPrimaryText}>+ Membership</Text>
          </Pressable>
          <Pressable style={styles.actionSecondary} onPress={() => navigation.navigate('Payments', {screen: 'AddPayment'})}>
            <Text style={styles.actionSecondaryText}>+ Payment</Text>
          </Pressable>
          <Pressable style={styles.actionSecondary} onPress={() => navigation.navigate('Expenses', {screen: 'AddExpense'})}>
            <Text style={styles.actionSecondaryText}>+ Expense</Text>
          </Pressable>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Explore</Text>
        <View style={styles.shortcutRow}>
          <Pressable style={styles.shortcut} onPress={() => navigation.navigate('Memberships')}>
            <Text style={styles.shortcutTitle}>Memberships</Text>
            <Text style={styles.shortcutSub}>All plans</Text>
          </Pressable>
          <Pressable style={styles.shortcut} onPress={() => navigation.navigate('Receipts')}>
            <Text style={styles.shortcutTitle}>Receipts</Text>
            <Text style={styles.shortcutSub}>WhatsApp share</Text>
          </Pressable>
          <Pressable style={styles.shortcut} onPress={() => navigation.navigate('Reports', {screen: 'FeePlans'})}>
            <Text style={styles.shortcutTitle}>Fee Plans</Text>
            <Text style={styles.shortcutSub}>Pricing</Text>
          </Pressable>
          <Pressable style={styles.shortcut} onPress={() => navigation.navigate('Reports', {screen: 'ReportsHome'})}>
            <Text style={styles.shortcutTitle}>Reports</Text>
            <Text style={styles.shortcutSub}>Monthly</Text>
          </Pressable>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  content: {padding: 20, paddingBottom: 40},
  header: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22},
  eyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.4, color: COLORS.primary, marginBottom: 4},
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  avatar: {width: 46, height: 46, borderRadius: 15, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center'},
  avatarText: {color: COLORS.white, fontWeight: '800', fontSize: 13},
  hero: {backgroundColor: COLORS.primary, borderRadius: 22, padding: 22, marginBottom: 16},
  heroLabel: {color: '#DBEAFE', fontSize: 10, fontWeight: '800', letterSpacing: 1.2},
  heroAmount: {color: COLORS.white, fontSize: 34, fontWeight: '900', marginTop: 8},
  heroRow: {flexDirection: 'row', alignItems: 'center', marginTop: 8},
  heroSub: {color: '#DBEAFE', fontSize: 12},
  heroDivider: {width: 1, height: 12, backgroundColor: '#93C5FD', marginHorizontal: 10},
  grid: {flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between'},
  statCard: {width: '48.5%', backgroundColor: COLORS.white, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: COLORS.border, marginBottom: 10, minHeight: 104},
  statDot: {width: 8, height: 8, borderRadius: 4, marginBottom: 10},
  statTitle: {color: COLORS.textSecondary, fontSize: 12, fontWeight: '600'},
  statValue: {color: COLORS.text, fontSize: 22, fontWeight: '900', marginTop: 4},
  statSubtitle: {color: COLORS.textLight, fontSize: 10, marginTop: 4},
  section: {marginTop: 22},
  sectionTitle: {fontSize: 17, fontWeight: '800', color: COLORS.text, marginBottom: 12},
  actionsGrid: {flexDirection: 'row', flexWrap: 'wrap', gap: 10},
  actionPrimary: {width: '48%', height: 52, borderRadius: 14, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center'},
  actionPrimaryText: {color: COLORS.white, fontSize: 13, fontWeight: '800'},
  actionSecondary: {width: '48%', height: 52, borderRadius: 14, backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.primary, alignItems: 'center', justifyContent: 'center'},
  actionSecondaryText: {color: COLORS.primary, fontSize: 13, fontWeight: '800'},
  shortcutRow: {flexDirection: 'row', flexWrap: 'wrap', gap: 10},
  shortcut: {width: '48%', padding: 14, backgroundColor: COLORS.white, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border},
  shortcutTitle: {fontSize: 14, fontWeight: '800', color: COLORS.text},
  shortcutSub: {fontSize: 11, color: COLORS.textSecondary, marginTop: 3},
});

export default DashboardScreen;