// import React from 'react';

// import {
//   createBottomTabNavigator,
// } from '@react-navigation/bottom-tabs';

// import {
//   createNativeStackNavigator,
// } from '@react-navigation/native-stack';

// import DashboardScreen from '../screens/dashboard/DashboardScreen';
// import StudentsScreen from '../screens/students/StudentsScreen';
// import AddStudentScreen from '../screens/students/AddStudentScreen';
// import SeatsScreen from '../screens/seats/SeatsScreen';
// import PaymentsScreen from '../screens/payments/PaymentsScreen';
// import ExpensesScreen from '../screens/expenses/ExpensesScreen';
// import ReportsScreen from '../screens/reports/ReportsScreen';
// import ProfileScreen from '../screens/profile/ProfileScreen';
// import StudentDetailsScreen from '../screens/students/StudentDetailsScreen';
// import AddPaymentScreen from '../screens/payments/AddPaymentScreen';
// import FeePlansScreen from '../screens/fees/FeePlansScreen';
// import AddExpenseScreen from '../screens/expenses/AddExpenseScreen';


// const Tab =
//   createBottomTabNavigator();

// const Stack =
//   createNativeStackNavigator();

// const StudentsStack = () => (
//   <Stack.Navigator
//     screenOptions={{
//       headerShown: false,
//     }}>
//     <Stack.Screen
//       name="StudentsList"
//       component={StudentsScreen}
//     />

//     <Stack.Screen
//       name="AddStudent"
//       component={AddStudentScreen}
//     />

//     <Stack.Screen
//       name="StudentDetails"
//       component={
//         StudentDetailsScreen
//       }
//     />
//     <Stack.Screen
//   name="PaymentsList"
//   component={PaymentsScreen}
//     />
//     <Stack.Screen
//       name="ExpensesList"
//       component={ExpensesScreen}
//     />

//     <Stack.Screen
//       name="AddExpense"
//       component={AddExpenseScreen}
//     />
//     <Stack.Screen
//       name="FeePlans"
//       component={FeePlansScreen}
//     />
//   </Stack.Navigator>
// );

// const MainTabs = () => {
//   return (
//     <Tab.Navigator
//       screenOptions={{
//         headerShown: false,
//         tabBarActiveTintColor:
//           '#2563EB',
//         tabBarInactiveTintColor:
//           '#9CA3AF',

//         tabBarStyle: {
//           height: 70,
//           paddingTop: 8,
//           paddingBottom: 10,
//           borderTopColor:
//             '#E5E7EB',
//         },

//         tabBarLabelStyle: {
//           fontSize: 11,
//           fontWeight: '600',
//         },
//       }}>
//       <Tab.Screen
//         name="Home"
//         component={DashboardScreen}
//         options={{
//           tabBarLabel: 'Home',
//           tabBarIcon: () => '⌂',
//         }}
//       />

//       <Tab.Screen
//         name="Students"
//         component={StudentsStack}
//         options={{
//           tabBarLabel: 'Students',
//           tabBarIcon: () => '●',
//         }}
//       />

//       <Tab.Screen
//         name="Payments"
//         component={PaymentsScreen}
//         options={{
//           tabBarLabel: 'Payments',
//           tabBarIcon: () => '₹',
//         }}
//       />

//       <Tab.Screen
//         name="Expenses"
//         component={ExpensesScreen}
//         options={{
//           tabBarLabel: 'Expenses',
//           tabBarIcon: () => '▣',
//         }}
//       />

//       <Tab.Screen
//         name="More"
//         component={ReportsScreen}
//         options={{
//           tabBarLabel: 'Reports',
//           tabBarIcon: () => '≡',
//         }}
//       />
//     </Tab.Navigator>
//   );
// };

// export default MainTabs;

import React from 'react';

import {
  createBottomTabNavigator,
} from '@react-navigation/bottom-tabs';

import {
  createNativeStackNavigator,
} from '@react-navigation/native-stack';
import {Text} from 'react-native';

import ScreenContainer from '../components/ScreenContainer';

import DashboardScreen from '../screens/dashboard/DashboardScreen';

import StudentsScreen from '../screens/students/StudentsScreen';
import AddStudentScreen from '../screens/students/AddStudentScreen';
import StudentDetailsScreen from '../screens/students/StudentDetailsScreen';

import PaymentsScreen from '../screens/payments/PaymentsScreen';
import AddPaymentScreen from '../screens/payments/AddPaymentScreen';

import ExpensesScreen from '../screens/expenses/ExpensesScreen';
import AddExpenseScreen from '../screens/expenses/AddExpenseScreen';

import ReportsScreen from '../screens/reports/ReportsScreen';
import FeePlansScreen from '../screens/fees/FeePlansScreen';

import MembershipsScreen from '../screens/memberships/MembershipsScreen';
import AddMembershipScreen from '../screens/memberships/AddMembershipScreen';

import ReceiptsScreen from '../screens/receipts/ReceiptsScreen';
import ReceiptDetailsScreen from '../screens/receipts/ReceiptDetailsScreen';

import SeatsScreen from '../screens/seats/SeatsScreen';
import ProfileScreen from '../screens/profile/ProfileScreen';
import DueStudentsScreen from '../screens/reports/DueStudentsScreen';

import {COLORS} from '../constants/colors';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const withSafeArea = Component => props => (
  <ScreenContainer>
    <Component {...props} />
  </ScreenContainer>
);

// ------------------------------------------------------------
// SHARED SCREENS  —  routes that can be reached from multiple tabs
// ------------------------------------------------------------
// These are registered inside EVERY stack that needs them, so
// navigation.navigate('ReceiptDetails', ...) works no matter
// which tab you're on.

const sharedScreens = (StackRef, opts = {}) => (
  <>
    <StackRef.Screen
      name="Memberships"
      component={withSafeArea(MembershipsScreen)}
    />
    <StackRef.Screen
      name="AddMembership"
      component={withSafeArea(AddMembershipScreen)}
    />
    <StackRef.Screen
      name="Receipts"
      component={withSafeArea(ReceiptsScreen)}
    />
    <StackRef.Screen
      name="ReceiptDetails"
      component={withSafeArea(ReceiptDetailsScreen)}
    />
    {opts.withPayments && (
      <StackRef.Screen
        name="AddPayment"
        component={withSafeArea(AddPaymentScreen)}
      />
    )}
    {opts.withExpenses && (
      <StackRef.Screen
        name="AddExpense"
        component={withSafeArea(AddExpenseScreen)}
      />
    )}
  </>
);

// ------------------------------------------------------------
// HOME STACK
// ------------------------------------------------------------
const HomeStack = () => (
  <Stack.Navigator screenOptions={{headerShown: false}}>
    <Stack.Screen
      name="Dashboard"
      component={withSafeArea(DashboardScreen)}
    />

    <Stack.Screen
      name="AddMembership"
      component={withSafeArea(AddMembershipScreen)}
    />
    <Stack.Screen
      name="AddPayment"
      component={withSafeArea(AddPaymentScreen)}
    />
    <Stack.Screen
      name="Memberships"
      component={withSafeArea(MembershipsScreen)}
    />
    <Stack.Screen
      name="Receipts"
      component={withSafeArea(ReceiptsScreen)}
    />
    <Stack.Screen
      name="ReceiptDetails"
      component={withSafeArea(ReceiptDetailsScreen)}
    />
    <Stack.Screen
      name="Seats"
      component={withSafeArea(SeatsScreen)}
    />
  </Stack.Navigator>
);

// ------------------------------------------------------------
// STUDENTS STACK
// ------------------------------------------------------------
const StudentsStack = () => (
  <Stack.Navigator screenOptions={{headerShown: false}}>
    <Stack.Screen
      name="StudentsList"
      component={withSafeArea(StudentsScreen)}
    />
    <Stack.Screen
      name="AddStudent"
      component={withSafeArea(AddStudentScreen)}
    />
    <Stack.Screen
      name="StudentDetails"
      component={withSafeArea(StudentDetailsScreen)}
    />

    <Stack.Screen
      name="AddMembership"
      component={withSafeArea(AddMembershipScreen)}
    />
    <Stack.Screen
      name="Memberships"
      component={withSafeArea(MembershipsScreen)}
    />
    <Stack.Screen
      name="AddPayment"
      component={withSafeArea(AddPaymentScreen)}
    />
    <Stack.Screen
      name="Receipts"
      component={withSafeArea(ReceiptsScreen)}
    />
    <Stack.Screen
      name="ReceiptDetails"
      component={withSafeArea(ReceiptDetailsScreen)}
    />
  </Stack.Navigator>
);

// ------------------------------------------------------------
// PAYMENTS STACK  ← fixes your current bug
// ------------------------------------------------------------
const PaymentsStack = () => (
  <Stack.Navigator screenOptions={{headerShown: false}}>
    <Stack.Screen
      name="PaymentsList"
      component={withSafeArea(PaymentsScreen)}
    />
    <Stack.Screen
      name="AddPayment"
      component={withSafeArea(AddPaymentScreen)}
    />
    <Stack.Screen
      name="Receipts"
      component={withSafeArea(ReceiptsScreen)}
    />
    <Stack.Screen
      name="ReceiptDetails"
      component={withSafeArea(ReceiptDetailsScreen)}
    />
  </Stack.Navigator>
);

// ------------------------------------------------------------
// EXPENSES STACK
// ------------------------------------------------------------
const ExpensesStack = () => (
  <Stack.Navigator screenOptions={{headerShown: false}}>
    <Stack.Screen
      name="ExpensesList"
      component={withSafeArea(ExpensesScreen)}
    />
    <Stack.Screen
      name="AddExpense"
      component={withSafeArea(AddExpenseScreen)}
    />
  </Stack.Navigator>
);

// ------------------------------------------------------------
// REPORTS / MORE STACK
// ------------------------------------------------------------
const ReportsStack = () => (
  <Stack.Navigator screenOptions={{headerShown: false}}>
    <Stack.Screen
      name="ReportsHome"
      component={withSafeArea(ReportsScreen)}
    />
    <Stack.Screen
      name="FeePlans"
      component={withSafeArea(FeePlansScreen)}
    />
    <Stack.Screen
      name="Seats"
      component={withSafeArea(SeatsScreen)}
    />
    <Stack.Screen
      name="Profile"
      component={withSafeArea(ProfileScreen)}
    />
    <Stack.Screen
      name="DueStudents"
      component={withSafeArea(DueStudentsScreen)}
    />
    <Stack.Screen
      name="StudentDetails"
      component={withSafeArea(StudentDetailsScreen)}
    />
  </Stack.Navigator>
);

// ------------------------------------------------------------
// MAIN TABS
// ------------------------------------------------------------
const MainTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: '#9CA3AF',
        tabBarStyle: {
          backgroundColor: COLORS.white,
          borderTopColor: '#E5E7EB',
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
        },
      }}>
      <Tab.Screen
        name="Home"
        component={HomeStack}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({color, size}) => (
            <Text style={{color, fontSize: size}}>⌂</Text>
          ),
          // tabBarIcon: () => '⌂',
        }}
      />

      <Tab.Screen
        name="Students"
        component={StudentsStack}
        options={{
          tabBarLabel: 'Students',
          tabBarIcon: ({color, size}) => (
  <Text style={{color, fontSize: size}}>●</Text>
),
          // tabBarIcon: () => '●',
        }}
      />

      <Tab.Screen
        name="Payments"
        component={PaymentsStack}
        options={{
          tabBarLabel: 'Payments',
          tabBarIcon: ({color, size}) => (
  <Text style={{color, fontSize: size}}>₹</Text>
),
          // tabBarIcon: () => '₹',
        }}
      />

      <Tab.Screen
        name="Expenses"
        component={ExpensesStack}
        options={{
          tabBarLabel: 'Expenses',
          tabBarIcon: ({color, size}) => (
  <Text style={{color, fontSize: size}}>▣</Text>
),
          // tabBarIcon: () => '▣',
        }}
      />

      <Tab.Screen
        name="Reports"
        component={ReportsStack}
        options={{
          tabBarLabel: 'Reports',
          tabBarIcon: ({color, size}) => (
  <Text style={{color, fontSize: size}}>≡</Text>
),
          // tabBarIcon: () => '≡',
        }}
      />
    </Tab.Navigator>
  );
};

export default MainTabs;

// import React from 'react';

// import {
//   createBottomTabNavigator,
// } from '@react-navigation/bottom-tabs';

// import {
//   createNativeStackNavigator,
// } from '@react-navigation/native-stack';

// import ScreenContainer from '../components/ScreenContainer';

// import DashboardScreen from '../screens/dashboard/DashboardScreen';
// import StudentsScreen from '../screens/students/StudentsScreen';
// import AddStudentScreen from '../screens/students/AddStudentScreen';
// import StudentDetailsScreen from '../screens/students/StudentDetailsScreen';

// import SeatsScreen from '../screens/seats/SeatsScreen';
// import PaymentsScreen from '../screens/payments/PaymentsScreen';
// import AddPaymentScreen from '../screens/payments/AddPaymentScreen';
// import ExpensesScreen from '../screens/expenses/ExpensesScreen';
// import AddExpenseScreen from '../screens/expenses/AddExpenseScreen';
// import ReportsScreen from '../screens/reports/ReportsScreen';
// import ProfileScreen from '../screens/profile/ProfileScreen';
// import FeePlansScreen from '../screens/fees/FeePlansScreen';
// import MembershipsScreen from '../screens/memberships/MembershipsScreen';
// import AddMembershipScreen from '../screens/memberships/AddMembershipScreen';
// import ReceiptsScreen from '../screens/receipts/ReceiptsScreen';
// import ReceiptDetailsScreen from '../screens/receipts/ReceiptDetailsScreen';


// import {COLORS} from '../constants/colors';

// const Tab = createBottomTabNavigator();
// const Stack = createNativeStackNavigator();

// // ---------- Wrapper helper ----------
// // Wraps any screen with safe-area handling so each screen file stays clean.
// const withSafeArea = Component => props => (
//   <ScreenContainer>
//     <Component {...props} />
//   </ScreenContainer>
// );

// // ---------- Students Stack ----------
// const StudentsStack = () => (
//   <Stack.Navigator screenOptions={{headerShown: false}}>
//     <Stack.Screen
//       name="StudentsList"
//       component={withSafeArea(StudentsScreen)}
//     />
//     <Stack.Screen
//       name="AddStudent"
//       component={withSafeArea(AddStudentScreen)}
//     />
//     <Stack.Screen
//       name="StudentDetails"
//       component={withSafeArea(StudentDetailsScreen)}
//     />

//     {/* Note: these are currently under Students tab.
//         Consider moving to a dedicated Payments/Expenses stack later. */}
//     <Stack.Screen
//       name="AddPayment"
//       component={withSafeArea(AddPaymentScreen)}
//     />
//     <Stack.Screen
//       name="PaymentsList"
//       component={withSafeArea(PaymentsScreen)}
//     />
//     <Stack.Screen
//       name="ExpensesList"
//       component={withSafeArea(ExpensesScreen)}
//     />
//     <Stack.Screen
//       name="AddExpense"
//       component={withSafeArea(AddExpenseScreen)}
//     />
//     <Stack.Screen
//       name="FeePlans"
//       component={withSafeArea(FeePlansScreen)}
//     />
//     <Stack.Screen
//       name="Memberships"
//       component={withSafeArea(MembershipsScreen)}
//     />
//     <Stack.Screen
//       name="AddMembership"
//       component={withSafeArea(AddMembershipScreen)}
//     />
//     <Stack.Screen
//       name="Receipts"
//       component={withSafeArea(ReceiptsScreen)}
//     />
//     <Stack.Screen
//       name="ReceiptDetails"
//       component={withSafeArea(ReceiptDetailsScreen)}
//     />
//   </Stack.Navigator>
// );

// // ---------- Main Tabs ----------
// const MainTabs = () => {
//   return (
//     <Tab.Navigator
//       screenOptions={{
//         headerShown: false,
//         tabBarActiveTintColor: COLORS.primary,
//         tabBarInactiveTintColor: '#9CA3AF',
//         tabBarStyle: {
//           backgroundColor: COLORS.white,
//           borderTopColor: '#E5E7EB',
//         },
//         tabBarLabelStyle: {
//           fontSize: 11,
//           fontWeight: '600',
//         },
//       }}>
//       <Tab.Screen
//         name="Home"
//         component={withSafeArea(DashboardScreen)}
//         options={{
//           tabBarLabel: 'Home',
//           tabBarIcon: () => '⌂',
//         }}
//       />

//       <Tab.Screen
//         name="Students"
//         component={StudentsStack}
//         options={{
//           tabBarLabel: 'Students',
//           tabBarIcon: () => '●',
//         }}
//       />

//       <Tab.Screen
//         name="Payments"
//         component={withSafeArea(PaymentsScreen)}
//         options={{
//           tabBarLabel: 'Payments',
//           tabBarIcon: () => '₹',
//         }}
//       />

//       <Tab.Screen
//         name="Expenses"
//         component={withSafeArea(ExpensesScreen)}
//         options={{
//           tabBarLabel: 'Expenses',
//           tabBarIcon: () => '▣',
//         }}
//       />

//       <Tab.Screen
//         name="More"
//         component={withSafeArea(ReportsScreen)}
//         options={{
//           tabBarLabel: 'Reports',
//           tabBarIcon: () => '≡',
//         }}
//       />
//     </Tab.Navigator>
//   );
// };

// export default MainTabs;