import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
} from 'react-native';

import {COLORS} from '../constants/colors';

const AppButton = ({
  title,
  onPress,
  loading = false,
  disabled = false,
  variant = 'primary',
}) => {
  const secondary =
    variant === 'secondary';

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({pressed}) => [
        styles.button,

        secondary && styles.secondary,

        pressed && styles.pressed,

        (disabled || loading) &&
          styles.disabled,
      ]}>
      {loading ? (
        <ActivityIndicator
          color={
            secondary
              ? COLORS.primary
              : COLORS.white
          }
        />
      ) : (
        <Text
          style={[
            styles.text,
            secondary &&
              styles.secondaryText,
          ]}>
          {title}
        </Text>
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  button: {
    height: 52,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },

  secondary: {
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
  },

  text: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: '700',
  },

  secondaryText: {
    color: COLORS.primary,
  },

  pressed: {
    opacity: 0.8,
  },

  disabled: {
    opacity: 0.5,
  },
});

export default AppButton;