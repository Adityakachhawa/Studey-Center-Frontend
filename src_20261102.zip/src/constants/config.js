// export const API_BASE_URL = 'http://192.168.1.7:5000';
export const API_BASE_URL = 'https://study-center-api-uzav.onrender.com';