import axios from 'axios';
import {API_BASE_URL} from '../constants/config';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  withCredentials: true,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
});

api.interceptors.response.use(
  response => {
    return response;
  },
  error => {
    if (error.response) {
      console.log(
        'API Error:',
        error.response.status,
        error.response.data,
      );
    } else {
      console.log('Network Error:', error.message);
    }

    return Promise.reject(error);
  },
);

export default api;