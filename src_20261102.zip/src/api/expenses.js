import api from './api';

export const getExpensesApi = async () => {
  const response = await api.get('/api/expenses');

  return response.data;
};

export const createExpenseApi = async data => {
  const response = await api.post('/api/expenses', data);

  return response.data;
};

export const updateExpenseApi = async (id, data) => {
  const response = await api.put(`/api/expenses/${id}`, data);

  return response.data;
};

export const deleteExpenseApi = async id => {
  const response = await api.delete(`/api/expenses/${id}`);
  return response.data;
};