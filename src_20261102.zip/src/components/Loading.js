import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {COLORS} from '../constants/colors';

const Loading = ({
  fullScreen = false,
  text = 'Loading...',
}) => {
  return (
    <View
      style={[
        styles.container,
        fullScreen && styles.fullScreen,
      ]}>
      <View style={styles.loaderBox}>
        <ActivityIndicator
          size="large"
          color={COLORS.primary}
        />

        {text ? (
          <Text style={styles.text}>{text}</Text>
        ) : null}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 140,
  },
  fullScreen: {
    backgroundColor: COLORS.background,
  },
  loaderBox: {
    alignItems: 'center',
  },
  text: {
    color: COLORS.textSecondary,
    fontSize: 12,
    fontWeight: '600',
    marginTop: 12,
  },
});

export default Loading;