// import React, {useCallback, useEffect, useState} from 'react';

// import {
//   ActivityIndicator,
//   Pressable,
//   RefreshControl,
//   ScrollView,
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {
//   getMonthlyReportApi,
//   getPaymentMethodReportApi,
//   getExpenseReportApi,
// } from '../../api/reports';

// import {COLORS} from '../../constants/colors';

// const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;

// const TABS = [
//   {key: 'MONTHLY', label: 'Monthly'},
//   {key: 'METHOD', label: 'By Method'},
//   {key: 'CATEGORY', label: 'By Category'},
// ];

// const monthKey = (y, m) =>
//   `${y}-${String(m).padStart(2, '0')}`;

// const monthLabel = (y, m) => {
//   const d = new Date(y, m - 1, 1);
//   return d.toLocaleDateString('en-IN', {
//     month: 'long',
//     year: 'numeric',
//   });
// };

// const BarRow = ({label, value, max, color, prefix}) => {
//   const pct = max > 0 ? Math.min(1, value / max) : 0;
//   return (
//     <View style={styles.barRow}>
//       <View style={styles.barHeader}>
//         <Text style={styles.barLabel}>{label}</Text>
//         <Text style={[styles.barValue, {color: color || COLORS.text}]}>
//           {prefix || ''}
//           {Number(value || 0).toLocaleString('en-IN')}
//         </Text>
//       </View>
//       <View style={styles.barTrack}>
//         <View
//           style={[
//             styles.barFill,
//             {width: `${pct * 100}%`, backgroundColor: color || COLORS.primary},
//           ]}
//         />
//       </View>
//     </View>
//   );
// };

// const ReportsScreen = ({navigation}) => {
//   const now = new Date();
//   const [year, setYear] = useState(now.getFullYear());
//   const [month, setMonth] = useState(now.getMonth() + 1);
//   const [tab, setTab] = useState('MONTHLY');

//   const [monthly, setMonthly] = useState(null);
//   const [methods, setMethods] = useState([]);
//   const [categories, setCategories] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);

//   const monthStr = monthKey(year, month);

//   const load = useCallback(async () => {
//     try {
//       const [m, p, e] = await Promise.all([
//         getMonthlyReportApi(monthStr),
//         getPaymentMethodReportApi(monthStr),
//         getExpenseReportApi(monthStr),
//       ]);
//       if (m?.status?.code === 200) setMonthly(m.data);
//       if (p?.status?.code === 200) setMethods(p.data || []);
//       if (e?.status?.code === 200) setCategories(e.data || []);
//     } catch (err) {
//       console.log('Reports error:', err);
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
//   }, [monthStr]);

//   useFocusEffect(
//     useCallback(() => {
//       load();
//     }, [load]),
//   );

//   const shiftMonth = delta => {
//     let newMonth = month + delta;
//     let newYear = year;
//     if (newMonth < 1) {
//       newMonth = 12;
//       newYear -= 1;
//     } else if (newMonth > 12) {
//       newMonth = 1;
//       newYear += 1;
//     }
//     setYear(newYear);
//     setMonth(newMonth);
//     setLoading(true);
//   };

//   const onRefresh = () => {
//     setRefreshing(true);
//     load();
//   };

//   const maxMethod = Math.max(
//     1,
//     ...methods.map(m => Number(m.total_amount || 0)),
//   );
//   const maxCategory = Math.max(
//     1,
//     ...categories.map(c => Number(c.total_amount || 0)),
//   );

//   return (
//     <ScrollView
//       style={styles.screen}
//       contentContainerStyle={styles.content}
//       refreshControl={
//         <RefreshControl
//           refreshing={refreshing}
//           onRefresh={onRefresh}
//         />
//       }>
//       <View style={styles.header}>
//         <View>
//           <Text style={styles.eyebrow}>REPORTS</Text>
//           <Text style={styles.title}>Analytics</Text>
//         </View>
//       </View>

//       {/* Month picker */}
//       <View style={styles.monthPicker}>
//         <Pressable
//           style={styles.monthButton}
//           onPress={() => shiftMonth(-1)}>
//           <Text style={styles.monthButtonText}>‹</Text>
//         </Pressable>
//         <Text style={styles.monthLabel}>{monthLabel(year, month)}</Text>
//         <Pressable
//           style={styles.monthButton}
//           onPress={() => shiftMonth(1)}>
//           <Text style={styles.monthButtonText}>›</Text>
//         </Pressable>
//       </View>

//       {/* Tabs */}
//       <View style={styles.tabRow}>
//         {TABS.map(t => {
//           const active = tab === t.key;
//           return (
//             <Pressable
//               key={t.key}
//               style={[styles.tab, active && styles.tabActive]}
//               onPress={() => setTab(t.key)}>
//               <Text
//                 style={[styles.tabText, active && styles.tabTextActive]}>
//                 {t.label}
//               </Text>
//             </Pressable>
//           );
//         })}
//       </View>

//       {loading ? (
//         <View style={styles.loader}>
//           <ActivityIndicator size="large" color={COLORS.primary} />
//         </View>
//       ) : tab === 'MONTHLY' ? (
//         <View>
//           <View style={styles.kpiGrid}>
//             <View style={styles.kpiCard}>
//               <Text style={styles.kpiLabel}>Collection</Text>
//               <Text style={[styles.kpiValue, {color: COLORS.success}]}>
//                 {formatMoney(monthly?.total_collection)}
//               </Text>
//             </View>
//             <View style={styles.kpiCard}>
//               <Text style={styles.kpiLabel}>Expense</Text>
//               <Text style={[styles.kpiValue, {color: COLORS.danger}]}>
//                 {formatMoney(monthly?.total_expense)}
//               </Text>
//             </View>
//             <View style={styles.kpiCard}>
//               <Text style={styles.kpiLabel}>Net</Text>
//               <Text
//                 style={[
//                   styles.kpiValue,
//                   {
//                     color:
//                       Number(monthly?.net_amount || 0) >= 0
//                         ? COLORS.success
//                         : COLORS.danger,
//                   },
//                 ]}>
//                 {formatMoney(monthly?.net_amount)}
//               </Text>
//             </View>
//             <View style={styles.kpiCard}>
//               <Text style={styles.kpiLabel}>New Students</Text>
//               <Text style={styles.kpiValue}>
//                 {monthly?.new_students || 0}
//               </Text>
//             </View>
//             <View style={styles.kpiCard}>
//               <Text style={styles.kpiLabel}>New Memberships</Text>
//               <Text style={styles.kpiValue}>
//                 {monthly?.new_memberships || 0}
//               </Text>
//             </View>
//             <View style={styles.kpiCard}>
//               <Text style={styles.kpiLabel}>Total Due</Text>
//               <Text style={[styles.kpiValue, {color: COLORS.warning}]}>
//                 {formatMoney(monthly?.current_total_due)}
//               </Text>
//             </View>
//           </View>
//         </View>
//       ) : tab === 'METHOD' ? (
//         <View style={styles.chartCard}>
//           <Text style={styles.chartTitle}>Collection by method</Text>
//           {methods.length === 0 ? (
//             <Text style={styles.empty}>No payments this month</Text>
//           ) : (
//             methods.map(m => (
//               <BarRow
//                 key={m.id}
//                 label={`${m.method_name} • ${m.transaction_count || 0} txns`}
//                 value={m.total_amount}
//                 max={maxMethod}
//                 color={COLORS.primary}
//                 prefix="₹"
//               />
//             ))
//           )}
//         </View>
//       ) : (
//         <View style={styles.chartCard}>
//           <Text style={styles.chartTitle}>Expenses by category</Text>
//           {categories.length === 0 ? (
//             <Text style={styles.empty}>No expenses this month</Text>
//           ) : (
//             categories.map(c => (
//               <BarRow
//                 key={c.category}
//                 label={`${c.category} • ${c.expense_count || 0} entries`}
//                 value={c.total_amount}
//                 max={maxCategory}
//                 color={COLORS.danger}
//                 prefix="₹"
//               />
//             ))
//           )}
//         </View>
//       )}

//       <View style={styles.section}>
//         <Text style={styles.sectionTitle}>Manage</Text>
//         <View style={styles.manageGrid}>
//           <Pressable
//             style={styles.manageCard}
//             onPress={() => navigation.navigate('Seats')}>
//             <Text style={styles.manageTitle}>Seats</Text>
//             <Text style={styles.manageSub}>Occupancy map</Text>
//           </Pressable>

//           <Pressable
//             style={styles.manageCard}
//             onPress={() => navigation.navigate('FeePlans')}>
//             <Text style={styles.manageTitle}>Fee Plans</Text>
//             <Text style={styles.manageSub}>Pricing</Text>
//           </Pressable>
//         </View>
//       </View>
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   screen: {flex: 1, backgroundColor: COLORS.background},
//   content: {padding: 20, paddingBottom: 40},

//   header: {marginBottom: 16},
//   eyebrow: {
//     fontSize: 10,
//     fontWeight: '800',
//     letterSpacing: 1.4,
//     color: COLORS.primary,
//     marginBottom: 4,
//   },
//   title: {fontSize: 28, fontWeight: '800', color: COLORS.text},

//   monthPicker: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     backgroundColor: COLORS.white,
//     borderRadius: 14,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     paddingHorizontal: 8,
//     paddingVertical: 6,
//     marginBottom: 14,
//   },
//   monthButton: {
//     width: 40,
//     height: 40,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   monthButtonText: {
//     fontSize: 22,
//     color: COLORS.primary,
//     fontWeight: '800',
//   },
//   monthLabel: {fontSize: 15, fontWeight: '800', color: COLORS.text},

//   tabRow: {
//     flexDirection: 'row',
//     backgroundColor: COLORS.white,
//     borderRadius: 14,
//     padding: 4,
//     marginBottom: 16,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//   },
//   tab: {
//     flex: 1,
//     paddingVertical: 10,
//     alignItems: 'center',
//     borderRadius: 10,
//   },
//   tabActive: {backgroundColor: COLORS.primary},
//   tabText: {fontSize: 12, fontWeight: '800', color: COLORS.textSecondary},
//   tabTextActive: {color: COLORS.white},

//   kpiGrid: {
//     flexDirection: 'row',
//     flexWrap: 'wrap',
//     justifyContent: 'space-between',
//   },
//   kpiCard: {
//     width: '48.5%',
//     backgroundColor: COLORS.white,
//     borderRadius: 14,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     padding: 14,
//     marginBottom: 10,
//   },
//   kpiLabel: {fontSize: 11, color: COLORS.textSecondary, fontWeight: '600'},
//   kpiValue: {
//     fontSize: 18,
//     fontWeight: '900',
//     color: COLORS.text,
//     marginTop: 6,
//   },

//   chartCard: {
//     backgroundColor: COLORS.white,
//     borderRadius: 16,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     padding: 16,
//   },
//   chartTitle: {
//     fontSize: 14,
//     fontWeight: '800',
//     color: COLORS.text,
//     marginBottom: 14,
//   },
//   barRow: {marginBottom: 14},
//   barHeader: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 6,
//   },
//   barLabel: {
//     fontSize: 12,
//     color: COLORS.textSecondary,
//     flex: 1,
//     marginRight: 8,
//   },
//   barValue: {fontSize: 12, fontWeight: '800'},
//   barTrack: {
//     height: 8,
//     backgroundColor: '#F1F5F9',
//     borderRadius: 4,
//     overflow: 'hidden',
//   },
//   barFill: {height: 8, borderRadius: 4},

//   empty: {
//     color: COLORS.textLight,
//     fontSize: 12,
//     textAlign: 'center',
//     paddingVertical: 20,
//   },

//   section: {marginTop: 22},
//   sectionTitle: {
//     fontSize: 17,
//     fontWeight: '800',
//     color: COLORS.text,
//     marginBottom: 12,
//   },
//   manageGrid: {flexDirection: 'row', gap: 10},
//   manageCard: {
//     flex: 1,
//     backgroundColor: COLORS.white,
//     borderRadius: 14,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     padding: 14,
//   },
//   manageTitle: {fontSize: 14, fontWeight: '800', color: COLORS.text},
//   manageSub: {fontSize: 11, color: COLORS.textSecondary, marginTop: 3},

//   loader: {paddingVertical: 60, alignItems: 'center'},
// });

// export default ReportsScreen;
import React, {useCallback, useState} from 'react';
import {
  ActivityIndicator, Modal, Platform, Pressable, RefreshControl,
  ScrollView, StyleSheet, Text, TouchableOpacity, View,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import DateTimePicker from '@react-native-community/datetimepicker';

import {
  getMonthlyReportApi,
  getPaymentMethodReportApi,
  getExpenseReportApi,
} from '../../api/reports';

import {COLORS} from '../../constants/colors';

const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;

const TABS = [
  {key: 'MONTHLY', label: 'Monthly'},
  {key: 'METHOD', label: 'By Method'},
  {key: 'CATEGORY', label: 'By Category'},
];

const BarRow = ({label, value, max, color, prefix}) => {
  const pct = max > 0 ? Math.min(1, value / max) : 0;
  return (
    <View style={styles.barRow}>
      <View style={styles.barHeader}>
        <Text style={styles.barLabel}>{label}</Text>
        <Text style={[styles.barValue, {color: color || COLORS.text}]}>
          {prefix || ''}{Number(value || 0).toLocaleString('en-IN')}
        </Text>
      </View>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, {width: `${pct * 100}%`, backgroundColor: color || COLORS.primary}]} />
      </View>
    </View>
  );
};

// Helper to format JS Date to YYYY-MM-DD
const toDateString = (date) => {
  if (!date) return '';
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const ReportsScreen = ({navigation}) => {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [tab, setTab] = useState('MONTHLY');

  const [monthly, setMonthly] = useState(null);
  const [methods, setMethods] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Date Filter State
  const [showDateModal, setShowDateModal] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [isCustomDate, setIsCustomDate] = useState(false);

  // Native Picker State
  const [showPicker, setShowPicker] = useState(false);
  const [pickerMode, setPickerMode] = useState('start'); // 'start' or 'end'

  const loadData = useCallback(async () => {
    setLoading(true);
    const params = isCustomDate
      ? { start_date: toDateString(startDate), end_date: toDateString(endDate) }
      : { month: `${year}-${String(month).padStart(2, '0')}` };

    try {
      const [m, p, e] = await Promise.all([
        getMonthlyReportApi(params),
        getPaymentMethodReportApi(params),
        getExpenseReportApi(params),
      ]);
      if (m?.status?.code === 200) setMonthly(m.data);
      if (p?.status?.code === 200) setMethods(p.data || []);
      if (e?.status?.code === 200) setCategories(e.data || []);
    } catch (err) {
      console.log('Reports error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [year, month, isCustomDate, startDate, endDate]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const shiftMonth = delta => {
    if (isCustomDate) return;
    let newMonth = month + delta;
    let newYear = year;
    if (newMonth < 1) { newMonth = 12; newYear -= 1; }
    else if (newMonth > 12) { newMonth = 1; newYear += 1; }
    setYear(newYear); setMonth(newMonth); setLoading(true);
  };

  const onChangeDate = (event, selectedDate) => {
    setShowPicker(Platform.OS === 'ios'); // Keep open on iOS, close on Android
    if (event.type === 'dismissed') {
      setShowPicker(false);
      return;
    }
    if (selectedDate) {
      if (pickerMode === 'start') setStartDate(selectedDate);
      else setEndDate(selectedDate);
    }
    if (Platform.OS === 'android') setShowPicker(false);
  };

  const applyCustomDate = () => {
    if (!startDate || !endDate) return alert("Please select both dates.");
    setIsCustomDate(true);
    setShowDateModal(false);
  };

  const clearCustomDate = () => {
    setIsCustomDate(false);
    setStartDate(null);
    setEndDate(null);
    setShowDateModal(false);
  };

  const maxMethod = Math.max(1, ...methods.map(m => Number(m.total_amount || 0)));
  const maxCategory = Math.max(1, ...categories.map(c => Number(c.total_amount || 0)));

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} />}>
      
      <View style={styles.header}>
        <View>
          <Text style={styles.eyebrow}>REPORTS</Text>
          <Text style={styles.title}>Analytics</Text>
        </View>
        <Pressable style={styles.filterBtn} onPress={() => setShowDateModal(true)}>
          <Text style={styles.filterBtnText}>📅 Filter Dates</Text>
        </Pressable>
      </View>

      {/* Date Selector / Month Picker */}
      {isCustomDate ? (
        <View style={styles.customDateBar}>
          <Text style={styles.customDateText}>
            {toDateString(startDate)} to {toDateString(endDate)}
          </Text>
          <Pressable onPress={clearCustomDate}>
            <Text style={styles.clearText}>✕ Clear</Text>
          </Pressable>
        </View>
      ) : (
        <View style={styles.monthPicker}>
          <Pressable style={styles.monthButton} onPress={() => shiftMonth(-1)}><Text style={styles.monthButtonText}>‹</Text></Pressable>
          <Text style={styles.monthLabel}>{new Date(year, month - 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</Text>
          <Pressable style={styles.monthButton} onPress={() => shiftMonth(1)}><Text style={styles.monthButtonText}>›</Text></Pressable>
        </View>
      )}

      {/* Tabs */}
      <View style={styles.tabRow}>
        {TABS.map(t => {
          const active = tab === t.key;
          return (
            <Pressable key={t.key} style={[styles.tab, active && styles.tabActive]} onPress={() => setTab(t.key)}>
              <Text style={[styles.tabText, active && styles.tabTextActive]}>{t.label}</Text>
            </Pressable>
          );
        })}
      </View>

      {loading ? (
        <View style={styles.loader}><ActivityIndicator size="large" color={COLORS.primary} /></View>
      ) : tab === 'MONTHLY' ? (
        <View style={styles.kpiGrid}>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Collection</Text>
            <Text style={[styles.kpiValue, {color: COLORS.success}]}>{formatMoney(monthly?.total_collection)}</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Expense</Text>
            <Text style={[styles.kpiValue, {color: COLORS.danger}]}>{formatMoney(monthly?.total_expense)}</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Net Profit</Text>
            <Text style={[styles.kpiValue, {color: Number(monthly?.net_amount || 0) >= 0 ? COLORS.success : COLORS.danger}]}>{formatMoney(monthly?.net_amount)}</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>New Students</Text>
            <Text style={styles.kpiValue}>{monthly?.new_students || 0}</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>New Memberships</Text>
            <Text style={styles.kpiValue}>{monthly?.new_memberships || 0}</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiLabel}>Total Due</Text>
            <Text style={[styles.kpiValue, {color: COLORS.warning}]}>{formatMoney(monthly?.current_total_due)}</Text>
          </View>
        </View>
      ) : tab === 'METHOD' ? (
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Collection by method</Text>
          {methods.length === 0 ? <Text style={styles.empty}>No payments</Text> : methods.map(m => (
            <BarRow key={m.id} label={`${m.method_name} • ${m.transaction_count || 0} txns`} value={m.total_amount} max={maxMethod} prefix="₹" />
          ))}
        </View>
      ) : (
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Expenses by category</Text>
          {categories.length === 0 ? <Text style={styles.empty}>No expenses</Text> : categories.map(c => (
            <BarRow key={c.category} label={`${c.category} • ${c.expense_count || 0} entries`} value={c.total_amount} max={maxCategory} color={COLORS.danger} prefix="₹" />
          ))}
        </View>
      )}

      {/* <View style={styles.section}>
        <Text style={styles.sectionTitle}>Manage</Text>
        <View style={styles.manageGrid}>
          <Pressable style={styles.manageCard} onPress={() => navigation.navigate('Seats')}>
            <Text style={styles.manageTitle}>Seats</Text>
            <Text style={styles.manageSub}>Occupancy map</Text>
          </Pressable>
          <Pressable style={styles.manageCard} onPress={() => navigation.navigate('FeePlans')}>
            <Text style={styles.manageTitle}>Fee Plans</Text>
            <Text style={styles.manageSub}>Pricing</Text>
          </Pressable>
        </View>
      </View> */}
            <View style={styles.section}>
        <Text style={styles.sectionTitle}>Manage & Reports</Text>
        
        <View style={styles.manageGrid}>
          <Pressable style={styles.manageCard} onPress={() => navigation.navigate('Seats')}>
            <Text style={styles.manageTitle}>Seats</Text>
            <Text style={styles.manageSub}>Occupancy map</Text>
          </Pressable>
          
          <Pressable style={styles.manageCard} onPress={() => navigation.navigate('FeePlans')}>
            <Text style={styles.manageTitle}>Fee Plans</Text>
            <Text style={styles.manageSub}>Pricing</Text>
          </Pressable>
        </View>

        {/* 👉 Added Due Students Button back */}
        <Pressable 
          style={[styles.manageCard, { marginTop: 10, backgroundColor: COLORS.dangerBg, borderColor: COLORS.dangerBg }]} 
          onPress={() => navigation.navigate('DueStudents')}
        >
          <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
            <View>
              <Text style={[styles.manageTitle, {color: COLORS.danger}]}>Due Students</Text>
              <Text style={[styles.manageSub, {color: COLORS.danger}]}>View pending fees & history</Text>
            </View>
            <Text style={{fontSize: 20, color: COLORS.danger}}>›</Text>
          </View>
        </Pressable>

      </View>

      {/* Date Filter Modal */}
      <Modal visible={showDateModal} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Filter by Date</Text>
            
            <Text style={styles.filterLabel}>Start Date</Text>
            <TouchableOpacity style={styles.input} onPress={() => { setPickerMode('start'); setShowPicker(true); }}>
              <Text style={{color: startDate ? COLORS.text : COLORS.textLight}}>
                {startDate ? toDateString(startDate) : 'Select Start Date'}
              </Text>
            </TouchableOpacity>

            <Text style={styles.filterLabel}>End Date</Text>
            <TouchableOpacity style={styles.input} onPress={() => { setPickerMode('end'); setShowPicker(true); }}>
              <Text style={{color: endDate ? COLORS.text : COLORS.textLight}}>
                {endDate ? toDateString(endDate) : 'Select End Date'}
              </Text>
            </TouchableOpacity>
            
            <Pressable style={styles.modalBtn} onPress={applyCustomDate}>
              <Text style={styles.modalBtnText}>Apply Filter</Text>
            </Pressable>
            <Pressable style={[styles.modalBtn, {backgroundColor: COLORS.background, marginTop: 8}]} onPress={() => setShowDateModal(false)}>
              <Text style={[styles.modalBtnText, {color: COLORS.textSecondary}]}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {/* Native Date Picker */}
      {showPicker && (
        <DateTimePicker
          value={(pickerMode === 'start' ? startDate : endDate) || new Date()}
          mode="date"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={onChangeDate}
        />
      )}

    </ScrollView>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  content: {padding: 20, paddingBottom: 40},
  header: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16},
  eyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.4, color: COLORS.primary, marginBottom: 4},
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  filterBtn: {backgroundColor: COLORS.white, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border},
  filterBtnText: {fontSize: 13, fontWeight: '700', color: COLORS.text},
  
  customDateBar: {flexDirection: 'row', justifyContent: 'space-between', backgroundColor: COLORS.primary, padding: 14, borderRadius: 14, marginBottom: 14},
  customDateText: {color: COLORS.white, fontWeight: '700'},
  clearText: {color: COLORS.white, fontWeight: '800'},

  monthPicker: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORS.white, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 8, paddingVertical: 6, marginBottom: 14},
  monthButton: {width: 40, height: 40, alignItems: 'center', justifyContent: 'center'},
  monthButtonText: {fontSize: 22, color: COLORS.primary, fontWeight: '800'},
  monthLabel: {fontSize: 15, fontWeight: '800', color: COLORS.text},

  tabRow: {flexDirection: 'row', backgroundColor: COLORS.white, borderRadius: 14, padding: 4, marginBottom: 16, borderWidth: 1, borderColor: COLORS.border},
  tab: {flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10},
  tabActive: {backgroundColor: COLORS.primary},
  tabText: {fontSize: 12, fontWeight: '800', color: COLORS.textSecondary},
  tabTextActive: {color: COLORS.white},

  kpiGrid: {flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between'},
  kpiCard: {width: '48.5%', backgroundColor: COLORS.white, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, padding: 14, marginBottom: 10},
  kpiLabel: {fontSize: 11, color: COLORS.textSecondary, fontWeight: '600'},
  kpiValue: {fontSize: 18, fontWeight: '900', color: COLORS.text, marginTop: 6},

  chartCard: {backgroundColor: COLORS.white, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border, padding: 16},
  chartTitle: {fontSize: 14, fontWeight: '800', color: COLORS.text, marginBottom: 14},
  barRow: {marginBottom: 14},
  barHeader: {flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6},
  barLabel: {fontSize: 12, color: COLORS.textSecondary, flex: 1, marginRight: 8},
  barValue: {fontSize: 12, fontWeight: '800'},
  barTrack: {height: 8, backgroundColor: '#F1F5F9', borderRadius: 4, overflow: 'hidden'},
  barFill: {height: 8, borderRadius: 4},
  empty: {color: COLORS.textLight, fontSize: 12, textAlign: 'center', paddingVertical: 20},

  section: {marginTop: 22},
  sectionTitle: {fontSize: 17, fontWeight: '800', color: COLORS.text, marginBottom: 12},
  manageGrid: {flexDirection: 'row', gap: 10},
  manageCard: {flex: 1, backgroundColor: COLORS.white, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, padding: 14},
  manageTitle: {fontSize: 14, fontWeight: '800', color: COLORS.text},
  manageSub: {fontSize: 11, color: COLORS.textSecondary, marginTop: 3},
  loader: {paddingVertical: 60, alignItems: 'center'},

  modalBg: {flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20},
  modalContent: {backgroundColor: COLORS.white, borderRadius: 20, padding: 20},
  modalTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text, marginBottom: 16},
  filterLabel: {fontSize: 12, color: COLORS.textSecondary, marginBottom: 6, fontWeight: '600'},
  
  // Changed input to look like a touchable field
  input: {
    height: 48, backgroundColor: COLORS.background, borderRadius: 12,
    borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 14,
    justifyContent: 'center', marginBottom: 14,
  },
  
  modalBtn: {backgroundColor: COLORS.primary, height: 48, borderRadius: 12, alignItems: 'center', justifyContent: 'center'},
  modalBtnText: {color: COLORS.white, fontWeight: '800', fontSize: 14},
});

export default ReportsScreen;