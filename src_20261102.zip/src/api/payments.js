// import api from './api';

// export const getPaymentsApi = async studentId => {
//   const response = await api.get('/api/payments', {
//     params: studentId
//       ? {student_id: studentId}
//       : {},
//   });

//   return response.data;
// };

// export const createPaymentApi = async data => {
//   const response = await api.post('/api/payments', data);

//   return response.data;
// };

// export const getReceiptsApi = async () => {
//   const response = await api.get('/api/receipts');

//   return response.data;
// };

// export const createReceiptApi = async paymentId => {
//   const response = await api.post('/api/receipts', {
//     payment_id: paymentId,
//   });

//   return response.data;
// };
import api from './api';

export const getPaymentsApi = async params => {
  const response = await api.get('/api/payments', {
    params: params || {},
  });

  return response.data;
};

export const createPaymentApi = async data => {
  const response = await api.post('/api/payments', data);

  return response.data;
};