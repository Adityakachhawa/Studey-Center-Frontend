import React, {useEffect, useMemo, useState} from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import AppButton from '../../components/AppButton';
import AppInput from '../../components/AppInput';
import ScreenHeader from '../../components/ScreenHeader';
import Loading from '../../components/Loading';

import {COLORS} from '../../constants/colors';

import {getStudentsApi} from '../../api/students';
import {
  getPaymentMethodsApi,
  getMembershipsApi,
} from '../../api/fees';
import {createPaymentApi} from '../../api/payments';
import {createReceiptApi} from '../../api/receipts';


const AddPaymentScreen = ({navigation, route}) => {
  const initialStudentId = route?.params?.studentId || null;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [students, setStudents] = useState([]);
  const [memberships, setMemberships] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState([]);

  const [studentId, setStudentId] = useState(initialStudentId);
  const [membershipId, setMembershipId] = useState(
    route?.params?.membershipId || null,
  );
  const [paymentMethodId, setPaymentMethodId] = useState(null);

  const [amount, setAmount] = useState(
    route?.params?.amount ? String(route.params.amount) : '',
  );
  const [referenceNumber, setReferenceNumber] = useState('');
  const [remarks, setRemarks] = useState('');

  const [studentSearch, setStudentSearch] = useState('');

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    if (studentId) {
      loadMemberships(studentId);
    } else {
      setMemberships([]);
      setMembershipId(null);
    }
  }, [studentId]);

  const loadInitialData = async () => {
    try {
      setLoading(true);

      const [studentsResponse, methodsResponse] = await Promise.all([
        getStudentsApi({status: 'ACTIVE'}),
        getPaymentMethodsApi(),
      ]);

      if (studentsResponse?.status?.code === 200) {
        setStudents(studentsResponse.data || []);
      }

      if (methodsResponse?.status?.code === 200) {
        const methods = methodsResponse.data || [];
        setPaymentMethods(methods);

        if (methods.length === 1) {
          setPaymentMethodId(methods[0].id);
        }
      }

      if (initialStudentId) {
        await loadMemberships(initialStudentId);
      }
    } catch (error) {
      console.log('Add payment load error:', error);
      Alert.alert('Error', 'Unable to load payment data.');
    } finally {
      setLoading(false);
    }
  };

  const loadMemberships = async id => {
    try {
      const response = await getMembershipsApi(id);

      if (response?.status?.code === 200) {
        const data = response.data || [];

        setMemberships(data);

        if (data.length === 1) {
          setMembershipId(data[0].id);

          if (!amount && Number(data[0].due_amount) > 0) {
            setAmount(String(data[0].due_amount));
          }
        }
      }
    } catch (error) {
      console.log('Membership error:', error);
      setMemberships([]);
    }
  };

  const selectedStudent = useMemo(
    () => students.find(item => Number(item.id) === Number(studentId)),
    [students, studentId],
  );

  const selectedMembership = useMemo(
    () =>
      memberships.find(
        item => Number(item.id) === Number(membershipId),
      ),
    [memberships, membershipId],
  );

  const filteredStudents = useMemo(() => {
    const search = studentSearch.trim().toLowerCase();

    if (!search) {
      return students.slice(0, 10);
    }

    return students
      .filter(student => {
        return (
          String(student.full_name || '')
            .toLowerCase()
            .includes(search) ||
          String(student.mobile || '').includes(search) ||
          String(student.student_code || '')
            .toLowerCase()
            .includes(search)
        );
      })
      .slice(0, 10);
  }, [students, studentSearch]);

  const handleStudentSelect = student => {
    setStudentId(student.id);
    setMembershipId(null);
    setAmount('');
    setStudentSearch('');
  };

  const handleMembershipSelect = membership => {
    setMembershipId(membership.id);

    if (Number(membership.due_amount) > 0) {
      setAmount(String(membership.due_amount));
    }
  };

  const handleSubmit = async () => {
    if (!studentId) {
      Alert.alert('Required', 'Please select a student.');
      return;
    }

    if (!paymentMethodId) {
      Alert.alert('Required', 'Please select a payment method.');
      return;
    }

    if (!amount || Number(amount) <= 0) {
      Alert.alert('Required', 'Please enter a valid payment amount.');
      return;
    }

    // if (selectedMembership && Number(amount) > Number(selectedMembership.due_amount || 0)) {
    //   Alert.alert(
    //     'Invalid amount',
    //     `Maximum due amount is ₹${Number(
    //       selectedMembership.due_amount || 0,
    //     ).toFixed(2)}.`,
    //   );
    //   return;
    // }

    if (
      selectedMembership &&
      Number(selectedMembership.due_amount) > 0 &&
      Number(amount) > Number(selectedMembership.due_amount)
    ) {
      Alert.alert(
        'Invalid amount',
        `Maximum due amount is ₹${Number(
          selectedMembership.due_amount,
        ).toFixed(2)}.`,
      );
      return;
    }

    try {
      setSaving(true);

      const response = await createPaymentApi({
        student_id: Number(studentId),
        membership_id: membershipId ? Number(membershipId) : null,
        payment_method_id: Number(paymentMethodId),
        amount: Number(amount),
        transaction_reference: referenceNumber.trim() || null,
        remarks: remarks.trim() || null,
      });

      if (response?.status?.code !== 200) {
        throw new Error(
          response?.status?.message || 'Payment could not be created.',
        );
      }

      // Alert.alert(
      //   'Payment Successful',
      //   'Payment has been recorded successfully.',
      //   [
      //     {
      //       text: 'Done',
      //       onPress: () => navigation.goBack(),
      //     },
      //   ],
      // );
            // 🔵 NEW: auto-generate receipt right after payment success
      let receiptData = null;

      try {
        const receiptRes = await createReceiptApi(
          response.data.payment_id,
        );

        if (receiptRes?.status?.code === 200) {
          receiptData = receiptRes.data;
        }
      } catch (receiptError) {
        console.log('Receipt generate error:', receiptError);
      }

      if (receiptData) {
        Alert.alert(
          'Payment Successful',
          `Receipt ${receiptData.receipt_number} generated.\n\nShare it on WhatsApp now?`,
          [
            {
              text: 'Later',
              style: 'cancel',
              onPress: () => navigation.goBack(),
            },
            {
              text: 'View Receipt',
              onPress: () => {
                // Build a minimal receipt object using what we know
                // from this screen — the full receipt object will
                // be refetched on the Receipts screen anyway.
                navigation.replace('ReceiptDetails', {
                  receipt: {
                    ...receiptData,
                    amount: Number(amount),
                    full_name: selectedStudent?.full_name,
                    student_code: selectedStudent?.student_code,
                    mobile: selectedStudent?.mobile,
                    method_name: paymentMethods.find(
                      m => Number(m.id) === Number(paymentMethodId),
                    )?.method_name,
                    payment_number: response.data.payment_number,
                    receipt_date: new Date().toISOString(),
                  },
                });
              },
            },
          ],
        );
      } else {
        Alert.alert(
          'Payment Successful',
          'Payment has been recorded, but receipt could not be generated. You can generate it later from the Payments tab.',
          [{text: 'OK', onPress: () => navigation.goBack()}],
        );
      }

    } catch (error) {
      Alert.alert(
        'Payment Failed',
        error?.response?.data?.status?.message ||
          error.message ||
          'Unable to record payment.',
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <Loading fullScreen text="Loading payment form..." />;
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScreenHeader
        title="Add Payment"
        subtitle="Record a student fee payment"
        onBack={() => navigation.goBack()}
      />

      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Student</Text>

          {selectedStudent ? (
            <View style={styles.selectedCard}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>
                  {selectedStudent.full_name?.charAt(0)?.toUpperCase()}
                </Text>
              </View>

              <View style={styles.selectedInfo}>
                <Text style={styles.selectedName}>
                  {selectedStudent.full_name}
                </Text>
                <Text style={styles.selectedMeta}>
                  {selectedStudent.student_code} • {selectedStudent.mobile}
                </Text>
              </View>

              <TouchableOpacity
                onPress={() => {
                  setStudentId(null);
                  setMembershipId(null);
                  setAmount('');
                }}>
                <Text style={styles.changeText}>Change</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              <AppInput
                placeholder="Search student name, mobile or code"
                value={studentSearch}
                onChangeText={setStudentSearch}
              />

              {filteredStudents.map(student => (
                <TouchableOpacity
                  key={student.id}
                  style={styles.studentOption}
                  onPress={() => handleStudentSelect(student)}>
                  <View style={styles.smallAvatar}>
                    <Text style={styles.smallAvatarText}>
                      {student.full_name?.charAt(0)?.toUpperCase()}
                    </Text>
                  </View>

                  <View style={styles.optionInfo}>
                    <Text style={styles.optionName}>
                      {student.full_name}
                    </Text>
                    <Text style={styles.optionMeta}>
                      {student.student_code} • {student.mobile}
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}
            </>
          )}
        </View>

        {studentId && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Membership</Text>

            {memberships.length === 0 ? (
              <View style={styles.warningBox}>
                <Text style={styles.warningText}>
                  No membership found for this student.
                </Text>
              </View>
            ) : (
              memberships.map(membership => {
                const selected =
                  Number(membership.id) === Number(membershipId);

                return (
                  <TouchableOpacity
                    key={membership.id}
                    style={[
                      styles.membershipCard,
                      selected && styles.membershipCardSelected,
                    ]}
                    onPress={() => handleMembershipSelect(membership)}>
                    <View style={styles.radio}>
                      {selected && <View style={styles.radioInner} />}
                    </View>

                    <View style={styles.membershipInfo}>
                      <Text style={styles.planName}>
                        {membership.plan_name || 'Membership'}
                      </Text>

                      <Text style={styles.membershipDates}>
                        {membership.start_date} → {membership.expiry_date}
                      </Text>

                      <Text style={styles.membershipSeat}>
                        Seat: {membership.seat_number || 'Not assigned'}
                      </Text>
                    </View>

                    <View style={styles.amountBox}>
                      <Text style={styles.amountLabel}>Due</Text>
                      <Text style={styles.dueAmount}>
                        ₹{Number(membership.due_amount || 0).toFixed(0)}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })
            )}
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Method</Text>

          <View style={styles.methodGrid}>
            {paymentMethods.map(method => {
              const selected =
                Number(method.id) === Number(paymentMethodId);

              return (
                <TouchableOpacity
                  key={method.id}
                  style={[
                    styles.methodCard,
                    selected && styles.methodCardSelected,
                  ]}
                  onPress={() => setPaymentMethodId(method.id)}>
                  <Text
                    style={[
                      styles.methodText,
                      selected && styles.methodTextSelected,
                    ]}>
                    {method.method_name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Details</Text>

          <AppInput
            label="Amount"
            placeholder="Enter amount"
            value={amount}
            onChangeText={setAmount}
            keyboardType="decimal-pad"
          />

          <AppInput
            label="Transaction / Reference Number"
            placeholder="Optional"
            value={referenceNumber}
            onChangeText={setReferenceNumber}
          />

          <AppInput
            label="Remarks"
            placeholder="Optional notes"
            value={remarks}
            onChangeText={setRemarks}
            multiline
            numberOfLines={4}
          />
        </View>

        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Payment Summary</Text>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Student</Text>
            <Text style={styles.summaryValue}>
              {selectedStudent?.full_name || '-'}
            </Text>
          </View>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Method</Text>
            <Text style={styles.summaryValue}>
              {paymentMethods.find(
                item => Number(item.id) === Number(paymentMethodId),
              )?.method_name || '-'}
            </Text>
          </View>

          <View style={styles.divider} />

          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total Payment</Text>
            <Text style={styles.totalAmount}>
              ₹{Number(amount || 0).toFixed(2)}
            </Text>
          </View>
        </View>

        <AppButton
          title={saving ? 'Saving Payment...' : 'Record Payment'}
          onPress={handleSubmit}
          loading={saving}
        />

        <View style={{height: 30}} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
  },
  section: {
    marginBottom: 22,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  selectedCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: '800',
  },
  selectedInfo: {
    flex: 1,
    marginLeft: 12,
  },
  selectedName: {
    color: COLORS.text,
    fontSize: 15,
    fontWeight: '800',
  },
  selectedMeta: {
    color: COLORS.textSecondary,
    fontSize: 12,
    marginTop: 3,
  },
  changeText: {
    color: COLORS.primary,
    fontWeight: '800',
    fontSize: 12,
  },
  studentOption: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 14,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  smallAvatar: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: COLORS.purpleBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  smallAvatarText: {
    color: COLORS.purple,
    fontWeight: '800',
  },
  optionInfo: {
    flex: 1,
    marginLeft: 10,
  },
  optionName: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.text,
  },
  optionMeta: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  membershipCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  membershipCardSelected: {
    borderColor: COLORS.primary,
    backgroundColor: '#F5F8FF',
  },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: COLORS.primary,
  },
  membershipInfo: {
    flex: 1,
    marginLeft: 12,
  },
  planName: {
    fontSize: 14,
    fontWeight: '800',
    color: COLORS.text,
  },
  membershipDates: {
    color: COLORS.textSecondary,
    fontSize: 11,
    marginTop: 4,
  },
  membershipSeat: {
    color: COLORS.textLight,
    fontSize: 11,
    marginTop: 3,
  },
  amountBox: {
    alignItems: 'flex-end',
  },
  amountLabel: {
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  dueAmount: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.danger,
    marginTop: 2,
  },
  warningBox: {
    padding: 14,
    borderRadius: 14,
    backgroundColor: COLORS.warningBg,
  },
  warningText: {
    color: COLORS.warning,
    fontSize: 13,
    fontWeight: '600',
  },
  methodGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  methodCard: {
    paddingHorizontal: 18,
    paddingVertical: 13,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 12,
  },
  methodCardSelected: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primary,
  },
  methodText: {
    color: COLORS.text,
    fontSize: 13,
    fontWeight: '700',
  },
  methodTextSelected: {
    color: COLORS.white,
  },
  summaryCard: {
    backgroundColor: COLORS.text,
    borderRadius: 20,
    padding: 18,
    marginBottom: 18,
  },
  summaryTitle: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 15,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  summaryLabel: {
    color: '#AEB6C2',
    fontSize: 12,
  },
  summaryValue: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '700',
  },
  divider: {
    height: 1,
    backgroundColor: '#2C3440',
    marginVertical: 8,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalLabel: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: '700',
  },
  totalAmount: {
    color: COLORS.white,
    fontSize: 22,
    fontWeight: '900',
  },
});

export default AddPaymentScreen;