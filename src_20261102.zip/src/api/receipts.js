import api from './api';

export const getReceiptsApi = async params => {
  const response = await api.get('/api/receipts', {
    params: params || {},
  });

  return response.data;
};

export const createReceiptApi = async paymentId => {
  const response = await api.post('/api/receipts', {
    payment_id: paymentId,
  });

  return response.data;
};