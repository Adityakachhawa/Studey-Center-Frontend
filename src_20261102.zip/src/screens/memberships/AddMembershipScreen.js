// import React, {useCallback, useEffect, useMemo, useState} from 'react';

// import {
//   ActivityIndicator,
//   Alert,
//   FlatList,
//   Pressable,
//   ScrollView,
//   StyleSheet,
//   Text,
//   TextInput,
//   View,
// } from 'react-native';

// import {getStudentsApi} from '../../api/students';
// import {getFeePlansApi} from '../../api/fees';
// import {getAvailableSeatsApi} from '../../api/seats';
// import {createMembershipApi} from '../../api/memberships';

// import {COLORS} from '../../constants/colors';

// const toDateString = date => {
//   const y = date.getFullYear();
//   const m = String(date.getMonth() + 1).padStart(2, '0');
//   const d = String(date.getDate()).padStart(2, '0');

//   return `${y}-${m}-${d}`;
// };

// const formatMoney = value => {
//   const number = Number(value || 0);

//   return `₹${number.toLocaleString('en-IN')}`;
// };

// const AddMembershipScreen = ({navigation, route}) => {
//   const [students, setStudents] = useState([]);
//   const [plans, setPlans] = useState([]);
//   const [seats, setSeats] = useState([]);

//   const [loadingLookups, setLoadingLookups] = useState(true);
//   const [submitting, setSubmitting] = useState(false);

//   const [studentSearch, setStudentSearch] = useState('');
//   const [selectedStudent, setSelectedStudent] = useState(null);
//   const [selectedPlan, setSelectedPlan] = useState(null);
//   const [selectedSeat, setSelectedSeat] = useState(null);

//   const [startDate, setStartDate] = useState(
//     toDateString(new Date()),
//   );

//   const [discount, setDiscount] = useState('0');
//   const [paid, setPaid] = useState('0');

//   const [step, setStep] = useState(1); // 1 student, 2 plan, 3 seat, 4 confirm
//   const initialStudentId = route?.params?.studentId;

//   // ---------- Load lookups ----------
//   useEffect(() => {
//     const load = async () => {
//       try {
//         const [studentsRes, plansRes] = await Promise.all([
//           getStudentsApi({status: 'ACTIVE'}),
//           getFeePlansApi({status: 'ACTIVE'}),
//         ]);

//         if (studentsRes?.status?.code === 200) {
//           setStudents(studentsRes.data || []);
//           if (initialStudentId) {
//             const found = (studentsRes.data || []).find(
//                 s => Number(s.id) === Number(initialStudentId),
//             );

//             if (found) {
//                 setSelectedStudent(found);
//                 setStep(2);
//             }
//             }
//         }

//         if (plansRes?.status?.code === 200) {
//           setPlans(plansRes.data || []);
//         }
//       } catch (error) {
//         console.log('Lookup error:', error);
//       } finally {
//         setLoadingLookups(false);
//       }
//     };

//     load();
//   }, []);

//   // ---------- Load available seats after student selected ----------
//   useEffect(() => {
//     const loadSeats = async () => {
//       if (!selectedStudent) return;

//       try {
//         const res = await getAvailableSeatsApi(
//           selectedStudent.gender || 'ANY',
//         );

//         if (res?.status?.code === 200) {
//           setSeats(res.data || []);
//         }
//       } catch (error) {
//         console.log('Seats error:', error);
//       }
//     };

//     loadSeats();
//   }, [selectedStudent]);

//   // ---------- Computed amounts ----------
//   const amounts = useMemo(() => {
//     const planAmount = Number(selectedPlan?.amount || 0);
//     const discountAmount = Math.max(0, Number(discount || 0));
//     const finalAmount = Math.max(0, planAmount - discountAmount);
//     const paidAmount = Math.max(0, Number(paid || 0));
//     const dueAmount = Math.max(0, finalAmount - paidAmount);

//     return {planAmount, discountAmount, finalAmount, paidAmount, dueAmount};
//   }, [selectedPlan, discount, paid]);

//   // ---------- Submit ----------
//   const submit = async () => {
//     if (!selectedStudent) {
//       return Alert.alert('Missing', 'Select a student first.');
//     }

//     if (!selectedPlan) {
//       return Alert.alert('Missing', 'Select a fee plan.');
//     }

//     if (amounts.paidAmount > amounts.finalAmount) {
//       return Alert.alert('Invalid', 'Paid amount exceeds final amount.');
//     }

//     try {
//       setSubmitting(true);

//       const response = await createMembershipApi({
//         student_id: selectedStudent.id,
//         fee_plan_id: selectedPlan.id,
//         seat_id: selectedSeat?.id || null,
//         joining_date: startDate,
//         start_date: startDate,
//         discount_amount: amounts.discountAmount,
//         paid_amount: amounts.paidAmount,
//         remarks: null,
//       });

//       if (response?.status?.code === 200) {
//         Alert.alert(
//           'Membership created',
//           `Expiry: ${response.data.expiry_date}\nDue: ${formatMoney(
//             response.data.due_amount,
//           )}`,
//           [
//             {
//               text: 'OK',
//               onPress: () => navigation.goBack(),
//             },
//           ],
//         );
//       } else {
//         Alert.alert(
//           'Failed',
//           response?.status?.message || 'Could not create membership',
//         );
//       }
//     } catch (error) {
//       Alert.alert(
//         'Failed',
//         error?.response?.data?.status?.message ||
//           'Something went wrong',
//       );
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   // ---------- UI ----------
//   const renderStudentPicker = () => {
//     const filtered = students.filter(s => {
//       if (!studentSearch) return true;

//       const q = studentSearch.toLowerCase();

//       return (
//         s.full_name?.toLowerCase().includes(q) ||
//         s.mobile?.includes(q) ||
//         s.student_code?.toLowerCase().includes(q)
//       );
//     });

//     return (
//       <View>
//         <Text style={styles.sectionTitle}>1. Select Student</Text>

//         <TextInput
//           value={studentSearch}
//           onChangeText={setStudentSearch}
//           placeholder="Search by name, mobile, code"
//           placeholderTextColor={COLORS.textLight}
//           style={styles.input}
//           autoCorrect={false}
//           autoCapitalize="none"
//         />

//         <FlatList
//           data={filtered}
//           keyExtractor={item => String(item.id)}
//           scrollEnabled={false}
//           renderItem={({item}) => {
//             const selected = selectedStudent?.id === item.id;

//             return (
//               <Pressable
//                 style={[
//                   styles.pickRow,
//                   selected && styles.pickRowActive,
//                 ]}
//                 onPress={() => {
//                   setSelectedStudent(item);
//                   setSelectedSeat(null);
//                   setStep(2);
//                 }}>
//                 <View style={styles.pickLeft}>
//                   <Text style={styles.pickTitle}>{item.full_name}</Text>
//                   <Text style={styles.pickSub}>
//                     {item.student_code} • {item.mobile} • {item.gender}
//                   </Text>
//                 </View>

//                 {selected && (
//                   <Text style={styles.tick}>✓</Text>
//                 )}
//               </Pressable>
//             );
//           }}
//           ListEmptyComponent={
//             <Text style={styles.emptyPick}>No matching students.</Text>
//           }
//         />
//       </View>
//     );
//   };

//   const renderPlanPicker = () => (
//     <View style={{marginTop: 24}}>
//       <Text style={styles.sectionTitle}>2. Select Fee Plan</Text>

//       {plans.map(plan => {
//         const selected = selectedPlan?.id === plan.id;

//         return (
//           <Pressable
//             key={plan.id}
//             style={[
//               styles.pickRow,
//               selected && styles.pickRowActive,
//             ]}
//             onPress={() => {
//               setSelectedPlan(plan);
//               setStep(3);
//             }}>
//             <View style={styles.pickLeft}>
//               <Text style={styles.pickTitle}>{plan.plan_name}</Text>
//               <Text style={styles.pickSub}>
//                 {plan.duration_days} days • {formatMoney(plan.amount)}
//               </Text>
//             </View>

//             {selected && <Text style={styles.tick}>✓</Text>}
//           </Pressable>
//         );
//       })}
//     </View>
//   );

//   const renderSeatPicker = () => (
//     <View style={{marginTop: 24}}>
//       <Text style={styles.sectionTitle}>3. Select Seat (optional)</Text>

//       {seats.length === 0 ? (
//         <Text style={styles.emptyPick}>
//           No seats available for this gender. You can skip and assign later.
//         </Text>
//       ) : (
//         <View style={styles.seatGrid}>
//           {seats.map(seat => {
//             const selected = selectedSeat?.id === seat.id;

//             return (
//               <Pressable
//                 key={seat.id}
//                 style={[
//                   styles.seatChip,
//                   selected && styles.seatChipActive,
//                 ]}
//                 onPress={() => {
//                   setSelectedSeat(
//                     selected ? null : seat,
//                   );
//                   setStep(4);
//                 }}>
//                 <Text
//                   style={[
//                     styles.seatText,
//                     selected && styles.seatTextActive,
//                   ]}>
//                   {seat.seat_number}
//                 </Text>
//               </Pressable>
//             );
//           })}
//         </View>
//       )}

//       <Pressable
//         style={styles.skipButton}
//         onPress={() => {
//           setSelectedSeat(null);
//           setStep(4);
//         }}>
//         <Text style={styles.skipText}>Skip — assign seat later</Text>
//       </Pressable>
//     </View>
//   );

//   const renderConfirm = () => (
//     <View style={{marginTop: 24}}>
//       <Text style={styles.sectionTitle}>4. Dates & Payment</Text>

//       <Text style={styles.fieldLabel}>Start Date (YYYY-MM-DD)</Text>
//       <TextInput
//         value={startDate}
//         onChangeText={setStartDate}
//         style={styles.input}
//         autoCapitalize="none"
//         autoCorrect={false}
//       />

//       <Text style={styles.fieldLabel}>Discount (₹)</Text>
//       <TextInput
//         value={discount}
//         onChangeText={setDiscount}
//         style={styles.input}
//         keyboardType="numeric"
//       />

//       <Text style={styles.fieldLabel}>Paid Now (₹)</Text>
//       <TextInput
//         value={paid}
//         onChangeText={setPaid}
//         style={styles.input}
//         keyboardType="numeric"
//       />

//       <View style={styles.summary}>
//         <View style={styles.summaryRow}>
//           <Text style={styles.summaryLabel}>Plan amount</Text>
//           <Text style={styles.summaryValue}>
//             {formatMoney(amounts.planAmount)}
//           </Text>
//         </View>

//         <View style={styles.summaryRow}>
//           <Text style={styles.summaryLabel}>Discount</Text>
//           <Text style={styles.summaryValue}>
//             - {formatMoney(amounts.discountAmount)}
//           </Text>
//         </View>

//         <View style={styles.summaryRow}>
//           <Text style={styles.summaryLabel}>Final</Text>
//           <Text style={[styles.summaryValue, {fontWeight: '800'}]}>
//             {formatMoney(amounts.finalAmount)}
//           </Text>
//         </View>

//         <View style={styles.summaryRow}>
//           <Text style={styles.summaryLabel}>Paid</Text>
//           <Text style={[styles.summaryValue, {color: COLORS.success}]}>
//             {formatMoney(amounts.paidAmount)}
//           </Text>
//         </View>

//         <View style={styles.summaryRow}>
//           <Text style={styles.summaryLabel}>Due</Text>
//           <Text
//             style={[
//               styles.summaryValue,
//               {color: amounts.dueAmount > 0 ? COLORS.danger : COLORS.success},
//             ]}>
//             {formatMoney(amounts.dueAmount)}
//           </Text>
//         </View>
//       </View>

//       <Pressable
//         style={[styles.submit, submitting && {opacity: 0.6}]}
//         onPress={submit}
//         disabled={submitting}>
//         {submitting ? (
//           <ActivityIndicator color={COLORS.white} />
//         ) : (
//           <Text style={styles.submitText}>Create Membership</Text>
//         )}
//       </Pressable>
//     </View>
//   );

//   if (loadingLookups) {
//     return (
//       <View style={styles.loader}>
//         <ActivityIndicator size="large" color={COLORS.primary} />
//       </View>
//     );
//   }

//   return (
//     <ScrollView
//       style={styles.screen}
//       contentContainerStyle={styles.content}
//       keyboardShouldPersistTaps="handled">
//       <Text style={styles.title}>New Membership</Text>
//       <Text style={styles.subtitle}>
//         Assign a plan and seat to a student
//       </Text>

//       {renderStudentPicker()}

//       {step >= 2 && selectedStudent && renderPlanPicker()}

//       {step >= 3 && selectedPlan && renderSeatPicker()}

//       {step >= 4 && renderConfirm()}
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   screen: {flex: 1, backgroundColor: COLORS.background},
//   content: {padding: 20, paddingBottom: 60},
//   title: {fontSize: 26, fontWeight: '800', color: COLORS.text},
//   subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
//   sectionTitle: {
//     fontSize: 15, fontWeight: '800', color: COLORS.text,
//     marginTop: 24, marginBottom: 10,
//   },
//   input: {
//     height: 48, backgroundColor: COLORS.white,
//     borderRadius: 12, borderWidth: 1, borderColor: COLORS.border,
//     paddingHorizontal: 14, color: COLORS.text, fontSize: 14,
//   },
//   fieldLabel: {
//     color: COLORS.textSecondary, fontSize: 12,
//     marginTop: 14, marginBottom: 6, fontWeight: '600',
//   },
//   pickRow: {
//     backgroundColor: COLORS.white, borderRadius: 12,
//     padding: 12, marginBottom: 8,
//     borderWidth: 1, borderColor: COLORS.border,
//     flexDirection: 'row', alignItems: 'center',
//   },
//   pickRowActive: {
//     borderColor: COLORS.primary, backgroundColor: '#EFF6FF',
//   },
//   pickLeft: {flex: 1},
//   pickTitle: {fontSize: 14, fontWeight: '700', color: COLORS.text},
//   pickSub: {fontSize: 11, color: COLORS.textSecondary, marginTop: 3},
//   tick: {color: COLORS.primary, fontSize: 18, fontWeight: '800'},
//   emptyPick: {
//     color: COLORS.textSecondary, fontSize: 12,
//     paddingVertical: 10, textAlign: 'center',
//   },
//   seatGrid: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
//   seatChip: {
//     paddingVertical: 10, paddingHorizontal: 14,
//     borderRadius: 10, borderWidth: 1, borderColor: COLORS.border,
//     backgroundColor: COLORS.white,
//   },
//   seatChipActive: {
//     backgroundColor: COLORS.primary, borderColor: COLORS.primary,
//   },
//   seatText: {color: COLORS.text, fontWeight: '700', fontSize: 12},
//   seatTextActive: {color: COLORS.white},
//   skipButton: {
//     marginTop: 14, padding: 12, borderRadius: 10,
//     borderWidth: 1, borderColor: COLORS.border,
//     alignItems: 'center',
//   },
//   skipText: {color: COLORS.textSecondary, fontSize: 12, fontWeight: '600'},
//   summary: {
//     marginTop: 20, padding: 14, borderRadius: 14,
//     backgroundColor: COLORS.white, borderWidth: 1,
//     borderColor: COLORS.border,
//   },
//   summaryRow: {
//     flexDirection: 'row', justifyContent: 'space-between',
//     paddingVertical: 5,
//   },
//   summaryLabel: {color: COLORS.textSecondary, fontSize: 13},
//   summaryValue: {color: COLORS.text, fontSize: 13, fontWeight: '700'},
//   submit: {
//     marginTop: 24, height: 52, borderRadius: 14,
//     backgroundColor: COLORS.primary,
//     alignItems: 'center', justifyContent: 'center',
//   },
//   submitText: {color: COLORS.white, fontWeight: '800', fontSize: 15},
//   loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
// });

// export default AddMembershipScreen;
import React, {useEffect, useMemo, useState} from 'react';

import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Keyboard
} from 'react-native';

import {getStudentsApi} from '../../api/students';
import {getFeePlansApi} from '../../api/fees';
import {getAvailableSeatsApi} from '../../api/seats';
import {createMembershipApi} from '../../api/memberships';

import {COLORS} from '../../constants/colors';

const toDateString = date => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;

const SLOT_LABELS = {
  FULL_TIME: 'Full Time',
  HALF_MORNING: 'Half Morning',
  HALF_EVENING: 'Half Evening',
};

const SLOT_TIMES = {
  FULL_TIME: '08:00 – 22:00',
  HALF_MORNING: '08:00 – 14:00',
  HALF_EVENING: '14:00 – 22:00',
};

const SlotBadge = ({slot}) => {
  if (!slot) return null;
  const color =
    slot === 'FULL_TIME'
      ? COLORS.primary
      : slot === 'HALF_MORNING'
      ? COLORS.warning
      : COLORS.purple;
  const bg =
    slot === 'FULL_TIME'
      ? '#DBEAFE'
      : slot === 'HALF_MORNING'
      ? COLORS.warningBg
      : COLORS.purpleBg;
  return (
    <View style={[badgeStyles.wrap, {backgroundColor: bg}]}>
      <Text style={[badgeStyles.text, {color}]}>
        {SLOT_LABELS[slot]}
      </Text>
    </View>
  );
};

const badgeStyles = StyleSheet.create({
  wrap: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  text: {fontSize: 10, fontWeight: '800'},
});

const AddMembershipScreen = ({navigation, route}) => {
//   const initialStudentId = route?.params?.studentId;
  const initialStudentId = route?.params?.studentId;
  const initialSeatId = route?.params?.seatId; // 👈 Add this
  const suggestedSlot = route?.params?.suggestedSlot; // 👈 Catch it


  const [students, setStudents] = useState([]);
  const [plans, setPlans] = useState([]);
  const [seats, setSeats] = useState([]);

  const [loadingLookups, setLoadingLookups] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [studentSearch, setStudentSearch] = useState('');
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [selectedSeat, setSelectedSeat] = useState(null);

  const [startDate, setStartDate] = useState(toDateString(new Date()));
  const [discount, setDiscount] = useState('0');
  const [paid, setPaid] = useState('0');

  const [step, setStep] = useState(1);

  // -------- load students + plans --------
  useEffect(() => {
    const load = async () => {
      try {
        const [studentsRes, plansRes] = await Promise.all([
          getStudentsApi({status: 'ACTIVE'}),
          getFeePlansApi({status: 'ACTIVE'}),
        ]);

        if (studentsRes?.status?.code === 200) {
          const list = studentsRes.data || [];
          setStudents(list);

          if (initialStudentId) {
            const found = list.find(
              s => Number(s.id) === Number(initialStudentId),
            );
            if (found) {
              setSelectedStudent(found);
              setStep(2);
            }
          }
        }

        if (plansRes?.status?.code === 200) {
          setPlans(plansRes.data || []);
        }
      } catch (error) {
        console.log('Lookup error:', error);
      } finally {
        setLoadingLookups(false);
      }
    };
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // -------- load available seats for the selected plan's slot --------
//   useEffect(() => {
//     const loadSeats = async () => {
//       if (!selectedStudent || !selectedPlan) {
//         setSeats([]);
//         return;
//       }

//       try {
//         const res = await getAvailableSeatsApi(
//           selectedStudent.gender || 'ANY',
//           selectedPlan.slot_type || 'FULL_TIME',
//         );
//         if (res?.status?.code === 200) {
//           setSeats(res.data || []);
//         }
//       } catch (error) {
//         console.log('Seats error:', error);
//       }
//     };
//     loadSeats();
//   }, [selectedStudent, selectedPlan]);

  // -------- load available seats for the selected plan's slot --------
  useEffect(() => {
    const loadSeats = async () => {
      if (!selectedStudent || !selectedPlan) {
        setSeats([]);
        return;
      }

      try {
        const res = await getAvailableSeatsApi(
          selectedStudent.gender || 'ANY',
          selectedPlan.slot_type || 'FULL_TIME',
        );
        if (res?.status?.code === 200) {
          const fetchedSeats = res.data || [];
          setSeats(fetchedSeats);

          // 👉 NEW: Auto-select the initial seat if it exists
          if (initialSeatId) {
            const match = fetchedSeats.find(
              s => Number(s.id) === Number(initialSeatId),
            );
            if (match) {
              setSelectedSeat(match);
              setStep(4); // Auto jump to final step
            }
          }
        }
      } catch (error) {
        console.log('Seats error:', error);
      }
    };
    loadSeats();
  }, [selectedStudent, selectedPlan, initialSeatId]);


  // -------- amounts --------
  const amounts = useMemo(() => {
    const planAmount = Number(selectedPlan?.amount || 0);
    const discountAmount = Math.max(0, Number(discount || 0));
    const finalAmount = Math.max(0, planAmount - discountAmount);
    const paidAmount = Math.max(0, Number(paid || 0));
    const dueAmount = Math.max(0, finalAmount - paidAmount);
    return {planAmount, discountAmount, finalAmount, paidAmount, dueAmount};
  }, [selectedPlan, discount, paid]);

  const submit = async () => {
    if (!selectedStudent) return Alert.alert('Missing', 'Select a student.');
    if (!selectedPlan) return Alert.alert('Missing', 'Select a fee plan.');
    if (amounts.paidAmount > amounts.finalAmount) {
      return Alert.alert('Invalid', 'Paid exceeds final amount.');
    }

    try {
      setSubmitting(true);

      const response = await createMembershipApi({
        student_id: selectedStudent.id,
        fee_plan_id: selectedPlan.id,
        seat_id: selectedSeat?.id || null,
        joining_date: startDate,
        start_date: startDate,
        discount_amount: amounts.discountAmount,
        paid_amount: amounts.paidAmount,
        remarks: null,
      });

      if (response?.status?.code === 200) {
        Alert.alert(
          'Membership created',
          `Slot: ${SLOT_LABELS[response.data.slot_type] || ''}\n` +
            `Expiry: ${response.data.expiry_date}\n` +
            `Due: ${formatMoney(response.data.due_amount)}`,
          [{text: 'OK', onPress: () => navigation.goBack()}],
        );
      } else {
        Alert.alert(
          'Failed',
          response?.status?.message || 'Could not create membership',
        );
      }
    } catch (error) {
      Alert.alert(
        'Failed',
        error?.response?.data?.status?.message || 'Something went wrong',
      );
    } finally {
      setSubmitting(false);
    }
  };

  // ---------- render blocks ----------

  // const renderStudentPicker = () => {
  //   const filtered = students.filter(s => {
  //     if (!studentSearch) return true;
  //     const q = studentSearch.toLowerCase();
  //     return (
  //       s.full_name?.toLowerCase().includes(q) ||
  //       s.mobile?.includes(q) ||
  //       s.student_code?.toLowerCase().includes(q)
  //     );
  //   });

  //   return (
  //     <View>
  //       <Text style={styles.sectionTitle}>1. Select Student</Text>

  //       <TextInput
  //         value={studentSearch}
  //         onChangeText={setStudentSearch}
  //         placeholder="Search by name, mobile, code"
  //         placeholderTextColor={COLORS.textLight}
  //         style={styles.input}
  //         autoCorrect={false}
  //         autoCapitalize="none"
  //       />

  //       <FlatList
  //         data={filtered}
  //         keyExtractor={item => String(item.id)}
  //         scrollEnabled={false}
  //         renderItem={({item}) => {
  //           const selected = selectedStudent?.id === item.id;
  //           return (
  //             <Pressable
  //               style={[styles.pickRow, selected && styles.pickRowActive]}
  //               onPress={() => {
  //                 setSelectedStudent(item);
  //                 setSelectedSeat(null);
  //                 setSelectedPlan(null);
  //                 setStep(2);
  //               }}>
  //               <View style={styles.pickLeft}>
  //                 <Text style={styles.pickTitle}>{item.full_name}</Text>
  //                 <Text style={styles.pickSub}>
  //                   {item.student_code} • {item.mobile} • {item.gender}
  //                 </Text>
  //               </View>
  //               {selected && <Text style={styles.tick}>✓</Text>}
  //             </Pressable>
  //           );
  //         }}
  //         ListEmptyComponent={
  //           <Text style={styles.emptyPick}>No matching students.</Text>
  //         }
  //       />
  //     </View>
  //   );
  // };

  const renderStudentPicker = () => {
    const filtered = students.filter(s => {
      if (!studentSearch) return true;
      const q = studentSearch.toLowerCase();
      return (
        s.full_name?.toLowerCase().includes(q) ||
        s.mobile?.includes(q) ||
        s.student_code?.toLowerCase().includes(q)
      );
    });

    return (
      <View>
        <Text style={styles.sectionTitle}>1. Select Student</Text>

        <TextInput
          value={studentSearch}
          onChangeText={setStudentSearch}
          placeholder="Search by name, mobile, code"
          placeholderTextColor={COLORS.textLight}
          style={styles.input}
          autoCorrect={false}
          autoCapitalize="none"
        />

        {/* 👉 Replaced FlatList with ScrollView + maxHeight */}
        <ScrollView
          style={styles.studentListWrapper}
          nestedScrollEnabled={true}
          showsVerticalScrollIndicator={true}
          keyboardShouldPersistTaps="handled">
          
          {filtered.length === 0 ? (
            <Text style={styles.emptyPick}>No matching students.</Text>
          ) : (
            filtered.map(item => {
              const selected = selectedStudent?.id === item.id;
              return (
                <Pressable
                  key={String(item.id)}
                  style={[styles.pickRow, selected && styles.pickRowActive]}
                  onPress={() => {
                    setSelectedStudent(item);
                    setSelectedSeat(null);
                    setSelectedPlan(null);
                    setStep(2);
                    Keyboard.dismiss();
                  }}>
                  <View style={styles.pickLeft}>
                    <Text style={styles.pickTitle}>{item.full_name}</Text>
                    <Text style={styles.pickSub}>
                      {item.student_code} • {item.mobile} • {item.gender}
                    </Text>
                  </View>
                  {selected && <Text style={styles.tick}>✓</Text>}
                </Pressable>
              );
            })
          )}
        </ScrollView>
      </View>
    );
  };


//   const renderPlanPicker = () => {
//     // group by slot_type so the chip is easy to scan
//     const grouped = {
//       FULL_TIME: [],
//       HALF_MORNING: [],
//       HALF_EVENING: [],
//     };
//     plans.forEach(p => {
//       const key = p.slot_type || 'FULL_TIME';
//       if (!grouped[key]) grouped[key] = [];
//       grouped[key].push(p);
//     });

//     return (
//       <View style={{marginTop: 24}}>
//         <Text style={styles.sectionTitle}>2. Select Fee Plan</Text>

//         {Object.keys(grouped).map(slot => {
//           if (grouped[slot].length === 0) return null;
//           return (
//             <View key={slot} style={{marginBottom: 14}}>
//               <View style={styles.slotHeader}>
//                 <SlotBadge slot={slot} />
//                 <Text style={styles.slotTime}>
//                   {SLOT_TIMES[slot]}
//                 </Text>
//               </View>

//               {grouped[slot].map(plan => {
//                 const selected = selectedPlan?.id === plan.id;
//                 return (
//                   <Pressable
//                     key={plan.id}
//                     style={[styles.pickRow, selected && styles.pickRowActive]}
//                     onPress={() => {
//                       setSelectedPlan(plan);
//                       setSelectedSeat(null);
//                       setStep(3);
//                     }}>
//                     <View style={styles.pickLeft}>
//                       <Text style={styles.pickTitle}>{plan.plan_name}</Text>
//                       <Text style={styles.pickSub}>
//                         {plan.duration_days} days • {formatMoney(plan.amount)}
//                       </Text>
//                     </View>
//                     {selected && <Text style={styles.tick}>✓</Text>}
//                   </Pressable>
//                 );
//               })}
//             </View>
//           );
//         })}
//       </View>
//     );
//   };

  const renderPlanPicker = () => {
    const grouped = { FULL_TIME: [], HALF_MORNING: [], HALF_EVENING: [] };
    plans.forEach(p => {
      const key = p.slot_type || 'FULL_TIME';
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(p);
    });

    return (
      <View style={{marginTop: 2}}>
        <Text style={styles.sectionTitle}>2. Select Fee Plan</Text>
        
        {/* Optional: Add a note if a slot was suggested */}
        {suggestedSlot && (
          <Text style={{color: COLORS.purple, fontSize: 12, fontWeight: '700', marginBottom: 10}}>
            Showing {suggestedSlot === 'HALF_MORNING' ? 'Morning' : 'Evening'} plans for this seat.
          </Text>
        )}

        {Object.keys(grouped).map(slot => {
          if (grouped[slot].length === 0) return null;
          
          // If we have a suggestion, visually dim the other slots
          const isSuggested = suggestedSlot === slot;
          const isDimmed = suggestedSlot && !isSuggested;

          return (
            <View key={slot} style={{marginBottom: 4, opacity: isDimmed ? 0.4 : 1}}>
              <View style={styles.slotHeader}>
                <SlotBadge slot={slot} />
                <Text style={styles.slotTime}>{SLOT_TIMES[slot]}</Text>
              </View>

              {grouped[slot].map(plan => {
                const selected = selectedPlan?.id === plan.id;
                return (
                  <Pressable
                    key={plan.id}
                    style={[styles.pickRow, selected && styles.pickRowActive]}
                    onPress={() => {
                      setSelectedPlan(plan);
                      setSelectedSeat(null);
                      setStep(3);
                    }}>
                    <View style={styles.pickLeft}>
                      <Text style={styles.pickTitle}>{plan.plan_name} 
                      <Text style={styles.pickSub}>
                        ({plan.duration_days} days • {formatMoney(plan.amount)})</Text>
                        </Text>
                      {/* <Text style={styles.pickSub}>
                        {plan.duration_days} days • {formatMoney(plan.amount)}
                      </Text> */}
                    </View>
                    {selected && <Text style={styles.tick}>✓</Text>}
                  </Pressable>
                );
              })}
            </View>
          );
        })}
      </View>
    );
  };

  
  const renderSeatPicker = () => (
    <View style={{marginTop: 2}}>
      <View style={styles.sectionHeadRow}>
        <Text style={styles.sectionTitle}>3. Select Seat (optional)</Text>
        <SlotBadge slot={selectedPlan?.slot_type} />
      </View>

      {seats.length === 0 ? (
        <View style={styles.infoBox}>
          <Text style={styles.infoBoxText}>
            No {SLOT_LABELS[selectedPlan?.slot_type]} seats available for{' '}
            {selectedStudent?.gender?.toLowerCase()} students.
          </Text>
          <Text style={styles.infoBoxSub}>
            You can skip and assign a seat later, or change the plan slot.
          </Text>
        </View>
      ) : (
        <View style={styles.seatGrid}>
          {seats.map(seat => {
            const selected = selectedSeat?.id === seat.id;
            return (
              <Pressable
                key={seat.id}
                style={[styles.seatChip, selected && styles.seatChipActive]}
                onPress={() => setSelectedSeat(selected ? null : seat)}>
                <Text
                  style={[
                    styles.seatText,
                    selected && styles.seatTextActive,
                  ]}>
                  {seat.seat_number}
                </Text>
              </Pressable>
            );
          })}
        </View>
      )}

      <Pressable
        style={styles.skipButton}
        onPress={() => {
          setSelectedSeat(null);
          setStep(4);
        }}>
        <Text style={styles.skipText}>
          {selectedSeat ? 'Continue without changing seat' : 'Skip seat'}
        </Text>
      </Pressable>

      {selectedSeat && (
        <Pressable
          style={styles.continueButton}
          onPress={() => setStep(4)}>
          <Text style={styles.continueText}>
            Continue with {selectedSeat.seat_number}
          </Text>
        </Pressable>
      )}
    </View>
  );

    const renderConfirm = () => (
    <View style={{marginTop: 24}}>
      <Text style={styles.sectionTitle}>4. Confirm Dates</Text>

      <View style={styles.slotSummary}>
        <View>
          <Text style={styles.slotSummaryLabel}>SELECTED SLOT</Text>
          <Text style={styles.slotSummaryValue}>
            {SLOT_LABELS[selectedPlan?.slot_type]}
          </Text>
        </View>
        <Text style={styles.slotSummaryTime}>
          {SLOT_TIMES[selectedPlan?.slot_type]}
        </Text>
      </View>

      <Text style={styles.fieldLabel}>Start Date (YYYY-MM-DD)</Text>
      <TextInput
        value={startDate}
        onChangeText={setStartDate}
        style={styles.input}
        autoCapitalize="none"
        autoCorrect={false}
      />

      <View style={styles.summary}>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Plan amount (Due)</Text>
          <Text style={[styles.summaryValue, {color: COLORS.danger}]}>
            {formatMoney(amounts.planAmount)}
          </Text>
        </View>
      </View>

      <Pressable
        style={[styles.submit, submitting && {opacity: 0.6}]}
        onPress={submit}
        disabled={submitting}>
        {submitting ? (
          <ActivityIndicator color={COLORS.white} />
        ) : (
          <Text style={styles.submitText}>Create Membership & Pay</Text>
        )}
      </Pressable>
    </View>
  );

  // const renderConfirm = () => (
  //   <View style={{marginTop: 24}}>
  //     <Text style={styles.sectionTitle}>4. Dates & Payment</Text>

  //     <View style={styles.slotSummary}>
  //       <View>
  //         <Text style={styles.slotSummaryLabel}>SELECTED SLOT</Text>
  //         <Text style={styles.slotSummaryValue}>
  //           {SLOT_LABELS[selectedPlan?.slot_type]}
  //         </Text>
  //       </View>
  //       <Text style={styles.slotSummaryTime}>
  //         {SLOT_TIMES[selectedPlan?.slot_type]}
  //       </Text>
  //     </View>

  //     <Text style={styles.fieldLabel}>Start Date (YYYY-MM-DD)</Text>
  //     <TextInput
  //       value={startDate}
  //       onChangeText={setStartDate}
  //       style={styles.input}
  //       autoCapitalize="none"
  //       autoCorrect={false}
  //     />

  //     {/* <Text style={styles.fieldLabel}>Discount (₹)</Text>
  //     <TextInput
  //       value={discount}
  //       onChangeText={setDiscount}
  //       style={styles.input}
  //       keyboardType="numeric"
  //     />

  //     <Text style={styles.fieldLabel}>Paid Now (₹)</Text>
  //     <TextInput
  //       value={paid}
  //       onChangeText={setPaid}
  //       style={styles.input}
  //       keyboardType="numeric"
  //     /> */}

  //     {/* <View style={styles.summary}>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Plan amount</Text>
  //         <Text style={styles.summaryValue}>
  //           {formatMoney(amounts.planAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Discount</Text>
  //         <Text style={styles.summaryValue}>
  //           - {formatMoney(amounts.discountAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Final</Text>
  //         <Text style={[styles.summaryValue, {fontWeight: '800'}]}>
  //           {formatMoney(amounts.finalAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Paid</Text>
  //         <Text style={[styles.summaryValue, {color: COLORS.success}]}>
  //           {formatMoney(amounts.paidAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Due</Text>
  //         <Text
  //           style={[
  //             styles.summaryValue,
  //             {
  //               color:
  //                 amounts.dueAmount > 0 ? COLORS.danger : COLORS.success,
  //             },
  //           ]}>
  //           {formatMoney(amounts.dueAmount)}
  //         </Text>
  //       </View>
  //     </View> */}
  //           <Text style={styles.fieldLabel}>Paid Now (₹)</Text>
  //     <TextInput
  //       value={paid}
  //       onChangeText={setPaid}
  //       style={styles.input}
  //       keyboardType="numeric"
  //       placeholder="0"
  //     />

  //     <View style={styles.summary}>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Plan amount</Text>
  //         <Text style={styles.summaryValue}>
  //           {formatMoney(amounts.planAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Discount</Text>
  //         <Text style={styles.summaryValue}>
  //           - {formatMoney(amounts.discountAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Final</Text>
  //         <Text style={[styles.summaryValue, {fontWeight: '800'}]}>
  //           {formatMoney(amounts.finalAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Paid</Text>
  //         <Text style={[styles.summaryValue, {color: COLORS.success}]}>
  //           {formatMoney(amounts.paidAmount)}
  //         </Text>
  //       </View>
  //       <View style={styles.summaryRow}>
  //         <Text style={styles.summaryLabel}>Due</Text>
  //         <Text
  //           style={[
  //             styles.summaryValue,
  //             {color: amounts.dueAmount > 0 ? COLORS.danger : COLORS.success},
  //           ]}>
  //           {formatMoney(amounts.dueAmount)}
  //         </Text>
  //       </View>
  //     </View>


  //     <Pressable
  //       style={[styles.submit, submitting && {opacity: 0.6}]}
  //       onPress={submit}
  //       disabled={submitting}>
  //       {submitting ? (
  //         <ActivityIndicator color={COLORS.white} />
  //       ) : (
  //         <Text style={styles.submitText}>Create Membership</Text>
  //       )}
  //     </Pressable>
  //   </View>
  // );

  if (loadingLookups) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled">
      <Text style={styles.title}>New Membership</Text>
      {/* <Text style={styles.subtitle}>
        Assign a plan and seat to a student
      </Text> */}

      {renderStudentPicker()}
      {step >= 2 && selectedStudent && renderPlanPicker()}
      {step >= 3 && selectedPlan && renderSeatPicker()}
      {step >= 4 && renderConfirm()}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  content: {padding: 20, paddingBottom: 60},
  title: {fontSize: 26, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
  sectionTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
    marginTop: 24,
    marginBottom: 10,
  },
  sectionHeadRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 2,
    marginBottom: 10,
  },
  slotHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  slotTime: {color: COLORS.textSecondary, fontSize: 11, fontWeight: '600'},
  input: {
    height: 48,
    backgroundColor: COLORS.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 14,
    color: COLORS.text,
    fontSize: 14,
    marginBottom:5
  },
  fieldLabel: {
    color: COLORS.textSecondary,
    fontSize: 12,
    marginTop: 14,
    marginBottom: 6,
    fontWeight: '600',
  },
  pickRow: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
    flexDirection: 'row',
    alignItems: 'center',
  },
  pickRowActive: {
    borderColor: COLORS.primary,
    backgroundColor: '#EFF6FF',
  },
  pickLeft: {flex: 1},
  pickTitle: {fontSize: 14, fontWeight: '700', color: COLORS.text},
  pickSub: {fontSize: 11, color: COLORS.textSecondary, marginTop: 3},
  tick: {color: COLORS.primary, fontSize: 18, fontWeight: '800'},
  emptyPick: {
    color: COLORS.textSecondary,
    fontSize: 12,
    paddingVertical: 10,
    textAlign: 'center',
  },
  seatGrid: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
  seatChip: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.white,
    minWidth: 60,
    alignItems: 'center',
  },
  seatChipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  seatText: {color: COLORS.text, fontWeight: '700', fontSize: 12},
  seatTextActive: {color: COLORS.white},
  skipButton: {
    marginTop: 14,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
  },
  skipText: {color: COLORS.textSecondary, fontSize: 12, fontWeight: '600'},
  continueButton: {
    marginTop: 10,
    padding: 14,
    borderRadius: 12,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
  },
  continueText: {color: COLORS.white, fontWeight: '800', fontSize: 13},
  infoBox: {
    padding: 14,
    backgroundColor: COLORS.warningBg,
    borderRadius: 12,
  },
  infoBoxText: {
    color: COLORS.warning,
    fontSize: 13,
    fontWeight: '700',
  },
  infoBoxSub: {color: COLORS.textSecondary, fontSize: 11, marginTop: 4},
  slotSummary: {
    marginTop: 10,
    padding: 14,
    borderRadius: 12,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  slotSummaryLabel: {
    fontSize: 10,
    color: COLORS.textSecondary,
    letterSpacing: 1,
    fontWeight: '700',
  },
  slotSummaryValue: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
    marginTop: 3,
  },
  slotSummaryTime: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  summary: {
    marginTop: 20,
    padding: 14,
    borderRadius: 14,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5,
  },
  summaryLabel: {color: COLORS.textSecondary, fontSize: 13},
  summaryValue: {color: COLORS.text, fontSize: 13, fontWeight: '700'},
  submit: {
    marginTop: 24,
    height: 52,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitText: {color: COLORS.white, fontWeight: '800', fontSize: 15},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
    studentListWrapper: {
    maxHeight: 250, // Prevents the list from taking over the whole screen
    marginTop: 8,
  },
});

export default AddMembershipScreen;