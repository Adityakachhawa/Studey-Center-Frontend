export const COLORS = {
  primary: '#2563EB',
  primaryDark: '#1D4ED8',

  background: '#F7F8FA',
  surface: '#FFFFFF',

  text: '#111827',
  textSecondary: '#6B7280',
  textLight: '#9CA3AF',

  border: '#E5E7EB',

  success: '#16A34A',
  successBg: '#DCFCE7',

  warning: '#D97706',
  warningBg: '#FEF3C7',

  danger: '#DC2626',
  dangerBg: '#FEE2E2',

  purple: '#7C3AED',
  purpleBg: '#EDE9FE',

  black: '#000000',
  white: '#FFFFFF',
};