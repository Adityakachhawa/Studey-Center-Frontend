// import api from './api';

// export const getMonthlyReportApi = async month => {
//   const response = await api.get('/api/reports/monthly', {
//     params: {
//       month,
//     },
//   });

//   return response.data;
// };

// export const getPaymentMethodReportApi = async month => {
//   const response = await api.get(
//     '/api/reports/payment-methods',
//     {
//       params: {
//         month,
//       },
//     },
//   );

//   return response.data;
// };

// export const getExpenseReportApi = async month => {
//   const response = await api.get(
//     '/api/reports/expenses',
//     {
//       params: {
//         month,
//       },
//     },
//   );

//   return response.data;
// };
import api from './api';

export const getMonthlyReportApi = async (params) => {
  const response = await api.get('/api/reports/monthly', {params});
  return response.data;
};

export const getPaymentMethodReportApi = async (params) => {
  const response = await api.get('/api/reports/payment-methods', {params});
  return response.data;
};

export const getExpenseReportApi = async (params) => {
  const response = await api.get('/api/reports/expenses', {params});
  return response.data;
};