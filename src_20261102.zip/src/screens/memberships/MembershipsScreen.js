// import React, {useCallback, useState} from 'react';

// import {
//   ActivityIndicator,
//   FlatList,
//   Pressable,
//   RefreshControl,
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {getMembershipsApi} from '../../api/memberships';

// import {COLORS} from '../../constants/colors';

// const formatDate = value => {
//   if (!value) return '—';

//   return String(value).slice(0, 10);
// };

// const formatMoney = value => {
//   const number = Number(value || 0);

//   return `₹${number.toLocaleString('en-IN')}`;
// };

// const MembershipsScreen = ({navigation}) => {
//   const [memberships, setMemberships] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);

//   const loadMemberships = useCallback(async (showLoader = false) => {
//     if (showLoader) setLoading(true);

//     try {
//       const response = await getMembershipsApi({});

//       if (response?.status?.code === 200) {
//         setMemberships(response.data || []);
//       }
//     } catch (error) {
//       console.log('Memberships error:', error);
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
//   }, []);

//   useFocusEffect(
//     useCallback(() => {
//       loadMemberships(memberships.length === 0);
//       // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, []),
//   );

//   const onRefresh = () => {
//     setRefreshing(true);
//     loadMemberships();
//   };

//   const renderMembership = ({item}) => {
//     const isActive = item.status === 'ACTIVE';

//     const hasDue = Number(item.due_amount || 0) > 0;

//     return (
//       <View style={styles.card}>
//         <View style={styles.topRow}>
//           <View style={styles.avatar}>
//             <Text style={styles.avatarText}>
//               {item.full_name?.charAt(0)?.toUpperCase() || 'S'}
//             </Text>
//           </View>

//           <View style={styles.info}>
//             <Text style={styles.name} numberOfLines={1}>
//               {item.full_name}
//             </Text>

//             <Text style={styles.code}>{item.student_code}</Text>

//             <Text style={styles.plan}>{item.plan_name}</Text>
//           </View>

//           <View
//             style={[
//               styles.status,
//               isActive ? styles.active : styles.inactive,
//             ]}>
//             <Text
//               style={[
//                 styles.statusText,
//                 isActive && styles.activeText,
//               ]}>
//               {item.status}
//             </Text>
//           </View>
//         </View>

//         <View style={styles.divider} />

//         <View style={styles.row}>
//           <View style={styles.col}>
//             <Text style={styles.label}>Seat</Text>
//             <Text style={styles.value}>{item.seat_number || '—'}</Text>
//           </View>

//           <View style={styles.col}>
//             <Text style={styles.label}>Start</Text>
//             <Text style={styles.value}>{formatDate(item.start_date)}</Text>
//           </View>

//           <View style={styles.col}>
//             <Text style={styles.label}>Expiry</Text>
//             <Text style={styles.value}>{formatDate(item.expiry_date)}</Text>
//           </View>
//         </View>

//         <View style={styles.row}>
//           <View style={styles.col}>
//             <Text style={styles.label}>Total</Text>
//             <Text style={styles.value}>
//               {formatMoney(item.final_amount)}
//             </Text>
//           </View>

//           <View style={styles.col}>
//             <Text style={styles.label}>Paid</Text>
//             <Text style={[styles.value, {color: COLORS.success}]}>
//               {formatMoney(item.paid_amount)}
//             </Text>
//           </View>

//           <View style={styles.col}>
//             <Text style={styles.label}>Due</Text>
//             <Text
//               style={[
//                 styles.value,
//                 {color: hasDue ? COLORS.danger : COLORS.textSecondary},
//               ]}>
//               {formatMoney(item.due_amount)}
//             </Text>
//           </View>
//         </View>
//       </View>
//     );
//   };

//   return (
//     <View style={styles.screen}>
//       <View style={styles.header}>
//         <View>
//           <Text style={styles.title}>Memberships</Text>
//           <Text style={styles.subtitle}>
//             Active & past student subscriptions
//           </Text>
//         </View>

//         <Pressable
//           style={styles.addButton}
//           onPress={() => navigation.navigate('AddMembership')}>
//           <Text style={styles.addText}>+</Text>
//         </Pressable>
//       </View>

//       {loading ? (
//         <View style={styles.loader}>
//           <ActivityIndicator size="large" color={COLORS.primary} />
//         </View>
//       ) : (
//         <FlatList
//           data={memberships}
//           keyExtractor={item => String(item.id)}
//           renderItem={renderMembership}
//           contentContainerStyle={styles.list}
//           refreshControl={
//             <RefreshControl
//               refreshing={refreshing}
//               onRefresh={onRefresh}
//             />
//           }
//           ListEmptyComponent={
//             <View style={styles.empty}>
//               <Text style={styles.emptyTitle}>No memberships yet</Text>
//               <Text style={styles.emptyText}>
//                 Create a membership to assign a fee plan and a seat.
//               </Text>
//             </View>
//           }
//         />
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   screen: {flex: 1, backgroundColor: COLORS.background},
//   header: {
//     paddingHorizontal: 20,
//     paddingTop: 20,
//     paddingBottom: 16,
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//   },
//   title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
//   subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
//   addButton: {
//     width: 46, height: 46, borderRadius: 14,
//     backgroundColor: COLORS.primary,
//     alignItems: 'center', justifyContent: 'center',
//   },
//   addText: {
//     color: COLORS.white, fontSize: 28,
//     lineHeight: 30, fontWeight: '400',
//   },
//   list: {padding: 20, paddingTop: 5, paddingBottom: 40},
//   card: {
//     backgroundColor: COLORS.white, borderRadius: 17,
//     padding: 14, marginBottom: 12,
//     borderWidth: 1, borderColor: COLORS.border,
//   },
//   topRow: {flexDirection: 'row', alignItems: 'center'},
//   avatar: {
//     width: 44, height: 44, borderRadius: 14,
//     backgroundColor: '#DBEAFE',
//     alignItems: 'center', justifyContent: 'center',
//   },
//   avatarText: {color: COLORS.primary, fontSize: 17, fontWeight: '800'},
//   info: {flex: 1, marginLeft: 12, marginRight: 8},
//   name: {color: COLORS.text, fontSize: 15, fontWeight: '700'},
//   code: {color: COLORS.primary, fontSize: 11, fontWeight: '700', marginTop: 2},
//   plan: {color: COLORS.textSecondary, fontSize: 12, marginTop: 2},
//   status: {borderRadius: 20, paddingHorizontal: 8, paddingVertical: 5},
//   active: {backgroundColor: COLORS.successBg},
//   inactive: {backgroundColor: COLORS.dangerBg},
//   statusText: {color: COLORS.danger, fontSize: 9, fontWeight: '800'},
//   activeText: {color: COLORS.success},
//   divider: {
//     height: 1, backgroundColor: COLORS.border, marginVertical: 12,
//   },
//   row: {flexDirection: 'row', marginBottom: 8},
//   col: {flex: 1},
//   label: {color: COLORS.textSecondary, fontSize: 11},
//   value: {color: COLORS.text, fontSize: 13, fontWeight: '700', marginTop: 3},
//   loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
//   empty: {alignItems: 'center', paddingTop: 100},
//   emptyTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text},
//   emptyText: {
//     color: COLORS.textSecondary, marginTop: 6,
//     textAlign: 'center', paddingHorizontal: 40,
//   },
// });

// export default MembershipsScreen;
import React, {useCallback, useState} from 'react';

import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {useFocusEffect} from '@react-navigation/native';

import {
  getMembershipsApi,
  cancelMembershipApi,
} from '../../api/fees';

import {COLORS} from '../../constants/colors';

const SLOT_LABELS = {
  FULL_TIME: 'Full Time',
  HALF_MORNING: 'Half Morning',
  HALF_EVENING: 'Half Evening',
};

const SLOT_COLORS = {
  FULL_TIME: {bg: '#DBEAFE', fg: COLORS.primary},
  HALF_MORNING: {bg: COLORS.warningBg, fg: COLORS.warning},
  HALF_EVENING: {bg: COLORS.purpleBg, fg: COLORS.purple},
};

const formatDate = v => (v ? String(v).slice(0, 10) : '—');
const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;

const FILTERS = [
  {key: 'ALL', label: 'All'},
  {key: 'ACTIVE', label: 'Active'},
  {key: 'EXPIRED', label: 'Expired'},
  {key: 'CANCELLED', label: 'Cancelled'},
];

const MembershipsScreen = ({navigation}) => {
  const [memberships, setMemberships] = useState([]);
  const [filter, setFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadMemberships = useCallback(async (showLoader = false) => {
    if (showLoader) setLoading(true);
    try {
      const response = await getMembershipsApi({});
      if (response?.status?.code === 200) {
        setMemberships(response.data || []);
      }
    } catch (error) {
      console.log('Memberships error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadMemberships(memberships.length === 0);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  const onRefresh = () => {
    setRefreshing(true);
    loadMemberships();
  };

  const visible = memberships.filter(m => {
    if (filter === 'ALL') return true;
    return m.status === filter;
  });

  const confirmCancel = item => {
    Alert.alert(
      'Cancel membership?',
      `Cancel ${item.full_name}'s ${SLOT_LABELS[item.slot_type] || ''} membership?`,
      [
        {text: 'No', style: 'cancel'},
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              const res = await cancelMembershipApi(item.id);
              if (res?.status?.code === 200) {
                loadMemberships();
              } else {
                Alert.alert(
                  'Failed',
                  res?.status?.message || 'Could not cancel',
                );
              }
            } catch (e) {
              Alert.alert(
                'Error',
                e?.response?.data?.status?.message || 'Could not cancel',
              );
            }
          },
        },
      ],
    );
  };

  const renderMembership = ({item}) => {
    const isActive = item.status === 'ACTIVE';
    const hasDue = Number(item.due_amount || 0) > 0;
    const slotColor = SLOT_COLORS[item.slot_type] || SLOT_COLORS.FULL_TIME;

    return (
      <View style={styles.card}>
        <View style={styles.topRow}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {item.full_name?.charAt(0)?.toUpperCase() || 'S'}
            </Text>
          </View>
          <View style={styles.info}>
            <Text style={styles.name} numberOfLines={1}>
              {item.full_name}
            </Text>
            <Text style={styles.code}>{item.student_code}</Text>
            <View style={styles.planRow}>
              <Text style={styles.plan}>{item.plan_name}</Text>
              {item.slot_type && (
                <View
                  style={[
                    styles.slotBadge,
                    {backgroundColor: slotColor.bg},
                  ]}>
                  <Text
                    style={[
                      styles.slotBadgeText,
                      {color: slotColor.fg},
                    ]}>
                    {SLOT_LABELS[item.slot_type]}
                  </Text>
                </View>
              )}
            </View>
          </View>
          <View
            style={[
              styles.status,
              isActive ? styles.active : styles.inactive,
            ]}>
            <Text
              style={[styles.statusText, isActive && styles.activeText]}>
              {item.status}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.row}>
          <View style={styles.col}>
            <Text style={styles.label}>Seat</Text>
            <Text style={styles.value}>{item.seat_number || '—'}</Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.label}>Start</Text>
            <Text style={styles.value}>{formatDate(item.start_date)}</Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.label}>Expiry</Text>
            <Text style={styles.value}>{formatDate(item.expiry_date)}</Text>
          </View>
        </View>

        <View style={styles.row}>
          <View style={styles.col}>
            <Text style={styles.label}>Total</Text>
            <Text style={styles.value}>{formatMoney(item.final_amount)}</Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.label}>Paid</Text>
            <Text style={[styles.value, {color: COLORS.success}]}>
              {formatMoney(item.paid_amount)}
            </Text>
          </View>
          <View style={styles.col}>
            <Text style={styles.label}>Due</Text>
            <Text
              style={[
                styles.value,
                {color: hasDue ? COLORS.danger : COLORS.textSecondary},
              ]}>
              {formatMoney(item.due_amount)}
            </Text>
          </View>
        </View>

        {isActive && (
          <View style={styles.actionsRow}>
            {hasDue && (
              <Pressable
                style={styles.smallActionPrimary}
                onPress={() =>
                  navigation.navigate('AddPayment', {
                    studentId: item.student_id,
                    membershipId: item.id,
                    amount: item.due_amount,
                  })
                }>
                <Text style={styles.smallActionPrimaryText}>
                  Pay ₹{Number(item.due_amount).toFixed(0)}
                </Text>
              </Pressable>
            )}
            <Pressable
              style={styles.smallActionDanger}
              onPress={() => confirmCancel(item)}>
              <Text style={styles.smallActionDangerText}>Cancel</Text>
            </Pressable>
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Memberships</Text>
          <Text style={styles.subtitle}>
            Active & past student subscriptions
          </Text>
        </View>
        <Pressable
          style={styles.addButton}
          onPress={() => navigation.navigate('AddMembership')}>
          <Text style={styles.addText}>+</Text>
        </Pressable>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterRow}>
        {FILTERS.map(f => {
          const active = filter === f.key;
          return (
            <Pressable
              key={f.key}
              style={[styles.chip, active && styles.chipActive]}
              onPress={() => setFilter(f.key)}>
              <Text
                style={[styles.chipText, active && styles.chipTextActive]}>
                {f.label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      {loading ? (
        <View style={styles.loader}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : (
        <FlatList
          data={visible}
          keyExtractor={item => String(item.id)}
          renderItem={renderMembership}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
            />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>No memberships</Text>
              <Text style={styles.emptyText}>
                Create a membership to assign a fee plan and a seat.
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
  addButton: {
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addText: {
    color: COLORS.white,
    fontSize: 28,
    lineHeight: 30,
    fontWeight: '400',
  },
  filterRow: {paddingHorizontal: 20, paddingBottom: 14, gap: 8},
  chip: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  chipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  chipText: {fontSize: 12, fontWeight: '700', color: COLORS.textSecondary},
  chipTextActive: {color: COLORS.white},
  list: {padding: 20, paddingTop: 4, paddingBottom: 40},
  card: {
    backgroundColor: COLORS.white,
    borderRadius: 17,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  topRow: {flexDirection: 'row', alignItems: 'center'},
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: '#DBEAFE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {color: COLORS.primary, fontSize: 17, fontWeight: '800'},
  info: {flex: 1, marginLeft: 12, marginRight: 8},
  name: {color: COLORS.text, fontSize: 15, fontWeight: '700'},
  code: {color: COLORS.primary, fontSize: 11, fontWeight: '700', marginTop: 2},
  planRow: {flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4},
  plan: {color: COLORS.textSecondary, fontSize: 12},
  slotBadge: {paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4},
  slotBadgeText: {fontSize: 9, fontWeight: '800'},
  status: {borderRadius: 20, paddingHorizontal: 8, paddingVertical: 5},
  active: {backgroundColor: COLORS.successBg},
  inactive: {backgroundColor: COLORS.dangerBg},
  statusText: {color: COLORS.danger, fontSize: 9, fontWeight: '800'},
  activeText: {color: COLORS.success},
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 12,
  },
  row: {flexDirection: 'row', marginBottom: 8},
  col: {flex: 1},
  label: {color: COLORS.textSecondary, fontSize: 11},
  value: {color: COLORS.text, fontSize: 13, fontWeight: '700', marginTop: 3},
  actionsRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  smallActionPrimary: {
    flex: 1,
    height: 36,
    borderRadius: 10,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  smallActionPrimaryText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '800',
  },
  smallActionDanger: {
    flex: 1,
    height: 36,
    borderRadius: 10,
    backgroundColor: COLORS.dangerBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  smallActionDangerText: {
    color: COLORS.danger,
    fontSize: 12,
    fontWeight: '800',
  },
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  empty: {alignItems: 'center', paddingTop: 100},
  emptyTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text},
  emptyText: {
    color: COLORS.textSecondary,
    marginTop: 6,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
});

export default MembershipsScreen;