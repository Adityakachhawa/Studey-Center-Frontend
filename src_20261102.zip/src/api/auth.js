import api from './api';

export const loginApi = async (mobile, password) => {
  const response = await api.post('/api/login', {
    mobile,
    password,
  });

  return response.data;
};

export const logoutApi = async () => {
  const response = await api.post('/api/logout');

  return response.data;
};

export const getMeApi = async () => {
  const response = await api.get('/api/me');

  return response.data;
};