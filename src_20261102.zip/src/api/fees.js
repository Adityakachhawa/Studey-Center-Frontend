// import api from './api';

// export const getFeePlansApi = async () => {
//   const response = await api.get('/api/fee-plans');

//   return response.data;
// };

// export const createFeePlanApi = async data => {
//   const response = await api.post('/api/fee-plans', data);

//   return response.data;
// };

// export const updateFeePlanApi = async (id, data) => {
//   const response = await api.put(`/api/fee-plans/${id}`, data);

//   return response.data;
// };

// export const getPaymentMethodsApi = async () => {
//   const response = await api.get('/api/payment-methods');

//   return response.data;
// };

// export const createPaymentMethodApi = async data => {
//   const response = await api.post('/api/payment-methods', data);

//   return response.data;
// };

// // export const getMembershipsApi = async studentId => {
// //   const response = await api.get('/api/memberships', {
// //     params: {
// //       student_id: studentId,
// //     },
// //   });

// //   return response.data;
// // };

// export const getMembershipsApi = async arg => {
//   const params =
//     arg && typeof arg === 'object'
//       ? arg
//       : arg
//       ? {student_id: arg}
//       : {};

//   const response = await api.get('/api/memberships', {params});

//   return response.data;
// };

// export const createMembershipApi = async data => {
//   const response = await api.post('/api/memberships', data);

//   return response.data;
// };
import api from './api';

export const getFeePlansApi = async () => {
  const response = await api.get('/api/fee-plans');

  return response.data;
};

export const createFeePlanApi = async data => {
  const response = await api.post('/api/fee-plans', data);

  return response.data;
};

export const updateFeePlanApi = async (id, data) => {
  const response = await api.put(`/api/fee-plans/${id}`, data);

  return response.data;
};

export const getPaymentMethodsApi = async () => {
  const response = await api.get('/api/payment-methods');

  return response.data;
};

export const createPaymentMethodApi = async data => {
  const response = await api.post('/api/payment-methods', data);

  return response.data;
};

export const getMembershipsApi = async arg => {
  const params =
    arg && typeof arg === 'object'
      ? arg
      : arg
      ? {student_id: arg}
      : {};

  const response = await api.get('/api/memberships', {params});

  return response.data;
};

export const createMembershipApi = async data => {
  const response = await api.post('/api/memberships', data);

  return response.data;
};

export const cancelMembershipApi = async membershipId => {
  const response = await api.post(
    `/api/memberships/${membershipId}/cancel`,
  );

  return response.data;
};