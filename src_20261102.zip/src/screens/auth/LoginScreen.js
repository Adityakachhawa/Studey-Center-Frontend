import React, {
  useState,
} from 'react';

import {
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import AppButton from '../../components/AppButton';
import AppInput from '../../components/AppInput';

import {COLORS} from '../../constants/colors';
import {useAuth} from '../../context/AuthContext';

const LoginScreen = () => {
  const {login} = useAuth();

  const [mobile, setMobile] =
    useState('');

  const [password, setPassword] =
    useState('');

  const [loading, setLoading] =
    useState(false);

  const [error, setError] =
    useState('');

  const handleLogin = async () => {
    if (!mobile || !password) {
      setError(
        'Please enter mobile number and password.',
      );
      return;
    }

    setError('');
    setLoading(true);

    try {
      await login(
        mobile.trim(),
        password,
      );
    } catch (e) {
      setError(
        e?.response?.data?.status
          ?.message ||
          e?.message ||
          'Unable to login.',
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView
      style={styles.safe}>
      <KeyboardAvoidingView
        behavior={
          Platform.OS === 'ios'
            ? 'padding'
            : undefined
        }
        style={styles.flex}>
        <ScrollView
          contentContainerStyle={
            styles.container
          }
          keyboardShouldPersistTaps="handled">
          <View style={styles.logo}>
            <Text style={styles.logoText}>
              S
            </Text>
          </View>

          <Text style={styles.title}>
            Welcome back
          </Text>

          <Text style={styles.subtitle}>
            Manage your study center
            from anywhere.
          </Text>

          <View style={styles.form}>
            <AppInput
              label="Mobile number"
              placeholder="Enter mobile number"
              value={mobile}
              onChangeText={setMobile}
              keyboardType="phone-pad"
            />

            <AppInput
              label="Password"
              placeholder="Enter password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />

            {error ? (
              <Text style={styles.error}>
                {error}
              </Text>
            ) : null}

            <AppButton
              title="Sign in"
              onPress={handleLogin}
              loading={loading}
            />
          </View>

          <Text style={styles.footer}>
            Study Center Manager
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  flex: {
    flex: 1,
  },

  container: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
  },

  logo: {
    width: 64,
    height: 64,
    borderRadius: 18,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 28,
  },

  logoText: {
    color: COLORS.white,
    fontSize: 28,
    fontWeight: '800',
  },

  title: {
    fontSize: 32,
    fontWeight: '800',
    color: COLORS.text,
  },

  subtitle: {
    fontSize: 15,
    lineHeight: 23,
    color: COLORS.textSecondary,
    marginTop: 8,
    marginBottom: 35,
    maxWidth: 320,
  },

  form: {
    width: '100%',
  },

  error: {
    color: COLORS.danger,
    fontSize: 13,
    marginBottom: 15,
  },

  footer: {
    textAlign: 'center',
    color: COLORS.textLight,
    marginTop: 35,
    fontSize: 12,
  },
});

export default LoginScreen;