// import api from './api';

// export const getSeatsApi = async params => {
//   const response = await api.get('/api/seats', {
//     params: params || {},
//   });

//   return response.data;
// };

// export const getSeatApi = async id => {
//   const response = await api.get(`/api/seats/${id}`);

//   return response.data;
// };

// export const updateSeatApi = async (id, data) => {
//   const response = await api.put(`/api/seats/${id}`, data);

//   return response.data;
// };

// export const createSeatApi = async data => {
//   const response = await api.post('/api/seats', data);

//   return response.data;
// };

// export const getAvailableSeatsApi = async gender => {
//   const response = await api.get('/api/seats/available', {
//     params: {gender: gender || 'ANY'},
//   });

//   return response.data;
// };
import api from './api';

export const getSeatsApi = async params => {
  const response = await api.get('/api/seats', {
    params: params || {},
  });

  return response.data;
};

export const getSeatApi = async id => {
  const response = await api.get(`/api/seats/${id}`);

  return response.data;
};

export const updateSeatApi = async (id, data) => {
  const response = await api.put(`/api/seats/${id}`, data);

  return response.data;
};

export const createSeatApi = async data => {
  const response = await api.post('/api/seats', data);

  return response.data;
};

export const getAvailableSeatsApi = async (gender, slot) => {
  const response = await api.get('/api/seats/available', {
    params: {
      gender: gender || 'ANY',
      slot: slot || 'FULL_TIME',
    },
  });

  return response.data;
};

export const updateMembershipSeatApi = async (membershipId, seatId) => {
  const response = await api.put(`/api/memberships/${membershipId}/change-seat`, {
    seat_id: seatId,
  });
  return response.data;
};
