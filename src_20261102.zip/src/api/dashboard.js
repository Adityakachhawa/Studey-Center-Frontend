import api from './api';

export const getDashboardApi = async () => {
  const response = await api.get('/api/dashboard');

  return response.data;
};