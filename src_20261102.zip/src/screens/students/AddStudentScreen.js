// import React, {
//   useState,
// } from 'react';

// import {
//   Alert,
//   KeyboardAvoidingView,
//   Platform,
//   ScrollView,
//   StyleSheet,
//   Text,
// } from 'react-native';

// import AppButton from '../../components/AppButton';
// import AppInput from '../../components/AppInput';

// import {createStudentApi} from '../../api/students';

// import {COLORS} from '../../constants/colors';

// const AddStudentScreen = ({
//   navigation,
// }) => {
//   const [name, setName] =
//     useState('');

//   const [mobile, setMobile] =
//     useState('');

//   const [alternateMobile, setAlternateMobile] =
//     useState('');

//   const [aadhar, setAadhar] =
//     useState('');

//   const [gender, setGender] =
//     useState('MALE');

//   const [fatherName, setFatherName] =
//     useState('');

//   const [motherName, setMotherName] =
//     useState('');

//   const [address, setAddress] =
//     useState('');

//   const [city, setCity] =
//     useState('');

//   const [state, setState] =
//     useState('');

//   const [pincode, setPincode] =
//     useState('');

//   const [emergencyName, setEmergencyName] =
//     useState('');

//   const [emergencyMobile, setEmergencyMobile] =
//     useState('');

//   const [loading, setLoading] =
//     useState(false);

//   const saveStudent = async () => {
//     if (!name.trim()) {
//       Alert.alert(
//         'Required',
//         'Please enter student name.',
//       );
//       return;
//     }

//     if (!mobile.trim()) {
//       Alert.alert(
//         'Required',
//         'Please enter mobile number.',
//       );
//       return;
//     }

//     setLoading(true);

//     try {
//       const response =
//         await createStudentApi({
//           full_name: name.trim(),
//           mobile: mobile.trim(),
//           alternate_mobile:
//             alternateMobile.trim() ||
//             null,
//           aadhar_number:
//             aadhar.trim() || null,
//           gender,
//           father_name:
//             fatherName.trim() ||
//             null,
//           mother_name:
//             motherName.trim() ||
//             null,
//           address:
//             address.trim() || null,
//           city:
//             city.trim() || null,
//           state:
//             state.trim() || null,
//           pincode:
//             pincode.trim() || null,
//           emergency_contact_name:
//             emergencyName.trim() ||
//             null,
//           emergency_contact_mobile:
//             emergencyMobile.trim() ||
//             null,
//         });

//       if (
//         response?.status?.code === 200
//       ) {
//         Alert.alert(
//           'Success',
//           'Student created successfully.',
//           [
//             {
//               text: 'OK',
//               onPress: () =>
//                 navigation.goBack(),
//             },
//           ],
//         );
//       } else {
//         throw new Error(
//           response?.status?.message ||
//             'Unable to create student',
//         );
//       }
//     } catch (error) {
//       Alert.alert(
//         'Error',
//         error?.response?.data?.status
//           ?.message ||
//           error.message ||
//           'Unable to create student.',
//       );
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <KeyboardAvoidingView
//       style={styles.screen}
//       behavior={
//         Platform.OS === 'ios'
//           ? 'padding'
//           : undefined
//       }>
//       <ScrollView
//         contentContainerStyle={
//           styles.content
//         }
//         keyboardShouldPersistTaps="handled">
//         <Text style={styles.title}>
//           Add student
//         </Text>

//         <Text style={styles.subtitle}>
//           Create a new student profile.
//         </Text>

//         <Text style={styles.section}>
//           Basic information
//         </Text>

//         <AppInput
//           label="Full name *"
//           placeholder="Student full name"
//           value={name}
//           onChangeText={setName}
//         />

//         <AppInput
//           label="Mobile number *"
//           placeholder="10 digit mobile number"
//           value={mobile}
//           onChangeText={setMobile}
//           keyboardType="phone-pad"
//         />

//         <AppInput
//           label="Alternate mobile"
//           placeholder="Optional"
//           value={alternateMobile}
//           onChangeText={
//             setAlternateMobile
//           }
//           keyboardType="phone-pad"
//         />

//         <AppInput
//           label="Aadhaar number"
//           placeholder="Optional"
//           value={aadhar}
//           onChangeText={setAadhar}
//           keyboardType="number-pad"
//         />

//         <Text style={styles.label}>
//           Gender
//         </Text>

//         <Text
//           onPress={() =>
//             setGender(
//               gender === 'MALE'
//                 ? 'FEMALE'
//                 : gender ===
//                   'FEMALE'
//                 ? 'OTHER'
//                 : 'MALE',
//             )
//           }
//           style={styles.gender}>
//           {gender}  •  Tap to change
//         </Text>

//         <Text style={styles.section}>
//           Family information
//         </Text>

//         <AppInput
//           label="Father name"
//           placeholder="Optional"
//           value={fatherName}
//           onChangeText={
//             setFatherName
//           }
//         />

//         <AppInput
//           label="Mother name"
//           placeholder="Optional"
//           value={motherName}
//           onChangeText={
//             setMotherName
//           }
//         />

//         <Text style={styles.section}>
//           Address
//         </Text>

//         <AppInput
//           label="Address"
//           placeholder="Full address"
//           value={address}
//           onChangeText={setAddress}
//         />

//         <AppInput
//           label="City"
//           placeholder="City"
//           value={city}
//           onChangeText={setCity}
//         />

//         <AppInput
//           label="State"
//           placeholder="State"
//           value={state}
//           onChangeText={setState}
//         />

//         <AppInput
//           label="Pincode"
//           placeholder="Pincode"
//           value={pincode}
//           onChangeText={setPincode}
//           keyboardType="number-pad"
//         />

//         <Text style={styles.section}>
//           Emergency contact
//         </Text>

//         <AppInput
//           label="Contact name"
//           placeholder="Optional"
//           value={emergencyName}
//           onChangeText={
//             setEmergencyName
//           }
//         />

//         <AppInput
//           label="Contact mobile"
//           placeholder="Optional"
//           value={emergencyMobile}
//           onChangeText={
//             setEmergencyMobile
//           }
//           keyboardType="phone-pad"
//         />

//         <AppButton
//           title="Create student"
//           loading={loading}
//           onPress={saveStudent}
//         />
//       </ScrollView>
//     </KeyboardAvoidingView>
//   );
// };

// const styles = StyleSheet.create({
//   screen: {
//     flex: 1,
//     backgroundColor: COLORS.background,
//   },

//   content: {
//     padding: 20,
//     paddingBottom: 50,
//   },

//   title: {
//     fontSize: 28,
//     fontWeight: '800',
//     color: COLORS.text,
//   },

//   subtitle: {
//     color: COLORS.textSecondary,
//     marginTop: 5,
//     marginBottom: 28,
//   },

//   section: {
//     fontSize: 16,
//     fontWeight: '800',
//     color: COLORS.text,
//     marginTop: 12,
//     marginBottom: 16,
//   },

//   label: {
//     fontSize: 13,
//     fontWeight: '600',
//     color: COLORS.text,
//     marginBottom: 8,
//   },

//   gender: {
//     backgroundColor: COLORS.white,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     borderRadius: 13,
//     padding: 16,
//     color: COLORS.primary,
//     fontWeight: '700',
//     marginBottom: 18,
//   },
// });

// export default AddStudentScreen;

import React, {useEffect, useState} from 'react';

import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import AppButton from '../../components/AppButton';
import AppInput from '../../components/AppInput';

import {
  createStudentApi,
  getStudentApi,
  updateStudentApi,
} from '../../api/students';

import {COLORS} from '../../constants/colors';

// ---------- Validators ----------
const MOBILE_REGEX = /^[6-9]\d{9}$/;
const AADHAAR_REGEX = /^\d{12}$/;
const PINCODE_REGEX = /^\d{6}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const GENDERS = ['MALE', 'FEMALE', 'OTHER'];

const AddStudentScreen = ({navigation, route}) => {
  const seatId = route?.params?.seatId;
  const seatNumber = route?.params?.seatNumber;
  const studentId = route?.params?.studentId;
  const isEdit = !!studentId;

  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [alternateMobile, setAlternateMobile] = useState('');
  const [aadhar, setAadhar] = useState('');
  const [aadharChanged, setAadharChanged] = useState(false);
  const [gender, setGender] = useState('MALE');
  const [fatherName, setFatherName] = useState('');
  const [motherName, setMotherName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [pincode, setPincode] = useState('');
  const [email, setEmail] = useState('');
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyMobile, setEmergencyMobile] = useState('');

  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(isEdit);

  // ---------- Load for edit ----------
  useEffect(() => {
    if (!isEdit) return;

    const load = async () => {
      try {
        const res = await getStudentApi(studentId);
        if (res?.status?.code === 200 && res.data) {
          const s = res.data;
          setName(s.full_name || '');
          setMobile(s.mobile || '');
          setAlternateMobile(s.alternate_mobile || '');
          setAadhar(s.aadhar_number || '');
          setGender((s.gender || 'MALE').toUpperCase());
          setFatherName(s.father_name || '');
          setMotherName(s.mother_name || '');
          setAddress(s.address || '');
          setCity(s.city || '');
          setState(s.state || '');
          setPincode(s.pincode || '');
          setEmail(s.email || '');
          setEmergencyName(s.emergency_contact_name || '');
          setEmergencyMobile(s.emergency_contact_mobile || '');
        }
      } catch (err) {
        Alert.alert('Error', 'Unable to load student.');
        navigation.goBack();
      } finally {
        setFetching(false);
      }
    };

    load();
  }, [isEdit, studentId, navigation]);

  // ---------- Validation ----------
  const validate = () => {
    if (!name.trim()) {
      Alert.alert('Required', 'Please enter student name.');
      return false;
    }

    if (!MOBILE_REGEX.test(mobile.trim())) {
      Alert.alert('Invalid mobile', 'Enter a valid 10-digit mobile number.');
      return false;
    }

    if (alternateMobile.trim() && !MOBILE_REGEX.test(alternateMobile.trim())) {
      Alert.alert('Invalid alternate mobile', 'Enter a valid 10-digit number.');
      return false;
    }

    // Only validate Aadhaar if user changed it
    if (isEdit && aadharChanged && aadhar.trim()) {
      if (!AADHAAR_REGEX.test(aadhar.replace(/\s|-/g, ''))) {
        Alert.alert('Invalid Aadhaar', 'Aadhaar must be 12 digits.');
        return false;
      }
    }

    if (!isEdit && aadhar.trim()) {
      if (!AADHAAR_REGEX.test(aadhar.replace(/\s|-/g, ''))) {
        Alert.alert('Invalid Aadhaar', 'Aadhaar must be 12 digits.');
        return false;
      }
    }

    if (pincode.trim() && !PINCODE_REGEX.test(pincode.trim())) {
      Alert.alert('Invalid pincode', 'Pincode must be 6 digits.');
      return false;
    }

    if (email.trim() && !EMAIL_REGEX.test(email.trim())) {
      Alert.alert('Invalid email', 'Please enter a valid email address.');
      return false;
    }

    if (
      emergencyMobile.trim() &&
      !MOBILE_REGEX.test(emergencyMobile.trim())
    ) {
      Alert.alert('Invalid emergency mobile', 'Enter a valid 10-digit number.');
      return false;
    }

    return true;
  };

  // ---------- Save ----------
  const saveStudent = async () => {
    if (!validate()) return;

    setLoading(true);

    const payload = {
      full_name: name.trim(),
      mobile: mobile.trim(),
      alternate_mobile: alternateMobile.trim() || null,
      gender,
      father_name: fatherName.trim() || null,
      mother_name: motherName.trim() || null,
      address: address.trim() || null,
      city: city.trim() || null,
      state: state.trim() || null,
      pincode: pincode.trim() || null,
      email: email.trim() || null,
      emergency_contact_name: emergencyName.trim() || null,
      emergency_contact_mobile: emergencyMobile.trim() || null,
    };

    // Aadhaar: only send when creating OR when user explicitly changed it
    if (!isEdit) {
      payload.aadhar_number = aadhar.trim() || null;
    } else if (aadharChanged) {
      payload.aadhar_number = aadhar.trim() || null;
    }

    try {
      const response = isEdit
        ? await updateStudentApi(studentId, payload)
        : await createStudentApi(payload);

      if (response?.status?.code === 200) {
        const newStudentId = response.data.id;
        if (seatId) {
          // If we came from the Seat screen, jump straight to Membership
          Alert.alert(
            'Student Added',
            'Now assign a fee plan and confirm the seat.',
            [
              {
                text: 'Continue',
                onPress: () => {
                  navigation.replace('AddMembership', {
                    studentId: newStudentId,
                    seatId: seatId, // pass the seat forward!
                    suggestedSlot: route?.params?.suggestedSlot // 👈 Pass the suggestion
                  });
                },
              },
            ],
          );
        }
        else{
        Alert.alert(
          'Success',
          isEdit ? 'Student updated successfully.' : 'Student created successfully.',
          [{text: 'OK', onPress: () => navigation.goBack()}],
        );
      }
      } else {
        throw new Error(
          response?.status?.message || 'Unable to save student',
        );
      }
    } catch (error) {
      Alert.alert(
        'Error',
        error?.response?.data?.status?.message ||
          error.message ||
          'Unable to save student.',
      );
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>
          {isEdit ? 'Edit student' : 'Add student'}
        </Text>

        {/* <Text style={styles.subtitle}>
          {isEdit
            ? 'Update student details.'
            : 'Create a new student profile.'}
        </Text> */}

        {/* <Text style={styles.section}>Basic information</Text> */}

        <AppInput
          label="Full name *"
          placeholder="Student full name"
          value={name}
          onChangeText={setName}
        />

        <AppInput
          label="Mobile number *"
          placeholder="10 digit mobile number"
          value={mobile}
          onChangeText={t => setMobile(t.replace(/[^0-9]/g, '').slice(0, 10))}
          keyboardType="phone-pad"
          maxLength={10}
        />

        <AppInput
          label="Alternate mobile"
          placeholder="Optional"
          value={alternateMobile}
          onChangeText={t =>
            setAlternateMobile(t.replace(/[^0-9]/g, '').slice(0, 10))
          }
          keyboardType="phone-pad"
          maxLength={10}
        />

        {/* <AppInput
          label="Aadhaar number"
          placeholder="12 digit Aadhaar (optional)"
          value={aadhar}
          onChangeText={t => {
            setAadhar(t.replace(/[^0-9]/g, '').slice(0, 12));
            if (isEdit) setAadharChanged(true);
          }}
          keyboardType="number-pad"
          maxLength={12}
        /> */}

        <Text style={styles.label}>Gender</Text>
        <View style={styles.genderRow}>
          {GENDERS.map(g => (
            <Text
              key={g}
              onPress={() => setGender(g)}
              style={[
                styles.genderChip,
                gender === g && styles.genderChipActive,
              ]}>
              {g}
            </Text>
          ))}
        </View>

        {/* <Text style={styles.section}>Family information</Text> */}

        <AppInput
          label="Father name"
          placeholder="Optional"
          value={fatherName}
          onChangeText={setFatherName}
        />

        {/* <AppInput
          label="Mother name"
          placeholder="Optional"
          value={motherName}
          onChangeText={setMotherName}
        /> */}

        {/* <Text style={styles.section}>Address</Text> */}

        <AppInput
          label="Address"
          placeholder="Full address"
          value={address}
          onChangeText={setAddress}
          multiline
        />

        {/* <AppInput
          label="City"
          placeholder="City"
          value={city}
          onChangeText={setCity}
        />

        <AppInput
          label="State"
          placeholder="State"
          value={state}
          onChangeText={setState}
        /> */}

        {/* <AppInput
          label="Pincode"
          placeholder="6 digit pincode"
          value={pincode}
          onChangeText={t => setPincode(t.replace(/[^0-9]/g, '').slice(0, 6))}
          keyboardType="number-pad"
          maxLength={6}
        /> */}

        {/* <Text style={styles.section}>Contact</Text> */}

        {/* <AppInput
          label="Email"
          placeholder="Optional"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        /> */}

        {/* <Text style={styles.section}>Emergency contact</Text>

        <AppInput
          label="Contact name"
          placeholder="Optional"
          value={emergencyName}
          onChangeText={setEmergencyName}
        />

        <AppInput
          label="Contact mobile"
          placeholder="Optional"
          value={emergencyMobile}
          onChangeText={t =>
            setEmergencyMobile(t.replace(/[^0-9]/g, '').slice(0, 10))
          }
          keyboardType="phone-pad"
          maxLength={10}
        /> */}

        <AppButton
          title={isEdit ? 'Update student' : 'Create student'}
          loading={loading}
          onPress={saveStudent}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  content: {padding: 20, paddingBottom: 50},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, marginTop: 5, 
    marginBottom: 28
  },
  section: {
    fontSize: 16, fontWeight: '800',
    color: COLORS.text, 
    marginTop: 10, 
    marginBottom: 16,
  },
  label: {
    fontSize: 13, fontWeight: '600',
    color: COLORS.text, marginBottom: 8,
  },
  genderRow: {
    flexDirection: 'row', gap: 8, marginBottom: 18,
  },
  genderChip: {
    flex: 1, textAlign: 'center',
    paddingVertical: 14, borderRadius: 13,
    borderWidth: 1, borderColor: COLORS.border,
    backgroundColor: COLORS.white,
    color: COLORS.textSecondary,
    fontWeight: '700', overflow: 'hidden',
  },
  genderChipActive: {
    borderColor: COLORS.primary,
    backgroundColor: '#DBEAFE',
    color: COLORS.primary,
  },
});

export default AddStudentScreen;