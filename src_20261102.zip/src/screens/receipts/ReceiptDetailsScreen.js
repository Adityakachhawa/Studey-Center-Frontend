import React from 'react';

import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {COLORS} from '../../constants/colors';

import {shareReceiptOnWhatsApp} from '../../utils/shareReceipt';

const formatMoney = value => {
  const number = Number(value || 0);

  return `₹${number.toLocaleString('en-IN')}`;
};

const formatDate = value => {
  if (!value) return '—';

  const date = new Date(value);

  if (isNaN(date.getTime())) return String(value).slice(0, 10);

  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const ReceiptDetailsScreen = ({route, navigation}) => {
  const {receipt} = route.params || {};

  if (!receipt) {
    return (
      <View style={styles.loader}>
        <Text style={{color: COLORS.textSecondary}}>
          No receipt data.
        </Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.content}>
      {/* Library header */}
      <View style={styles.headerBlock}>
        <Text style={styles.libraryName}>GYAN GANGA LIBRARY</Text>
        <Text style={styles.librarySub}>
          Near Canara Bank, Main Road, Gangashahar
        </Text>
        <Text style={styles.librarySub}>
          Timing: 08:00 AM – 10:00 PM
        </Text>
      </View>

      {/* Receipt card */}
      <View style={styles.card}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>PAYMENT RECEIPT</Text>
        </View>

        <View style={styles.rowBetween}>
          <Text style={styles.label}>Receipt No</Text>
          <Text style={styles.value}>{receipt.receipt_number}</Text>
        </View>

        <View style={styles.rowBetween}>
          <Text style={styles.label}>Payment No</Text>
          <Text style={styles.value}>{receipt.payment_number}</Text>
        </View>

        <View style={styles.rowBetween}>
          <Text style={styles.label}>Date</Text>
          <Text style={styles.value}>
            {formatDate(receipt.receipt_date)}
          </Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.rowBetween}>
          <Text style={styles.label}>Student</Text>
          <Text style={styles.value}>{receipt.full_name}</Text>
        </View>

        <View style={styles.rowBetween}>
          <Text style={styles.label}>Code</Text>
          <Text style={styles.value}>{receipt.student_code}</Text>
        </View>

        {receipt.mobile && (
          <View style={styles.rowBetween}>
            <Text style={styles.label}>Mobile</Text>
            <Text style={styles.value}>{receipt.mobile}</Text>
          </View>
        )}

        <View style={styles.divider} />

        <View style={styles.rowBetween}>
          <Text style={styles.label}>Method</Text>
          <Text style={styles.value}>{receipt.method_name}</Text>
        </View>

        <View style={[styles.rowBetween, {marginTop: 8}]}>
          <Text style={styles.totalLabel}>Amount Paid</Text>
          <Text style={styles.totalValue}>
            {formatMoney(receipt.amount)}
          </Text>
        </View>
      </View>

      {/* WhatsApp button */}
      <Pressable
        style={styles.waButton}
        onPress={() => shareReceiptOnWhatsApp(receipt)}>
        <Text style={styles.waText}>Share on WhatsApp</Text>
      </Pressable>

      <Pressable
        style={styles.backButton}
        onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>Back</Text>
      </Pressable>

      <Text style={styles.footer}>
        Thank you for choosing Gyan Ganga Library.
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  content: {padding: 20, paddingBottom: 60},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},

  headerBlock: {
    alignItems: 'center',
    marginBottom: 16,
  },
  libraryName: {
    fontSize: 20, fontWeight: '900',
    color: COLORS.primary, letterSpacing: 1,
  },
  librarySub: {
    fontSize: 11, color: COLORS.textSecondary, marginTop: 3,
  },

  card: {
    backgroundColor: COLORS.white, borderRadius: 18,
    borderWidth: 1, borderColor: COLORS.border,
    padding: 18,
  },
  badge: {
    alignSelf: 'flex-start',
    backgroundColor: COLORS.primary,
    paddingHorizontal: 10, paddingVertical: 5,
    borderRadius: 20, marginBottom: 14,
  },
  badgeText: {
    color: COLORS.white, fontSize: 10,
    fontWeight: '800', letterSpacing: 1,
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5,
  },
  label: {color: COLORS.textSecondary, fontSize: 12},
  value: {color: COLORS.text, fontSize: 13, fontWeight: '700'},
  divider: {
    height: 1, backgroundColor: COLORS.border, marginVertical: 10,
  },
  totalLabel: {color: COLORS.text, fontSize: 15, fontWeight: '800'},
  totalValue: {color: COLORS.success, fontSize: 20, fontWeight: '900'},

  waButton: {
    marginTop: 22, height: 54, borderRadius: 14,
    backgroundColor: '#25D366',
    alignItems: 'center', justifyContent: 'center',
  },
  waText: {color: COLORS.white, fontSize: 15, fontWeight: '800'},

  backButton: {
    marginTop: 12, height: 48, borderRadius: 14,
    borderWidth: 1, borderColor: COLORS.border,
    alignItems: 'center', justifyContent: 'center',
  },
  backText: {color: COLORS.textSecondary, fontSize: 14, fontWeight: '700'},

  footer: {
    marginTop: 24, textAlign: 'center',
    color: COLORS.textLight, fontSize: 11,
  },
});

export default ReceiptDetailsScreen;