// import React, {useCallback, useMemo, useState} from 'react';

// import {
//   ActivityIndicator,
//   FlatList,
//   Pressable,
//   RefreshControl,
//   StyleSheet,
//   Text,
//   TextInput,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {getPaymentsApi} from '../../api/payments';
// import {getReceiptsApi} from '../../api/receipts';

// import {COLORS} from '../../constants/colors';

// import {shareReceiptOnWhatsApp} from '../../utils/shareReceipt';

// const formatMoney = value => {
//   const number = Number(value || 0);

//   return `₹${number.toLocaleString('en-IN')}`;
// };

// const formatDate = value => {
//   if (!value) return '—';

//   const date = new Date(value);

//   if (isNaN(date.getTime())) return String(value).slice(0, 10);

//   return date.toLocaleDateString('en-IN', {
//     day: '2-digit',
//     month: 'short',
//     year: 'numeric',
//   });
// };

// const PaymentsScreen = ({navigation}) => {
//   const [payments, setPayments] = useState([]);
//   const [receipts, setReceipts] = useState([]);
//   const [search, setSearch] = useState('');
//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);

//   const loadAll = useCallback(async (showLoader = false) => {
//     if (showLoader) setLoading(true);

//     try {
//       const [paymentsRes, receiptsRes] = await Promise.all([
//         getPaymentsApi(),
//         getReceiptsApi(),
//       ]);

//       if (paymentsRes?.status?.code === 200) {
//         setPayments(paymentsRes.data || []);
//       }

//       if (receiptsRes?.status?.code === 200) {
//         setReceipts(receiptsRes.data || []);
//       }
//     } catch (error) {
//       console.log('Payments load error:', error);
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
//   }, []);

//   useFocusEffect(
//     useCallback(() => {
//       loadAll(payments.length === 0);
//       // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, []),
//   );

//   const onRefresh = () => {
//     setRefreshing(true);
//     loadAll();
//   };

//   // Fast lookup: payment_id → receipt
//   const receiptByPaymentId = useMemo(() => {
//     const map = {};

//     receipts.forEach(r => {
//       map[Number(r.payment_id)] = r;
//     });

//     return map;
//   }, [receipts]);

//   const filtered = useMemo(() => {
//     const q = search.trim().toLowerCase();

//     if (!q) return payments;

//     return payments.filter(p => {
//       return (
//         String(p.full_name || '').toLowerCase().includes(q) ||
//         String(p.student_code || '').toLowerCase().includes(q) ||
//         String(p.payment_number || '').toLowerCase().includes(q)
//       );
//     });
//   }, [payments, search]);

//   const renderPayment = ({item}) => {
//     const receipt = receiptByPaymentId[Number(item.id)];

//     return (
//       <View style={styles.card}>
//         <View style={styles.topRow}>
//           <View style={styles.left}>
//             <Text style={styles.name} numberOfLines={1}>
//               {item.full_name}
//             </Text>

//             <Text style={styles.sub}>
//               {item.student_code} • {item.payment_number}
//             </Text>

//             <Text style={styles.meta}>
//               {formatDate(item.payment_date)} • {item.method_name}
//             </Text>
//           </View>

//           <Text style={styles.amount}>{formatMoney(item.amount)}</Text>
//         </View>

//         <View style={styles.actions}>
//           {receipt ? (
//             <>
//               <Pressable
//                 style={styles.receiptChip}
//                 onPress={() =>
//                   navigation.navigate('ReceiptDetails', {receipt})
//                 }>
//                 <Text style={styles.receiptChipText}>
//                   {receipt.receipt_number}
//                 </Text>
//               </Pressable>

//               <Pressable
//                 style={styles.waChip}
//                 onPress={() => shareReceiptOnWhatsApp(receipt)}>
//                 <Text style={styles.waChipText}>Share on WhatsApp</Text>
//               </Pressable>
//             </>
//           ) : (
//             <Text style={styles.noReceipt}>No receipt generated</Text>
//           )}
//         </View>
//       </View>
//     );
//   };

//   return (
//     <View style={styles.screen}>
//       <View style={styles.header}>
//         <View>
//           <Text style={styles.title}>Payments</Text>
//           <Text style={styles.subtitle}>Fee collection & receipts</Text>
//         </View>

//         <Pressable
//           style={styles.addButton}
//           onPress={() => navigation.navigate("AddPayment")}>
//           <Text style={styles.addText}>+</Text>
//         </Pressable>
//       </View>

//       <View style={styles.searchBox}>
//         <Text style={styles.searchIcon}>⌕</Text>
//         <TextInput
//           value={search}
//           onChangeText={setSearch}
//           placeholder="Search by name, code or payment no."
//           placeholderTextColor={COLORS.textLight}
//           style={styles.searchInput}
//           autoCorrect={false}
//           autoCapitalize="none"
//         />
//       </View>

//       {loading ? (
//         <View style={styles.loader}>
//           <ActivityIndicator size="large" color={COLORS.primary} />
//         </View>
//       ) : (
//         <FlatList
//           data={filtered}
//           keyExtractor={item => String(item.id)}
//           renderItem={renderPayment}
//           contentContainerStyle={styles.list}
//           keyboardShouldPersistTaps="handled"
//           refreshControl={
//             <RefreshControl
//               refreshing={refreshing}
//               onRefresh={onRefresh}
//             />
//           }
//           ListEmptyComponent={
//             <View style={styles.empty}>
//               <Text style={styles.emptyTitle}>No payments yet</Text>
//               <Text style={styles.emptyText}>
//                 Record a payment to see it here.
//               </Text>
//             </View>
//           }
//         />
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   screen: {flex: 1, backgroundColor: COLORS.background},
//   header: {
//     paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12,
//     flexDirection: 'row', alignItems: 'center',
//     justifyContent: 'space-between',
//   },
//   title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
//   subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
//   addButton: {
//     width: 46, height: 46, borderRadius: 14,
//     backgroundColor: COLORS.primary,
//     alignItems: 'center', justifyContent: 'center',
//   },
//   addText: {
//     color: COLORS.white, fontSize: 28,
//     lineHeight: 30, fontWeight: '400',
//   },
//   searchBox: {
//     marginHorizontal: 20, marginBottom: 12,
//     height: 50, backgroundColor: COLORS.white,
//     borderRadius: 14, borderWidth: 1,
//     borderColor: COLORS.border,
//     flexDirection: 'row', alignItems: 'center',
//     paddingHorizontal: 14,
//   },
//   searchIcon: {
//     color: COLORS.textSecondary, fontSize: 23, marginRight: 8,
//   },
//   searchInput: {flex: 1, color: COLORS.text, fontSize: 14},
//   list: {padding: 20, paddingTop: 5, paddingBottom: 40},
//   card: {
//     backgroundColor: COLORS.white, borderRadius: 16,
//     borderWidth: 1, borderColor: COLORS.border,
//     padding: 14, marginBottom: 10,
//   },
//   topRow: {flexDirection: 'row', alignItems: 'flex-start'},
//   left: {flex: 1, marginRight: 10},
//   name: {color: COLORS.text, fontSize: 15, fontWeight: '800'},
//   sub: {color: COLORS.textSecondary, fontSize: 11, marginTop: 3},
//   meta: {color: COLORS.textLight, fontSize: 11, marginTop: 3},
//   amount: {color: COLORS.text, fontSize: 16, fontWeight: '900'},
//   actions: {
//     flexDirection: 'row', alignItems: 'center',
//     marginTop: 12, flexWrap: 'wrap', gap: 8,
//   },
//   receiptChip: {
//     paddingVertical: 6, paddingHorizontal: 10,
//     borderRadius: 20, backgroundColor: COLORS.primary + '18',
//   },
//   receiptChipText: {
//     color: COLORS.primary, fontSize: 11, fontWeight: '800',
//   },
//   waChip: {
//     paddingVertical: 6, paddingHorizontal: 12,
//     borderRadius: 20, backgroundColor: '#25D366',
//   },
//   waChipText: {color: COLORS.white, fontSize: 11, fontWeight: '800'},
//   noReceipt: {color: COLORS.textLight, fontSize: 11, fontStyle: 'italic'},
//   loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
//   empty: {alignItems: 'center', paddingTop: 100},
//   emptyTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text},
//   emptyText: {
//     color: COLORS.textSecondary, marginTop: 6,
//     textAlign: 'center', paddingHorizontal: 40,
//   },
// });

// export default PaymentsScreen;
import React, {useCallback, useMemo, useState} from 'react';
import {
  ActivityIndicator, FlatList, Modal, Platform, Pressable,
  RefreshControl, StyleSheet, Text, TextInput, TouchableOpacity, View,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import DateTimePicker from '@react-native-community/datetimepicker';

import {getPaymentsApi} from '../../api/payments';
import {getReceiptsApi} from '../../api/receipts';
import {COLORS} from '../../constants/colors';
import {shareReceiptOnWhatsApp} from '../../utils/shareReceipt';

const formatMoney = v => `₹${Number(v || 0).toLocaleString('en-IN')}`;
const formatDate = value => {
  if (!value) return '—';
  const date = new Date(value);
  if (isNaN(date.getTime())) return String(value).slice(0, 10);
  return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};
const toDateString = (date) => {
  if (!date) return '';
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const PaymentsScreen = ({navigation}) => {
  const [payments, setPayments] = useState([]);
  const [receipts, setReceipts] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Date Filter State
  const [showDateModal, setShowDateModal] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [isFiltered, setIsFiltered] = useState(false);

  // Native Picker State
  const [showPicker, setShowPicker] = useState(false);
  const [pickerMode, setPickerMode] = useState('start');

  const loadAll = useCallback(async (showLoader = false) => {
    if (showLoader) setLoading(true);

    const params = {};
    if (isFiltered && startDate && endDate) {
      params.start_date = toDateString(startDate);
      params.end_date = toDateString(endDate);
    }

    try {
      const [paymentsRes, receiptsRes] = await Promise.all([
        getPaymentsApi(params),
        getReceiptsApi(),
      ]);

      if (paymentsRes?.status?.code === 200) setPayments(paymentsRes.data || []);
      if (receiptsRes?.status?.code === 200) setReceipts(receiptsRes.data || []);
    } catch (error) {
      console.log('Payments load error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [isFiltered, startDate, endDate]);

  useFocusEffect(
    useCallback(() => {
      loadAll(payments.length === 0);
    }, [loadAll]),
  );

  const onRefresh = () => {
    setRefreshing(true);
    loadAll();
  };

  const onChangeDate = (event, selectedDate) => {
    setShowPicker(Platform.OS === 'ios');
    if (event.type === 'dismissed') { setShowPicker(false); return; }
    
    if (selectedDate) {
      if (pickerMode === 'start') setStartDate(selectedDate);
      else setEndDate(selectedDate);
    }
    if (Platform.OS === 'android') setShowPicker(false);
  };

  const applyFilter = () => {
    if (!startDate || !endDate) return alert("Please select both dates");
    setIsFiltered(true);
    setShowDateModal(false);
  };

  const clearFilter = () => {
    setIsFiltered(false);
    setStartDate(null);
    setEndDate(null);
    setShowDateModal(false);
    setTimeout(() => loadAll(true), 100); // reload without filter
  };

  const receiptByPaymentId = useMemo(() => {
    const map = {};
    receipts.forEach(r => { map[Number(r.payment_id)] = r; });
    return map;
  }, [receipts]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return payments;
    return payments.filter(p => 
      String(p.full_name || '').toLowerCase().includes(q) ||
      String(p.student_code || '').toLowerCase().includes(q) ||
      String(p.payment_number || '').toLowerCase().includes(q)
    );
  }, [payments, search]);

  const renderPayment = ({item}) => {
    const receipt = receiptByPaymentId[Number(item.id)];

    return (
      <View style={styles.card}>
        <View style={styles.topRow}>
          <View style={styles.left}>
            <Text style={styles.name} numberOfLines={1}>{item.full_name}</Text>
            {/* <Text style={styles.sub}>{item.student_code} • {item.payment_number}</Text> */}
            <Text style={styles.meta}>{formatDate(item.payment_date)} • {item.method_name}</Text>
          </View>
          <Text style={styles.amount}>{formatMoney(item.amount)}</Text>
        </View>

        <View style={styles.actions}>
          {receipt ? (
            <>
              <Pressable style={styles.receiptChip} onPress={() => navigation.navigate('ReceiptDetails', {receipt})}>
                <Text style={styles.receiptChipText}>{receipt.receipt_number}</Text>
              </Pressable>
              <Pressable style={styles.waChip} onPress={() => shareReceiptOnWhatsApp(receipt)}>
                <Text style={styles.waChipText}>Share on WhatsApp</Text>
              </Pressable>
            </>
          ) : (
            <Text style={styles.noReceipt}>No receipt generated</Text>
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Payments</Text>
          <Text style={styles.subtitle}>Fee collection & receipts</Text>
        </View>
        
        <View style={{flexDirection: 'row', gap: 8}}>
          <Pressable style={styles.filterBtn} onPress={() => setShowDateModal(true)}>
            <Text style={styles.filterBtnText}>📅 Filter</Text>
          </Pressable>
          <Pressable style={styles.addButton} onPress={() => navigation.navigate('AddPayment')}>
            <Text style={styles.addText}>+</Text>
          </Pressable>
        </View>
      </View>

      {isFiltered && (
        <View style={styles.activeFilterBar}>
          <Text style={styles.activeFilterText}>Showing: {toDateString(startDate)} to {toDateString(endDate)}</Text>
          <Pressable onPress={clearFilter}><Text style={styles.clearFilterText}>✕ Clear</Text></Pressable>
        </View>
      )}

      <View style={styles.searchBox}>
        <Text style={styles.searchIcon}>⌕</Text>
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search by name, code or payment no."
          placeholderTextColor={COLORS.textLight}
          style={styles.searchInput}
        />
      </View>

      {loading ? (
        <View style={styles.loader}><ActivityIndicator size="large" color={COLORS.primary} /></View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => String(item.id)}
          renderItem={renderPayment}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>No payments found</Text>
              <Text style={styles.emptyText}>{isFiltered ? 'No payments in this date range.' : 'Record a payment to see it here.'}</Text>
            </View>
          }
        />
      )}

      {/* Date Filter Modal */}
      <Modal visible={showDateModal} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Filter Payments</Text>
            
            <Text style={styles.filterLabel}>Start Date</Text>
            <TouchableOpacity style={styles.input} onPress={() => { setPickerMode('start'); setShowPicker(true); }}>
              <Text style={{color: startDate ? COLORS.text : COLORS.textLight}}>
                {startDate ? toDateString(startDate) : 'Select Start Date'}
              </Text>
            </TouchableOpacity>

            <Text style={styles.filterLabel}>End Date</Text>
            <TouchableOpacity style={styles.input} onPress={() => { setPickerMode('end'); setShowPicker(true); }}>
              <Text style={{color: endDate ? COLORS.text : COLORS.textLight}}>
                {endDate ? toDateString(endDate) : 'Select End Date'}
              </Text>
            </TouchableOpacity>
            
            <Pressable style={styles.modalBtn} onPress={applyFilter}>
              <Text style={styles.modalBtnText}>Apply Filter</Text>
            </Pressable>
            <Pressable style={[styles.modalBtn, {backgroundColor: COLORS.background, marginTop: 8}]} onPress={() => setShowDateModal(false)}>
              <Text style={[styles.modalBtnText, {color: COLORS.textSecondary}]}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {showPicker && (
        <DateTimePicker
          value={(pickerMode === 'start' ? startDate : endDate) || new Date()}
          mode="date"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={onChangeDate}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  header: {paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'},
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
  addButton: {width: 46, height: 46, borderRadius: 14, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center'},
  addText: {color: COLORS.white, fontSize: 28, lineHeight: 30, fontWeight: '400'},
  filterBtn: {backgroundColor: COLORS.white, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, justifyContent: 'center'},
  filterBtnText: {fontSize: 12, fontWeight: '700', color: COLORS.text},
  
  activeFilterBar: {flexDirection: 'row', justifyContent: 'space-between', backgroundColor: COLORS.primary, marginHorizontal: 20, padding: 12, borderRadius: 12, marginBottom: 10},
  activeFilterText: {color: COLORS.white, fontWeight: '700', fontSize: 12},
  clearFilterText: {color: COLORS.white, fontWeight: '800', fontSize: 12},

  searchBox: {marginHorizontal: 20, marginBottom: 12, height: 50, backgroundColor: COLORS.white, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14},
  searchIcon: {color: COLORS.textSecondary, fontSize: 23, marginRight: 8},
  searchInput: {flex: 1, color: COLORS.text, fontSize: 14},
  list: {padding: 20, paddingTop: 5, paddingBottom: 40},
  card: {backgroundColor: COLORS.white, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border, padding: 14, marginBottom: 10},
  topRow: {flexDirection: 'row', alignItems: 'flex-start'},
  left: {flex: 1, marginRight: 10},
  name: {color: COLORS.text, fontSize: 15, fontWeight: '800'},
  sub: {color: COLORS.textSecondary, fontSize: 11, marginTop: 3},
  meta: {color: COLORS.textLight, fontSize: 11, marginTop: 3},
  amount: {color: COLORS.text, fontSize: 16, fontWeight: '900'},
  actions: {flexDirection: 'row', alignItems: 'center', marginTop: 12, flexWrap: 'wrap', gap: 8},
  receiptChip: {paddingVertical: 6, paddingHorizontal: 10, borderRadius: 20, backgroundColor: COLORS.primary + '18'},
  receiptChipText: {color: COLORS.primary, fontSize: 11, fontWeight: '800'},
  waChip: {paddingVertical: 6, paddingHorizontal: 12, borderRadius: 20, backgroundColor: '#25D366'},
  waChipText: {color: COLORS.white, fontSize: 11, fontWeight: '800'},
  noReceipt: {color: COLORS.textLight, fontSize: 11, fontStyle: 'italic'},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  empty: {alignItems: 'center', paddingTop: 100},
  emptyTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text},
  emptyText: {color: COLORS.textSecondary, marginTop: 6, textAlign: 'center', paddingHorizontal: 40},
  
  modalBg: {flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20},
  modalContent: {backgroundColor: COLORS.white, borderRadius: 20, padding: 20},
  modalTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text, marginBottom: 16},
  filterLabel: {fontSize: 12, color: COLORS.textSecondary, marginBottom: 6, fontWeight: '600'},
  input: {height: 48, backgroundColor: COLORS.background, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 14, justifyContent: 'center', marginBottom: 14},
  modalBtn: {backgroundColor: COLORS.primary, height: 48, borderRadius: 12, alignItems: 'center', justifyContent: 'center'},
  modalBtnText: {color: COLORS.white, fontWeight: '800', fontSize: 14},
});

export default PaymentsScreen;