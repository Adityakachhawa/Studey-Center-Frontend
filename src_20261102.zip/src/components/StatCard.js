import React from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import {COLORS} from '../constants/colors';

const StatCard = ({
  title,
  value,
  subtitle,
  icon = '•',
  iconBackground = COLORS.purpleBg,
  iconColor = COLORS.purple,
  onPress,
}) => {
  const content = (
    <View style={styles.container}>
      <View style={styles.topRow}>
        <View
          style={[
            styles.iconContainer,
            {backgroundColor: iconBackground},
          ]}>
          <Text style={[styles.icon, {color: iconColor}]}>
            {icon}
          </Text>
        </View>
      </View>

      <Text style={styles.title}>{title}</Text>

      <Text style={styles.value}>{value}</Text>

      {subtitle ? (
        <Text style={styles.subtitle}>{subtitle}</Text>
      ) : null}
    </View>
  );

  if (onPress) {
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={onPress}
        style={styles.wrapper}>
        {content}
      </TouchableOpacity>
    );
  }

  return <View style={styles.wrapper}>{content}</View>;
};

const styles = StyleSheet.create({
  wrapper: {
    width: '48%',
    marginBottom: 12,
  },
  container: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 18,
    padding: 15,
    minHeight: 140,
  },
  topRow: {
    marginBottom: 15,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    fontSize: 19,
    fontWeight: '900',
  },
  title: {
    color: COLORS.textSecondary,
    fontSize: 11,
    fontWeight: '700',
  },
  value: {
    color: COLORS.text,
    fontSize: 23,
    fontWeight: '900',
    marginTop: 3,
  },
  subtitle: {
    color: COLORS.textLight,
    fontSize: 10,
    marginTop: 4,
  },
});

export default StatCard;