import React, {useCallback, useState} from 'react';

import {
  ActivityIndicator,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {useFocusEffect} from '@react-navigation/native';

import {getReceiptsApi} from '../../api/receipts';

import {COLORS} from '../../constants/colors';

import {shareReceiptOnWhatsApp} from '../../utils/shareReceipt';

const formatMoney = value => {
  const number = Number(value || 0);

  return `₹${number.toLocaleString('en-IN')}`;
};

const formatDate = value => {
  if (!value) return '—';

  const date = new Date(value);

  if (isNaN(date.getTime())) return String(value).slice(0, 10);

  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const ReceiptsScreen = ({navigation}) => {
  const [receipts, setReceipts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadReceipts = useCallback(async (showLoader = false) => {
    if (showLoader) setLoading(true);

    try {
      const response = await getReceiptsApi();

      if (response?.status?.code === 200) {
        setReceipts(response.data || []);
      }
    } catch (error) {
      console.log('Receipts error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadReceipts(receipts.length === 0);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  const onRefresh = () => {
    setRefreshing(true);
    loadReceipts();
  };

  const renderReceipt = ({item}) => (
    <Pressable
      style={styles.card}
      onPress={() =>
        navigation.navigate('ReceiptDetails', {receipt: item})
      }>
      <View style={styles.left}>
        <Text style={styles.name} numberOfLines={1}>
          {item.full_name}
        </Text>

        <Text style={styles.sub}>
          {item.receipt_number} • {formatDate(item.receipt_date)}
        </Text>

        <Text style={styles.method}>{item.method_name}</Text>
      </View>

      <View style={styles.right}>
        <Text style={styles.amount}>{formatMoney(item.amount)}</Text>

        <Pressable
          style={styles.waChip}
          onPress={() => shareReceiptOnWhatsApp(item)}>
          <Text style={styles.waChipText}>WhatsApp</Text>
        </Pressable>
      </View>
    </Pressable>
  );

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Receipts</Text>
          <Text style={styles.subtitle}>All generated receipts</Text>
        </View>
      </View>

      {loading ? (
        <View style={styles.loader}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : (
        <FlatList
          data={receipts}
          keyExtractor={item => String(item.id)}
          renderItem={renderReceipt}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
            />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>No receipts yet</Text>
              <Text style={styles.emptyText}>
                Generate a receipt from any payment to see it here.
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  header: {
    paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12,
  },
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
  list: {padding: 20, paddingTop: 8, paddingBottom: 40},
  card: {
    backgroundColor: COLORS.white, borderRadius: 16,
    borderWidth: 1, borderColor: COLORS.border,
    padding: 14, marginBottom: 10,
    flexDirection: 'row', alignItems: 'center',
  },
  left: {flex: 1, marginRight: 10},
  right: {alignItems: 'flex-end'},
  name: {color: COLORS.text, fontSize: 14, fontWeight: '800'},
  sub: {color: COLORS.textSecondary, fontSize: 11, marginTop: 3},
  method: {color: COLORS.primary, fontSize: 11, marginTop: 3, fontWeight: '700'},
  amount: {color: COLORS.text, fontSize: 15, fontWeight: '900'},
  waChip: {
    marginTop: 8, backgroundColor: '#25D366',
    paddingVertical: 5, paddingHorizontal: 10, borderRadius: 20,
  },
  waChipText: {color: COLORS.white, fontSize: 10, fontWeight: '800'},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  empty: {alignItems: 'center', paddingTop: 100},
  emptyTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text},
  emptyText: {
    color: COLORS.textSecondary, marginTop: 6,
    textAlign: 'center', paddingHorizontal: 40,
  },
});

export default ReceiptsScreen;