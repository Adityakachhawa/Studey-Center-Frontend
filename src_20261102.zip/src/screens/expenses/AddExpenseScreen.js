// import React, {useEffect, useState} from 'react';
// import {
//   Alert,
//   KeyboardAvoidingView,
//   Platform,
//   ScrollView,
//   StyleSheet,
//   Text,
//   TouchableOpacity,
//   View,
// } from 'react-native';

// import AppButton from '../../components/AppButton';
// import AppInput from '../../components/AppInput';
// import ScreenHeader from '../../components/ScreenHeader';
// import Loading from '../../components/Loading';

// import {COLORS} from '../../constants/colors';
// import {createExpenseApi} from '../../api/expenses';
// import {getPaymentMethodsApi} from '../../api/fees';

// const AddExpenseScreen = ({navigation}) => {
//   const [loading, setLoading] = useState(true);
//   const [saving, setSaving] = useState(false);

//   const [paymentMethods, setPaymentMethods] = useState([]);

//   const [category, setCategory] = useState('');
//   const [title, setTitle] = useState('');
//   const [description, setDescription] = useState('');
//   const [amount, setAmount] = useState('');
//   const [expenseDate, setExpenseDate] = useState(
//     new Date().toISOString().split('T')[0],
//   );
//   const [paymentMethodId, setPaymentMethodId] = useState(null);
//   const [referenceNumber, setReferenceNumber] = useState('');

//   useEffect(() => {
//     loadMethods();
//   }, []);

//   const loadMethods = async () => {
//     try {
//       const response = await getPaymentMethodsApi();

//       if (response?.status?.code === 200) {
//         const methods = response.data || [];
//         setPaymentMethods(methods);

//         if (methods.length === 1) {
//           setPaymentMethodId(methods[0].id);
//         }
//       }
//     } catch (error) {
//       Alert.alert('Error', 'Unable to load payment methods.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const saveExpense = async () => {
//     if (!category.trim()) {
//       Alert.alert('Required', 'Please enter expense category.');
//       return;
//     }

//     if (!title.trim()) {
//       Alert.alert('Required', 'Please enter expense title.');
//       return;
//     }

//     if (!amount || Number(amount) <= 0) {
//       Alert.alert('Required', 'Please enter a valid amount.');
//       return;
//     }

//     try {
//       setSaving(true);

//       const response = await createExpenseApi({
//         category: category.trim(),
//         title: title.trim(),
//         description: description.trim() || null,
//         amount: Number(amount),
//         expense_date: expenseDate,
//         payment_method_id: paymentMethodId
//           ? Number(paymentMethodId)
//           : null,
//         reference_number: referenceNumber.trim() || null,
//         status: 'PAID',
//       });

//       if (response?.status?.code !== 200) {
//         throw new Error(
//           response?.status?.message || 'Unable to create expense.',
//         );
//       }

//       Alert.alert('Success', 'Expense recorded successfully.', [
//         {
//           text: 'Done',
//           onPress: () => navigation.goBack(),
//         },
//       ]);
//     } catch (error) {
//       Alert.alert(
//         'Error',
//         error.message || 'Unable to create expense.',
//       );
//     } finally {
//       setSaving(false);
//     }
//   };

//   if (loading) {
//     return <Loading fullScreen text="Loading expense form..." />;
//   }

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
//       <ScreenHeader
//         title="Add Expense"
//         subtitle="Record a center expense"
//         onBack={() => navigation.goBack()}
//       />

//       <ScrollView
//         contentContainerStyle={styles.content}
//         keyboardShouldPersistTaps="handled"
//         showsVerticalScrollIndicator={false}>
//         <View style={styles.hero}>
//           <Text style={styles.heroTitle}>New Expense</Text>
//           <Text style={styles.heroText}>
//             Keep your center's financial records accurate.
//           </Text>
//         </View>

//         <AppInput
//           label="Category"
//           placeholder="Example: Electricity"
//           value={category}
//           onChangeText={setCategory}
//         />

//         <AppInput
//           label="Expense Title"
//           placeholder="Example: September electricity bill"
//           value={title}
//           onChangeText={setTitle}
//         />

//         <AppInput
//           label="Amount"
//           placeholder="Enter amount"
//           value={amount}
//           onChangeText={setAmount}
//           keyboardType="decimal-pad"
//         />

//         <AppInput
//           label="Expense Date"
//           placeholder="YYYY-MM-DD"
//           value={expenseDate}
//           onChangeText={setExpenseDate}
//         />

//         <Text style={styles.label}>Payment Method</Text>

//         <View style={styles.methods}>
//           {paymentMethods.map(method => {
//             const selected =
//               Number(method.id) === Number(paymentMethodId);

//             return (
//               <TouchableOpacity
//                 key={method.id}
//                 onPress={() => setPaymentMethodId(method.id)}
//                 style={[
//                   styles.method,
//                   selected && styles.methodSelected,
//                 ]}>
//                 <Text
//                   style={[
//                     styles.methodText,
//                     selected && styles.methodTextSelected,
//                   ]}>
//                   {method.method_name}
//                 </Text>
//               </TouchableOpacity>
//             );
//           })}
//         </View>

//         <AppInput
//           label="Reference Number"
//           placeholder="Optional"
//           value={referenceNumber}
//           onChangeText={setReferenceNumber}
//         />

//         <AppInput
//           label="Description"
//           placeholder="Add additional details"
//           value={description}
//           onChangeText={setDescription}
//           multiline
//           numberOfLines={5}
//         />

//         <View style={styles.preview}>
//           <Text style={styles.previewTitle}>Expense Preview</Text>

//           <View style={styles.previewRow}>
//             <Text style={styles.previewLabel}>Category</Text>
//             <Text style={styles.previewValue}>
//               {category || '-'}
//             </Text>
//           </View>

//           <View style={styles.previewRow}>
//             <Text style={styles.previewLabel}>Payment Method</Text>
//             <Text style={styles.previewValue}>
//               {paymentMethods.find(
//                 item => Number(item.id) === Number(paymentMethodId),
//               )?.method_name || '-'}
//             </Text>
//           </View>

//           <View style={styles.previewTotal}>
//             <Text style={styles.previewTotalLabel}>Expense</Text>
//             <Text style={styles.previewAmount}>
//               ₹{Number(amount || 0).toFixed(2)}
//             </Text>
//           </View>
//         </View>

//         <AppButton
//           title={saving ? 'Saving Expense...' : 'Save Expense'}
//           onPress={saveExpense}
//           loading={saving}
//         />

//         <View style={{height: 30}} />
//       </ScrollView>
//     </KeyboardAvoidingView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: COLORS.background,
//   },
//   content: {
//     padding: 16,
//   },
//   hero: {
//     backgroundColor: COLORS.text,
//     borderRadius: 20,
//     padding: 18,
//     marginBottom: 20,
//   },
//   heroTitle: {
//     color: COLORS.white,
//     fontSize: 20,
//     fontWeight: '900',
//   },
//   heroText: {
//     color: '#AEB6C2',
//     fontSize: 12,
//     marginTop: 5,
//   },
//   label: {
//     color: COLORS.text,
//     fontSize: 12,
//     fontWeight: '800',
//     marginBottom: 9,
//   },
//   methods: {
//     flexDirection: 'row',
//     flexWrap: 'wrap',
//     gap: 9,
//     marginBottom: 18,
//   },
//   method: {
//     backgroundColor: COLORS.surface,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     borderRadius: 11,
//     paddingHorizontal: 15,
//     paddingVertical: 11,
//   },
//   methodSelected: {
//     backgroundColor: COLORS.primary,
//     borderColor: COLORS.primary,
//   },
//   methodText: {
//     color: COLORS.text,
//     fontSize: 12,
//     fontWeight: '700',
//   },
//   methodTextSelected: {
//     color: COLORS.white,
//   },
//   preview: {
//     backgroundColor: COLORS.surface,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     borderRadius: 18,
//     padding: 17,
//     marginBottom: 18,
//   },
//   previewTitle: {
//     color: COLORS.text,
//     fontSize: 15,
//     fontWeight: '800',
//     marginBottom: 14,
//   },
//   previewRow: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 10,
//   },
//   previewLabel: {
//     color: COLORS.textSecondary,
//     fontSize: 12,
//   },
//   previewValue: {
//     color: COLORS.text,
//     fontSize: 12,
//     fontWeight: '700',
//   },
//   previewTotal: {
//     borderTopWidth: 1,
//     borderTopColor: COLORS.border,
//     paddingTop: 13,
//     marginTop: 5,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//   },
//   previewTotalLabel: {
//     fontSize: 14,
//     color: COLORS.text,
//     fontWeight: '800',
//   },
//   previewAmount: {
//     fontSize: 21,
//     fontWeight: '900',
//     color: COLORS.danger,
//   },
// });

// export default AddExpenseScreen;
import React, {useState, useEffect} from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View, Pressable } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';

import AppButton from '../../components/AppButton';
import AppInput from '../../components/AppInput';
import ScreenHeader from '../../components/ScreenHeader';

import { createExpenseApi, updateExpenseApi, deleteExpenseApi } from '../../api/expenses';
import { COLORS } from '../../constants/colors';

const toDateString = (date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const AddExpenseScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const existingExpense = route.params?.expense; // 👈 Catch the passed expense
  const isEdit = !!existingExpense;

  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('GENERAL');
  const [date, setDate] = useState(toDateString(new Date()));
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isEdit && existingExpense) {
      setTitle(existingExpense.title || '');
      setAmount(String(existingExpense.amount || ''));
      setCategory(existingExpense.category || 'GENERAL');
      setDate(existingExpense.expense_date ? String(existingExpense.expense_date).slice(0, 10) : toDateString(new Date()));
      setDescription(existingExpense.description || '');
    }
  }, [isEdit, existingExpense]);

  const handleSave = async () => {
    if (!title.trim() || !amount || Number(amount) <= 0) {
      return Alert.alert('Error', 'Please fill all required fields.');
    }
    setSaving(true);
    const payload = {
      title: title.trim(),
      amount: Number(amount),
      category: category.trim().toUpperCase(),
      expense_date: date,
      description: description.trim() || null,
      status: 'PAID',
      payment_method_id: 1, // Defaulting to CASH for now
    };

    try {
      const res = isEdit 
        ? await updateExpenseApi(existingExpense.id, payload)
        : await createExpenseApi(payload);
      
      if (res?.status?.code === 200) {
        navigation.goBack();
      } else {
        Alert.alert('Error', res?.status?.message || 'Could not save');
      }
    } catch (e) {
      Alert.alert('Error', e?.response?.data?.status?.message || 'Network error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = () => {
    Alert.alert('Delete Expense', 'Are you sure you want to delete this expense?', [
      { text: 'Cancel', style: 'cancel' },
      { 
        text: 'Delete', 
        style: 'destructive', 
        onPress: async () => {
          try {
            await deleteExpenseApi(existingExpense.id);
            navigation.goBack();
          } catch (e) {
            Alert.alert('Error', 'Could not delete expense');
          }
        } 
      }
    ]);
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScreenHeader
        title={isEdit ? 'Edit Expense' : 'Add Expense'}
        subtitle={isEdit ? 'Update existing expense' : 'Record a new expense'}
        onBack={() => navigation.goBack()}
      />

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <AppInput label="Title *" placeholder="e.g. Electricity Bill" value={title} onChangeText={setTitle} />
        <AppInput label="Amount *" placeholder="0.00" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" />
        <AppInput label="Category *" placeholder="e.g. RENT, ELECTRICITY" value={category} onChangeText={setCategory} />
        <AppInput label="Date (YYYY-MM-DD) *" placeholder="2026-10-24" value={date} onChangeText={setDate} />
        <AppInput label="Description" placeholder="Optional notes" value={description} onChangeText={setDescription} multiline />

        <AppButton
          title={saving ? 'Saving...' : (isEdit ? 'Update Expense' : 'Save Expense')}
          onPress={handleSave}
          loading={saving}
        />

        {/* 👉 Show Delete Button only in Edit Mode */}
        {isEdit && (
          <Pressable style={styles.deleteBtn} onPress={handleDelete}>
            <Text style={styles.deleteBtnText}>Delete Expense</Text>
          </Pressable>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: COLORS.background},
  content: {padding: 20, paddingBottom: 40},
  deleteBtn: {
    marginTop: 20, height: 50, borderRadius: 12,
    backgroundColor: COLORS.dangerBg, alignItems: 'center', justifyContent: 'center',
  },
  deleteBtnText: {color: COLORS.danger, fontWeight: '800', fontSize: 15},
});

export default AddExpenseScreen;