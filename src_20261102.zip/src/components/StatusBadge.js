import React from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {COLORS} from '../constants/colors';

const StatusBadge = ({status}) => {
  const normalized = String(status || '')
    .toUpperCase()
    .replace(/ /g, '_');

  const config = {
    ACTIVE: {
      background: COLORS.successBg,
      text: COLORS.success,
    },
    SUCCESS: {
      background: COLORS.successBg,
      text: COLORS.success,
    },
    PAID: {
      background: COLORS.successBg,
      text: COLORS.success,
    },
    AVAILABLE: {
      background: COLORS.successBg,
      text: COLORS.success,
    },
    EXPIRED: {
      background: COLORS.warningBg,
      text: COLORS.warning,
    },
    PENDING: {
      background: COLORS.warningBg,
      text: COLORS.warning,
    },
    INACTIVE: {
      background: COLORS.border,
      text: COLORS.textSecondary,
    },
    CANCELLED: {
      background: COLORS.dangerBg,
      text: COLORS.danger,
    },
    FAILED: {
      background: COLORS.dangerBg,
      text: COLORS.danger,
    },
    LEFT: {
      background: COLORS.dangerBg,
      text: COLORS.danger,
    },
    OCCUPIED: {
      background: COLORS.purpleBg,
      text: COLORS.purple,
    },
    MAINTENANCE: {
      background: COLORS.warningBg,
      text: COLORS.warning,
    },
    BLOCKED: {
      background: COLORS.dangerBg,
      text: COLORS.danger,
    },
  };

  const selected = config[normalized] || {
    background: COLORS.border,
    text: COLORS.textSecondary,
  };

  return (
    <View
      style={[
        styles.badge,
        {backgroundColor: selected.background},
      ]}>
      <View
        style={[
          styles.dot,
          {backgroundColor: selected.text},
        ]}
      />

      <Text
        style={[
          styles.text,
          {color: selected.text},
        ]}>
        {String(status || 'UNKNOWN').replace(/_/g, ' ')}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 20,
  },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    marginRight: 5,
  },
  text: {
    fontSize: 9,
    fontWeight: '900',
  },
});

export default StatusBadge;