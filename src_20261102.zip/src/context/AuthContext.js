import React, {
  createContext,
  useContext,
  useEffect,
  useState,
} from 'react';

import {
  loginApi,
  logoutApi,
  getMeApi,
} from '../api/auth';

const AuthContext = createContext(null);

export const AuthProvider = ({children}) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const checkLogin = async () => {
    try {
      const response = await getMeApi();

      if (response?.status?.code === 200) {
        setUser(response.data);
      }
    } catch (error) {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkLogin();
  }, []);

  const login = async (mobile, password) => {
    const response = await loginApi(
      mobile,
      password,
    );

    if (response?.status?.code !== 200) {
      throw new Error(
        response?.status?.message ||
          'Login failed',
      );
    }

    setUser(response.data);

    return response;
  };

  const logout = async () => {
    try {
      await logoutApi();
    } catch (error) {
      console.log('Logout error:', error);
    }

    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        logout,
      }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () =>
  useContext(AuthContext);