import api from './api';

export const getMembershipsApi = async params => {
  const response = await api.get('/api/memberships', {
    params: params || {},
  });

  return response.data;
};

export const createMembershipApi = async data => {
  const response = await api.post('/api/memberships', data);

  return response.data;
};