import React from 'react';
import {StyleSheet, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';

import {COLORS} from '../constants/colors';

/**
 * Standard screen wrapper that handles safe areas.
 *
 * Usage:
 *   <ScreenContainer>            → top/left/right insets (default, for scrollable screens)
 *   <ScreenContainer includeBottom>  → adds bottom inset (for fixed-bottom-button screens)
 *
 * @param {boolean} includeBottom  Add bottom safe area (use for Login, OTP, fixed CTA screens)
 * @param {string}  backgroundColor  Override default background
 * @param {object}  style            Additional styles for the inner view
 */
const ScreenContainer = ({
  children,
  includeBottom = false,
  backgroundColor = COLORS.background,
  style,
}) => {
  const edges = includeBottom
    ? ['top', 'bottom', 'left', 'right']
    : ['top', 'left', 'right'];

  return (
    <SafeAreaView
      style={[styles.safe, {backgroundColor}]}
      edges={edges}>
      <View style={[styles.inner, style]}>{children}</View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  inner: {
    flex: 1,
  },
});

export default ScreenContainer;