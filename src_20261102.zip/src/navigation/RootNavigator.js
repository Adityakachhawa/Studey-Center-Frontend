// import React from 'react';
// import {createNativeStackNavigator} from '@react-navigation/native-stack';

// import MainNavigator from './MainNavigator';
// import AuthNavigator from './AuthNavigator';

// import {useAuth} from '../context/AuthContext';

// const Stack = createNativeStackNavigator();

// const RootNavigator = () => {
//   const {user, loading} = useAuth();

//   if (loading) {
//     return null;
//   }

//   if (!user) {
//     return <AuthNavigator />;
//   }

//   return (
//     <Stack.Navigator screenOptions={{headerShown: false}}>
//       <Stack.Screen
//         name="Main"
//         component={MainNavigator}
//       />
//     </Stack.Navigator>
//   );
// };

// export default RootNavigator;

import React from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import MainNavigator from './MainNavigator';
import AuthNavigator from './AuthNavigator';

import {useAuth} from '../context/AuthContext';
import {COLORS} from '../constants/colors';

const Stack = createNativeStackNavigator();

const RootNavigator = () => {
  const {user, loading} = useAuth();

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  if (!user) {
    return <AuthNavigator />;
  }

  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="Main" component={MainNavigator} />
    </Stack.Navigator>
  );
};

const styles = StyleSheet.create({
  loader: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.background,
  },
});

export default RootNavigator;