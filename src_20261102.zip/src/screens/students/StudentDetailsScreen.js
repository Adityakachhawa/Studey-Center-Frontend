// import React, {useCallback, useState} from 'react';

// import {
//   ActivityIndicator,
//   Alert,
//   Pressable,
//   ScrollView,
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {
//   getStudentApi,
//   deleteStudentApi,
//   updateStudentApi
// } from '../../api/students';

// import {getMembershipsApi} from '../../api/fees';
// import {getPaymentsApi} from '../../api/payments';
// import {getReceiptsApi} from '../../api/receipts';

// import {COLORS} from '../../constants/colors';
// import {cancelMembershipApi} from '../../api/fees';
// import {shareReceiptOnWhatsApp} from '../../utils/shareReceipt';

// const formatMoney = value => {
//   const number = Number(value || 0);

//   return `₹${number.toLocaleString('en-IN')}`;
// };

// const formatDate = value => {
//   if (!value) return '—';

//   const date = new Date(value);

//   if (isNaN(date.getTime())) return String(value).slice(0, 10);

//   return date.toLocaleDateString('en-IN', {
//     day: '2-digit',
//     month: 'short',
//     year: 'numeric',
//   });
// };

// const StudentDetailsScreen = ({route, navigation}) => {
//   const {studentId} = route.params;

//   const [student, setStudent] = useState(null);
//   const [memberships, setMemberships] = useState([]);
//   const [payments, setPayments] = useState([]);
//   const [receipts, setReceipts] = useState([]);
//   const [loading, setLoading] = useState(true);

//   const loadData = useCallback(async () => {
//     try {
//       const [
//         studentRes,
//         membershipRes,
//         paymentsRes,
//         receiptsRes,
//       ] = await Promise.all([
//         getStudentApi(studentId),
//         getMembershipsApi(studentId),
//         getPaymentsApi({student_id: studentId}),
//         getReceiptsApi(),
//       ]);

//       if (studentRes?.status?.code === 200) {
//         setStudent(studentRes.data);
//       }

//       if (membershipRes?.status?.code === 200) {
//         setMemberships(membershipRes.data || []);
//       }

//       if (paymentsRes?.status?.code === 200) {
//         setPayments(paymentsRes.data || []);
//       }

//       if (receiptsRes?.status?.code === 200) {
//         // receipts endpoint doesn't support student filter — do it here
//         const paymentIds = new Set(
//           (paymentsRes?.data || []).map(p => Number(p.id)),
//         );

//         setReceipts(
//           (receiptsRes.data || []).filter(r =>
//             paymentIds.has(Number(r.payment_id)),
//           ),
//         );
//       }
//     } catch (error) {
//       Alert.alert('Error', 'Unable to load student.');
//     } finally {
//       setLoading(false);
//     }
//   }, [studentId]);

//   useFocusEffect(
//     useCallback(() => {
//       setLoading(true);
//       loadData();
//     }, [loadData]),
//   );

//   const deactivate = () => {
//     Alert.alert(
//       'Deactivate student',
//       'Are you sure you want to deactivate this student?',
//       [
//         {text: 'Cancel', style: 'cancel'},
//         {
//           text: 'Deactivate',
//           style: 'destructive',
//           onPress: async () => {
//             try {
//               await deleteStudentApi(studentId);
//               navigation.goBack();
//             } catch (error) {
//               Alert.alert('Error', 'Unable to deactivate student.');
//             }
//           },
//         },
//       ],
//     );
//   };


//   const reactivate = async () => {
//     try {
//       setLoading(true);
//       await updateStudentApi(studentId, {status: 'ACTIVE'});
//       await loadData();
//     } catch (error) {
//       Alert.alert('Error', 'Unable to reactivate student.');
//       setLoading(false);
//     }
//   };


//   if (loading) {
//     return (
//       <View style={styles.loader}>
//         <ActivityIndicator size="large" color={COLORS.primary} />
//       </View>
//     );
//   }

//   if (!student) return null;

//   const isActive = student.status === 'ACTIVE';

//   const activeMembership = memberships.find(
//     m => m.status === 'ACTIVE',
//   );

//   const totalPaid = payments.reduce(
//     (sum, p) => sum + Number(p.amount || 0),
//     0,
//   );

//   const totalDue = memberships.reduce(
//     (sum, m) => sum + Number(m.due_amount || 0),
//     0,
//   );

//   return (
//     <ScrollView
//       style={styles.screen}
//       contentContainerStyle={styles.content}>
//       <Pressable onPress={() => navigation.goBack()}>
//         <Text style={styles.back}>‹  Students</Text>
//       </Pressable>

//       <View style={styles.profile}>
//         <View style={styles.avatar}>
//           <Text style={styles.avatarText}>
//             {student.full_name?.charAt(0)?.toUpperCase()}
//           </Text>
//         </View>

//         <Text style={styles.name}>{student.full_name}</Text>
//         <Text style={styles.code}>{student.student_code}</Text>

//         <View
//           style={[
//             styles.badge,
//             !isActive && styles.badgeInactive,
//           ]}>
//           <Text
//             style={[
//               styles.badgeText,
//               !isActive && styles.badgeTextInactive,
//             ]}>
//             {student.status}
//           </Text>
//         </View>
//       </View>

//       {/* Quick stats */}
//       <View style={styles.statsRow}>
//         <View style={styles.statBox}>
//           <Text style={styles.statLabel}>Total Paid</Text>
//           <Text style={[styles.statValue, {color: COLORS.success}]}>
//             {formatMoney(totalPaid)}
//           </Text>
//         </View>

//         <View style={styles.statBox}>
//           <Text style={styles.statLabel}>Total Due</Text>
//           <Text
//             style={[
//               styles.statValue,
//               {color: totalDue > 0 ? COLORS.danger : COLORS.textSecondary},
//             ]}>
//             {formatMoney(totalDue)}
//           </Text>
//         </View>

//         <View style={styles.statBox}>
//           <Text style={styles.statLabel}>Memberships</Text>
//           <Text style={styles.statValue}>{memberships.length}</Text>
//         </View>
//       </View>

//       {/* Actions */}
//       <View style={styles.actionsRow}>
//         <Pressable
//           style={[styles.actionButton, styles.actionPrimary]}
//           onPress={() =>
//             navigation.navigate('AddStudent', {studentId})
//           }>
//           <Text style={styles.actionPrimaryText}>Edit</Text>
//         </Pressable>

//         {/* {isActive && (
//           <Pressable
//             style={[styles.actionButton, styles.actionDanger]}
//             onPress={deactivate}>
//             <Text style={styles.actionDangerText}>Deactivate</Text>
//           </Pressable>
//         )} */}
//         {isActive ? (
//           <Pressable style={[styles.actionButton, styles.actionDanger]} onPress={deactivate}>
//             <Text style={styles.actionDangerText}>Deactivate</Text>
//           </Pressable>
//         ) : (
//           <Pressable style={[styles.actionButton, {backgroundColor: COLORS.success}]} onPress={reactivate}>
//             <Text style={[styles.actionPrimaryText, {color: COLORS.white}]}>Reactivate</Text>
//           </Pressable>
//         )}
//       </View>

//       {/* <View style={styles.actionsRow}>
//         <Pressable
//           style={[styles.actionButton, styles.actionSecondary]}
//           onPress={() =>
//             navigation.navigate('AddMembership', {studentId})
//           }>
//           <Text style={styles.actionSecondaryText}>
//             + New Membership
//           </Text>
//         </Pressable>

//         <Pressable
//           style={[styles.actionButton, styles.actionSecondary]}
//           onPress={() =>
//             navigation.navigate('AddPayment', {studentId})
//           }>
//           <Text style={styles.actionSecondaryText}>+ Payment</Text>
//         </Pressable>
//       </View> */}

// {/* // <View style={styles.actionsRow}>
// //   <Pressable style={[styles.actionButton, styles.actionSecondary]} onPress={() => navigation.navigate('AddMembership', {studentId})}>
// //     <Text style={styles.actionSecondaryText}>+ New Membership</Text>
// //   </Pressable>
// //   <Pressable style={[styles.actionButton, styles.actionSecondary]} onPress={() => navigation.navigate('AddPayment', {studentId})}>
// //     <Text style={styles.actionSecondaryText}>+ Payment</Text>
// //   </Pressable>
// // </View> */}

// {isActive && (
// <>
//       {/* Actions */}
//       <View style={styles.actionsRow}>
//         <Pressable
//           style={[styles.actionButton, styles.actionSecondary]}
//           onPress={() =>
//             navigation.navigate('AddMembership', {studentId})
//           }>
//           <Text style={styles.actionSecondaryText}>
//             + New Membership
//           </Text>
//         </Pressable>

//         <Pressable
//           style={[styles.actionButton, styles.actionSecondary]}
//           onPress={() =>
//             navigation.navigate('AddPayment', {studentId})
//           }>
//           <Text style={styles.actionSecondaryText}>+ Payment</Text>
//         </Pressable>
//       </View>

//       {/* 👉 NEW: Upgrade / Change Plan Button */}
//       {activeMembership && (
//         <View style={styles.actionsRow}>
//           <Pressable
//             style={[styles.actionButton, {backgroundColor: COLORS.warningBg}]}
//             onPress={() => {
//               Alert.alert(
//                 'Upgrade / Change Plan',
//                 `Current Plan: ${activeMembership.plan_name}\n\nThis will cancel the current membership and free up the seat. Do you want to proceed?`,
//                 [
//                   {text: 'Cancel', style: 'cancel'},
//                   {
//                     text: 'Proceed',
//                     onPress: async () => {
//                       try {
//                         setLoading(true);
//                         // 1. Cancel the current membership
//                         await cancelMembershipApi(activeMembership.id);
                        
//                         // 2. Reload the screen to free the seat
//                         await loadData();
                        
//                         // 3. Jump to AddMembership with the suggested new slot
//                         const suggestedSlot = activeMembership.slot_type === 'HALF_EVENING' 
//                           ? 'FULL_TIME' 
//                           : 'FULL_TIME';

//                         navigation.navigate('AddMembership', {
//                           studentId: studentId,
//                           suggestedSlot: suggestedSlot, // 👈 Automatically suggests Full Time
//                         });
//                       } catch (err) {
//                         Alert.alert('Error', 'Could not upgrade membership.');
//                         setLoading(false);
//                       }
//                     },
//                   },
//                 ],
//               );
//             }}>
//             <Text style={[styles.actionSecondaryText, {color: COLORS.warning}]}>
//               Upgrade / Change Plan
//             </Text>
//           </Pressable>
//         </View>
//       )}
// </>
//       )}


//       <Section title="Contact">
//         <Info label="Mobile" value={student.mobile} />
//         <Info
//           label="Alternate mobile"
//           value={student.alternate_mobile || '—'}
//         />
//         <Info label="Email" value={student.email || '—'} />
//       </Section>

//       <Section title="Personal">
//         <Info label="Gender" value={student.gender} />
//         <Info
//           label="Date of birth"
//           value={student.date_of_birth || '—'}
//         />
//         <Info
//           label="Aadhaar"
//           value={student.aadhar_number || '—'}
//         />
//       </Section>

//       <Section title="Family">
//         <Info label="Father" value={student.father_name || '—'} />
//         <Info label="Mother" value={student.mother_name || '—'} />
//       </Section>

//       <Section title="Address">
//         <Info label="Address" value={student.address || '—'} />
//         <Info label="City" value={student.city || '—'} />
//         <Info label="State" value={student.state || '—'} />
//         <Info label="Pincode" value={student.pincode || '—'} />
//       </Section>

//       <Section title="Emergency contact">
//         <Info
//           label="Name"
//           value={student.emergency_contact_name || '—'}
//         />
//         <Info
//           label="Mobile"
//           value={student.emergency_contact_mobile || '—'}
//         />
//       </Section>

//       {/* ============ FEE HISTORY ============ */}

//       <Section title="Current Membership">
//         {activeMembership ? (
//           <>
//             <Info
//               label="Plan"
//               value={activeMembership.plan_name}
//             />
//             <Info
//               label="Seat"
//               value={activeMembership.seat_number || 'Not assigned'}
//             />
//             <Info
//               label="Start"
//               value={formatDate(activeMembership.start_date)}
//             />
//             <Info
//               label="Expiry"
//               value={formatDate(activeMembership.expiry_date)}
//             />
//             <Info
//               label="Final amount"
//               value={formatMoney(activeMembership.final_amount)}
//             />
//             <Info
//               label="Paid"
//               value={formatMoney(activeMembership.paid_amount)}
//             />
//             <Info
//               label="Due"
//               value={formatMoney(activeMembership.due_amount)}
//               highlight={Number(activeMembership.due_amount) > 0}
//             />
//           </>
//         ) : (
//           <Text style={styles.noData}>No active membership.</Text>
//         )}
//       </Section>

//       {memberships.length > 1 && (
//         <View style={styles.section}>
//           <Text style={styles.sectionTitle}>
//             Membership History ({memberships.length})
//           </Text>

//           {memberships.map(m => (
//             <View key={m.id} style={styles.historyCard}>
//               <View style={styles.historyTop}>
//                 <Text style={styles.historyPlan}>
//                   {m.plan_name}
//                 </Text>

//                 <View
//                   style={[
//                     styles.smallBadge,
//                     m.status === 'ACTIVE'
//                       ? styles.smallBadgeActive
//                       : styles.smallBadgeInactive,
//                   ]}>
//                   <Text
//                     style={[
//                       styles.smallBadgeText,
//                       m.status === 'ACTIVE'
//                         ? styles.smallBadgeTextActive
//                         : styles.smallBadgeTextInactive,
//                     ]}>
//                     {m.status}
//                   </Text>
//                 </View>
//               </View>

//               <Text style={styles.historyMeta}>
//                 {formatDate(m.start_date)} → {formatDate(m.expiry_date)}
//                 {m.seat_number ? ` • Seat ${m.seat_number}` : ''}
//               </Text>

//               <View style={styles.historyAmounts}>
//                 <Text style={styles.historySmall}>
//                   Final {formatMoney(m.final_amount)}
//                 </Text>
//                 <Text
//                   style={[
//                     styles.historySmall,
//                     {color: COLORS.success},
//                   ]}>
//                   Paid {formatMoney(m.paid_amount)}
//                 </Text>
//                 <Text
//                   style={[
//                     styles.historySmall,
//                     {
//                       color:
//                         Number(m.due_amount) > 0
//                           ? COLORS.danger
//                           : COLORS.textSecondary,
//                     },
//                   ]}>
//                   Due {formatMoney(m.due_amount)}
//                 </Text>
//               </View>
//             </View>
//           ))}
//         </View>
//       )}

//       <View style={styles.section}>
//         <Text style={styles.sectionTitle}>
//           Payment History ({payments.length})
//         </Text>

//         {payments.length === 0 ? (
//           <Text style={styles.noData}>No payments yet.</Text>
//         ) : (
//           payments.map(p => (
//             <View key={p.id} style={styles.historyCard}>
//               <View style={styles.historyTop}>
//                 <Text style={styles.historyPlan}>
//                   {p.payment_number}
//                 </Text>
//                 <Text
//                   style={{
//                     color: COLORS.success,
//                     fontWeight: '800',
//                     fontSize: 14,
//                   }}>
//                   {formatMoney(p.amount)}
//                 </Text>
//               </View>

//               <Text style={styles.historyMeta}>
//                 {formatDate(p.payment_date)} • {p.method_name}
//                 {p.remarks ? ` • ${p.remarks}` : ''}
//               </Text>
//             </View>
//           ))
//         )}
//       </View>

//       <View style={styles.section}>
//         <Text style={styles.sectionTitle}>
//           Receipts ({receipts.length})
//         </Text>

//         {receipts.length === 0 ? (
//           <Text style={styles.noData}>No receipts yet.</Text>
//         ) : (
//           receipts.map(r => (
//             <Pressable
//               key={r.id}
//               style={styles.historyCard}
//               onPress={() =>
//                 navigation.navigate('ReceiptDetails', {receipt: r})
//               }>
//               <View style={styles.historyTop}>
//                 <Text style={styles.historyPlan}>
//                   {r.receipt_number}
//                 </Text>
//                 <Text
//                   style={{
//                     color: COLORS.text,
//                     fontWeight: '800',
//                     fontSize: 13,
//                   }}>
//                   {formatMoney(r.amount)}
//                 </Text>
//               </View>

//               <Text style={styles.historyMeta}>
//                 {formatDate(r.receipt_date)} • {r.method_name}
//               </Text>

//               <Pressable
//                 style={styles.waInline}
//                 onPress={() => shareReceiptOnWhatsApp(r)}>
//                 <Text style={styles.waInlineText}>
//                   Share on WhatsApp
//                 </Text>
//               </Pressable>
//             </Pressable>
//           ))
//         )}
//       </View>
//     </ScrollView>
//   );
// };

// const Section = ({title, children}) => (
//   <View style={styles.section}>
//     <Text style={styles.sectionTitle}>{title}</Text>
//     <View style={styles.card}>{children}</View>
//   </View>
// );

// const Info = ({label, value, highlight}) => (
//   <View style={styles.info}>
//     <Text style={styles.infoLabel}>{label}</Text>
//     <Text
//       style={[styles.infoValue, highlight && styles.highlight]}
//       numberOfLines={3}>
//       {value}
//     </Text>
//   </View>
// );

// const styles = StyleSheet.create({
//   screen: {flex: 1, backgroundColor: COLORS.background},
//   content: {padding: 20, paddingBottom: 50},
//   loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
//   back: {
//     color: COLORS.primary, fontSize: 15,
//     fontWeight: '700', marginBottom: 22,
//   },
//   profile: {alignItems: 'center', marginBottom: 20},
//   avatar: {
//     width: 76, height: 76, borderRadius: 25,
//     backgroundColor: '#DBEAFE',
//     alignItems: 'center', justifyContent: 'center',
//   },
//   avatarText: {color: COLORS.primary, fontSize: 28, fontWeight: '800'},
//   name: {color: COLORS.text, fontSize: 24, fontWeight: '800', marginTop: 13},
//   code: {color: COLORS.textSecondary, marginTop: 4},
//   badge: {
//     backgroundColor: COLORS.successBg,
//     paddingHorizontal: 12, paddingVertical: 6,
//     borderRadius: 20, marginTop: 10,
//   },
//   badgeInactive: {backgroundColor: COLORS.dangerBg},
//   badgeText: {color: COLORS.success, fontSize: 11, fontWeight: '800'},
//   badgeTextInactive: {color: COLORS.danger},

//   statsRow: {flexDirection: 'row', gap: 10, marginBottom: 14},
//   statBox: {
//     flex: 1, backgroundColor: COLORS.white,
//     borderRadius: 14, borderWidth: 1,
//     borderColor: COLORS.border,
//     padding: 12, alignItems: 'center',
//   },
//   statLabel: {
//     color: COLORS.textSecondary, fontSize: 10,
//     fontWeight: '600', marginBottom: 4,
//   },
//   statValue: {fontSize: 15, fontWeight: '900', color: COLORS.text},

//   actionsRow: {flexDirection: 'row', gap: 10, marginBottom: 12},
//   actionButton: {
//     flex: 1, height: 48, borderRadius: 13,
//     alignItems: 'center', justifyContent: 'center',
//   },
//   actionPrimary: {backgroundColor: COLORS.primary},
//   actionPrimaryText: {
//     color: COLORS.white, fontWeight: '800', fontSize: 14,
//   },
//   actionDanger: {backgroundColor: COLORS.dangerBg},
//   actionDangerText: {
//     color: COLORS.danger, fontWeight: '800', fontSize: 14,
//   },
//   actionSecondary: {
//     backgroundColor: COLORS.white,
//     borderWidth: 1, borderColor: COLORS.primary,
//   },
//   actionSecondaryText: {
//     color: COLORS.primary, fontWeight: '800', fontSize: 13,
//   },

//   section: {marginBottom: 20},
//   sectionTitle: {
//     fontSize: 17, color: COLORS.text,
//     fontWeight: '800', marginBottom: 10,
//   },
//   card: {
//     backgroundColor: COLORS.white, borderRadius: 17,
//     borderWidth: 1, borderColor: COLORS.border,
//     paddingHorizontal: 16,
//   },
//   info: {
//     minHeight: 52, flexDirection: 'row',
//     alignItems: 'center', justifyContent: 'space-between',
//     borderBottomWidth: 1, borderBottomColor: '#F1F1F1',
//     paddingVertical: 10,
//   },
//   infoLabel: {color: COLORS.textSecondary, fontSize: 13},
//   infoValue: {
//     color: COLORS.text, fontSize: 13, fontWeight: '700',
//     maxWidth: '60%', textAlign: 'right',
//   },
//   highlight: {color: COLORS.danger},
//   noData: {paddingVertical: 20, color: COLORS.textSecondary},

//   historyCard: {
//     backgroundColor: COLORS.white, borderRadius: 14,
//     borderWidth: 1, borderColor: COLORS.border,
//     padding: 13, marginBottom: 8,
//   },
//   historyTop: {
//     flexDirection: 'row', justifyContent: 'space-between',
//     alignItems: 'center', marginBottom: 6,
//   },
//   historyPlan: {
//     color: COLORS.text, fontWeight: '800', fontSize: 13,
//   },
//   historyMeta: {
//     color: COLORS.textSecondary, fontSize: 11,
//   },
//   historyAmounts: {
//     flexDirection: 'row', gap: 12, marginTop: 8,
//   },
//   historySmall: {fontSize: 11, color: COLORS.textSecondary},
//   smallBadge: {
//     paddingVertical: 3, paddingHorizontal: 8, borderRadius: 10,
//   },
//   smallBadgeActive: {backgroundColor: COLORS.successBg},
//   smallBadgeInactive: {backgroundColor: COLORS.dangerBg},
//   smallBadgeText: {fontSize: 9, fontWeight: '800'},
//   smallBadgeTextActive: {color: COLORS.success},
//   smallBadgeTextInactive: {color: COLORS.danger},
//   waInline: {
//     marginTop: 8, alignSelf: 'flex-start',
//     paddingVertical: 5, paddingHorizontal: 10,
//     borderRadius: 20, backgroundColor: '#25D366',
//   },
//   waInlineText: {
//     color: COLORS.white, fontSize: 10, fontWeight: '800',
//   },
// });

// export default StudentDetailsScreen;
import React, {useCallback, useState} from 'react';

import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  Modal
} from 'react-native';

import {useFocusEffect} from '@react-navigation/native';

import {
  getStudentApi,
  deleteStudentApi,
  updateStudentApi,
} from '../../api/students';

import {
  getMembershipsApi,
  cancelMembershipApi,
} from '../../api/fees';

import {getPaymentsApi} from '../../api/payments';
import {getReceiptsApi} from '../../api/receipts';

import {COLORS} from '../../constants/colors';

import {shareReceiptOnWhatsApp} from '../../utils/shareReceipt';
import { getAvailableSeatsApi,updateMembershipSeatApi } from '../../api/seats';
const formatMoney = value => {
  const number = Number(value || 0);
  return `₹${number.toLocaleString('en-IN')}`;
};

const formatDate = value => {
  if (!value) return '—';
  const date = new Date(value);
  if (isNaN(date.getTime())) return String(value).slice(0, 10);
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const StudentDetailsScreen = ({route, navigation}) => {
  const {studentId} = route.params;

  const [student, setStudent] = useState(null);
  const [memberships, setMemberships] = useState([]);
  const [payments, setPayments] = useState([]);
  const [receipts, setReceipts] = useState([]);
  const [loading, setLoading] = useState(true);

   // Seat Modal State
  const [showSeatModal, setShowSeatModal] = useState(false);
  const [availableSeats, setAvailableSeats] = useState([]);
  const [loadingSeats, setLoadingSeats] = useState(false);
  const [selectedSeatId, setSelectedSeatId] = useState(null);

  const loadData = useCallback(async () => {
    try {
      const [studentRes, membershipRes, paymentsRes, receiptsRes] =
        await Promise.all([
          getStudentApi(studentId),
          getMembershipsApi(studentId),
          getPaymentsApi({student_id: studentId}),
          getReceiptsApi(),
        ]);

      if (studentRes?.status?.code === 200) setStudent(studentRes.data);
      if (membershipRes?.status?.code === 200) setMemberships(membershipRes.data || []);
      if (paymentsRes?.status?.code === 200) setPayments(paymentsRes.data || []);
      
      if (receiptsRes?.status?.code === 200) {
        const paymentIds = new Set((paymentsRes?.data || []).map(p => Number(p.id)));
        setReceipts((receiptsRes.data || []).filter(r => paymentIds.has(Number(r.payment_id))));
      }
    } catch (error) {
      Alert.alert('Error', 'Unable to load student.');
    } finally {
      setLoading(false);
    }
  }, [studentId]);

  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      loadData();
    }, [loadData]),
  );

  // 👉 NEW: Handle Student Leaving
  const handleStudentLeave = (activeMembership) => {
    const message = activeMembership
      ? 'This will cancel their current membership, free up their seat, and mark the student as inactive. Proceed?'
      : 'This will mark the student as inactive. Proceed?';

    Alert.alert('Student Leaving?', message, [
      {text: 'Cancel', style: 'cancel'},
      {
        text: 'Yes, Mark as Left',
        style: 'destructive',
        onPress: async () => {
          try {
            setLoading(true);
            
            // 1. Cancel membership if it exists
            if (activeMembership) {
              await cancelMembershipApi(activeMembership.id);
            }
            
            // 2. Deactivate student
            await deleteStudentApi(studentId);
            
            // 3. Reload data (student will now show as INACTIVE)
            await loadData();
            Alert.alert('Success', 'Student marked as left and seat is now free.');
          } catch (error) {
            Alert.alert('Error', 'Could not complete the leave process.');
            setLoading(false);
          }
        },
      },
    ]);
  };

  const reactivate = async () => {
    try {
      setLoading(true);
      await updateStudentApi(studentId, {status: 'ACTIVE'});
      await loadData();
    } catch (error) {
      Alert.alert('Error', 'Unable to reactivate student.');
      setLoading(false);
    }
  };

  const handleUpgrade = (activeMembership) => {
    Alert.alert(
      'Change Plan / Upgrade',
      'This will cancel the current membership and free up the seat. Do you want to proceed?',
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Proceed',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              await cancelMembershipApi(activeMembership.id);
              await loadData();

              let nextSlot = 'FULL_TIME';
              if (activeMembership.slot_type === 'FULL_TIME') nextSlot = 'HALF_MORNING';
              else if (activeMembership.slot_type === 'HALF_MORNING') nextSlot = 'HALF_EVENING';
              else if (activeMembership.slot_type === 'HALF_EVENING') nextSlot = 'FULL_TIME';

              navigation.navigate('AddMembership', {
                studentId: studentId,
                suggestedSlot: nextSlot,
              });
            } catch (err) {
              Alert.alert('Error', 'Could not change plan.');
              setLoading(false);
            }
          },
        },
      ],
    );
  };

  // Open Seat Modal and fetch available seats for this slot
  const openSeatModal = async () => {
    if (!activeMembership) return;
    setShowSeatModal(true);
    setLoadingSeats(true);
    setSelectedSeatId(activeMembership.seat_id || null);
    
    try {
      const res = await getAvailableSeatsApi(student?.gender || 'ANY', activeMembership.slot_type);
      if (res?.status?.code === 200) {
        setAvailableSeats(res.data || []);
      }
    } catch (err) {
      Alert.alert('Error', 'Could not load seats.');
    } finally {
      setLoadingSeats(false);
    }
  };

  // Save the new seat
  const saveSeatChange = async () => {
    if (!activeMembership) return;
    setLoading(true);
    setShowSeatModal(false);

    try {
      const res = await updateMembershipSeatApi(activeMembership.id, selectedSeatId);

      if (res.status?.code === 200) {
        Alert.alert('Success', res.status?.message || 'Could not change seat');
        await loadData();
      } else {
        Alert.alert('Failed', res.status?.message || 'Could not change seat');
        setLoading(false);
      }
    } catch (err) {
      Alert.alert('Error', err?.response?.data?.status?.message || 'Could not change seat');
      setLoading(false);
    }
  };


  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  if (!student) return null;

  const isActive = student.status === 'ACTIVE';
  const activeMembership = memberships.find(m => m.status === 'ACTIVE');

  // const totalPaid = payments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
  // const totalDue = memberships.reduce((sum, m) => sum + Number(m.due_amount || 0), 0);
    // ✅ USE VALUES FROM BACKEND
  const totalPaid = student?.total_paid || 0;
  const totalDue = student?.total_due || 0;
  const totalMemberships = student?.membership_count || 0;

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Pressable onPress={() => navigation.goBack()}>
        <Text style={styles.back}>‹  Students</Text>
      </Pressable>

      <View style={styles.profile}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {student.full_name?.charAt(0)?.toUpperCase()}
          </Text>
        </View>
        <Text style={styles.name}>{student.full_name}</Text>
        <Text style={styles.code}>{student.student_code}</Text>
        <View style={[styles.badge, !isActive && styles.badgeInactive]}>
          <Text style={[styles.badgeText, !isActive && styles.badgeTextInactive]}>
            {student.status}
          </Text>
        </View>
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>Total Paid</Text>
          <Text style={[styles.statValue, {color: COLORS.success}]}>
            {formatMoney(totalPaid)}
          </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>Total Due</Text>
          <Text style={[styles.statValue, {color: totalDue > 0 ? COLORS.danger : COLORS.textSecondary}]}>
            {formatMoney(totalDue)}
          </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>Memberships</Text>
          <Text style={styles.statValue}>{memberships.length}</Text>
        </View>
      </View>

      <View style={styles.actionsRow}>
        <Pressable
          style={[styles.actionButton, styles.actionPrimary]}
          onPress={() => navigation.navigate('AddStudent', {studentId})}>
          <Text style={styles.actionPrimaryText}>Edit</Text>
        </Pressable>
        
        {isActive ? (
          <Pressable
            style={[styles.actionButton, styles.actionDanger]}
            onPress={() => handleStudentLeave(activeMembership)}>
            <Text style={styles.actionDangerText}>Mark as Left</Text>
          </Pressable>
        ) : (
          <Pressable
            style={[styles.actionButton, {backgroundColor: COLORS.success}]}
            onPress={reactivate}>
            <Text style={[styles.actionPrimaryText, {color: COLORS.white}]}>
              Reactivate
            </Text>
          </Pressable>
        )}
      </View>

      {/* {isActive && (
        <View style={styles.actionsRow}>
          <Pressable
            style={[styles.actionButton, styles.actionSecondary]}
            onPress={() => navigation.navigate('AddMembership', {studentId})}>
            <Text style={styles.actionSecondaryText}>+ New Membership</Text>
          </Pressable>
          <Pressable
            style={[styles.actionButton, styles.actionSecondary]}
            onPress={() => navigation.navigate('AddPayment', {studentId})}>
            <Text style={styles.actionSecondaryText}>+ Payment</Text>
          </Pressable>
        </View>
      )} */}
            {/* Action Buttons: New Membership OR Payment depending on status */}
      {isActive && (
        <View style={styles.actionsRow}>
          {!activeMembership ? (
            // Show New Membership only if there is NO active membership
            <Pressable
              style={[styles.actionButton, styles.actionSecondary]}
              onPress={() => navigation.navigate('AddMembership', {studentId})}>
              <Text style={styles.actionSecondaryText}>+ New Membership</Text>
            </Pressable>
          ) : (
            // Show Payment only if there IS an active membership
            <Pressable
              style={[styles.actionButton, styles.actionSecondary]}
              onPress={() => navigation.navigate('AddPayment', {studentId})}>
              <Text style={styles.actionSecondaryText}>+ Payment</Text>
            </Pressable>
          )}
        </View>
      )}

      <Section title="Contact">
        <Info label="Mobile" value={student.mobile} />
        <Info label="Alternate mobile" value={student.alternate_mobile || '—'} />
        {/* <Info label="Gender" value={student.gender} /> */}
        {/* <Info label="Father" value={student.father_name || '—'} /> */}
        {/* <Info label="Address" value={student.address || '—'} /> */}

        {/* <Info label="Email" value={student.email || '—'} /> */}
      </Section>

      {/* <Section title="Personal"> */}
        {/* <Info label="Gender" value={student.gender} /> */}
        {/* <Info label="Date of birth" value={student.date_of_birth || '—'} />
        <Info label="Aadhaar" value={student.aadhar_number || '—'} /> */}
      {/* </Section> */}

      {/* <Section title="Family">
        <Info label="Father" value={student.father_name || '—'} />
        <Info label="Mother" value={student.mother_name || '—'} />
      </Section> */}

      {/* <Section title="Address">
        <Info label="Address" value={student.address || '—'} />
        <Info label="City" value={student.city || '—'} />
        <Info label="State" value={student.state || '—'} />
        <Info label="Pincode" value={student.pincode || '—'} />
      </Section> */}

      {/* <Section title="Emergency contact">
        <Info label="Name" value={student.emergency_contact_name || '—'} />
        <Info label="Mobile" value={student.emergency_contact_mobile || '—'} />
      </Section> */}

      <Section title="Current Membership">
        <>
        {activeMembership ? (
          <>
            <Info label="Plan" value={activeMembership.plan_name} />
            <Info label="Slot" value={activeMembership.slot_type?.replace('_', ' ')} />
            <Info label="Seat" value={activeMembership.seat_number || 'Not assigned'} />
            <Info label="Start" value={formatDate(activeMembership.start_date)} />
            <Info label="Expiry" value={formatDate(activeMembership.expiry_date)} />
            <Info label="Final amount" value={formatMoney(activeMembership.final_amount)} />
            <Info label="Paid" value={formatMoney(activeMembership.paid_amount)} />
            <Info
              label="Due"
              value={formatMoney(activeMembership.due_amount)}
              highlight={Number(activeMembership.due_amount) > 0}
            />
          </>
        ) : (
          <Text style={styles.noData}>No active membership.</Text>
        )}


            {isActive && (
              <View style={{ marginTop: 16, paddingTop: 16, borderTopWidth: 1, borderTopColor: COLORS.border, gap: 10 }}>
                {/* 👉 NEW: Change Seat Button */}
                <Pressable
                  style={{ backgroundColor: COLORS.primary, padding: 14, borderRadius: 12, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', gap: 8 }}
                  onPress={openSeatModal}
                >
                  <Text style={{ color: COLORS.white, fontWeight: '800', fontSize: 14 }}>
                    🪑 {activeMembership.seat_id ? 'Change Seat' : 'Assign Seat'}
                  </Text>
                </Pressable>

                <Pressable
                  style={{ backgroundColor: COLORS.warningBg, padding: 14, borderRadius: 12, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', gap: 8 }}
                  onPress={() => handleUpgrade(activeMembership)}
                >
                  <Text style={{ color: COLORS.warning, fontWeight: '800', fontSize: 14 }}>🔄 Upgrade / Change Plan</Text>
                </Pressable>
              </View>

              // <View style={{ marginTop: 16, paddingTop: 16, borderTopWidth: 1, borderTopColor: COLORS.border }}>
              //   <Pressable
              //     style={{
              //       backgroundColor: COLORS.warningBg,
              //       padding: 14,
              //       borderRadius: 12,
              //       alignItems: 'center',
              //       flexDirection: 'row',
              //       justifyContent: 'center',
              //       gap: 8,
              //     }}
              //     onPress={() => handleUpgrade(activeMembership)}
              //   >
              //     <Text style={{ color: COLORS.warning, fontWeight: '800', fontSize: 14 }}>
              //       🔄 Upgrade / Change Plan
              //     </Text>
              //   </Pressable>
              // </View>
            )}
          </>
      </Section>

      {memberships.length > 1 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Membership History ({memberships.length})</Text>
          {memberships.map(m => (
            <View key={m.id} style={styles.historyCard}>
              <View style={styles.historyTop}>
                <Text style={styles.historyPlan}>{m.plan_name}</Text>
                <View style={[styles.smallBadge, m.status === 'ACTIVE' ? styles.smallBadgeActive : styles.smallBadgeInactive]}>
                  <Text style={[styles.smallBadgeText, m.status === 'ACTIVE' ? styles.smallBadgeTextActive : styles.smallBadgeTextInactive]}>
                    {m.status}
                  </Text>
                </View>
              </View>
              <Text style={styles.historyMeta}>
                {formatDate(m.start_date)} → {formatDate(m.expiry_date)}
                {m.seat_number ? ` • Seat ${m.seat_number}` : ''}
              </Text>
              <View style={styles.historyAmounts}>
                <Text style={styles.historySmall}>Final {formatMoney(m.final_amount)}</Text>
                <Text style={[styles.historySmall, {color: COLORS.success}]}>Paid {formatMoney(m.paid_amount)}</Text>
                <Text style={[styles.historySmall, {color: Number(m.due_amount) > 0 ? COLORS.danger : COLORS.textSecondary}]}>
                  Due {formatMoney(m.due_amount)}
                </Text>
              </View>
            </View>
          ))}
        </View>
      )}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Payment History ({payments.length})</Text>
        {payments.length === 0 ? (
          <Text style={styles.noData}>No payments yet.</Text>
        ) : (
          payments.map(p => (
            <View key={p.id} style={styles.historyCard}>
              <View style={styles.historyTop}>
                <Text style={styles.historyPlan}>{p.payment_number}</Text>
                <Text style={{ color: COLORS.success, fontWeight: '800', fontSize: 14 }}>
                  {formatMoney(p.amount)}
                </Text>
              </View>
              <Text style={styles.historyMeta}>
                {formatDate(p.payment_date)} • {p.method_name}
                {p.remarks ? ` • ${p.remarks}` : ''}
              </Text>
            </View>
          ))
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Receipts ({receipts.length})</Text>
        {receipts.length === 0 ? (
          <Text style={styles.noData}>No receipts yet.</Text>
        ) : (
          receipts.map(r => (
            <Pressable
              key={r.id}
              style={styles.historyCard}
              onPress={() => navigation.navigate('ReceiptDetails', {receipt: r})}>
              <View style={styles.historyTop}>
                <Text style={styles.historyPlan}>{r.receipt_number}</Text>
                <Text style={{ color: COLORS.text, fontWeight: '800', fontSize: 13 }}>
                  {formatMoney(r.amount)}
                </Text>
              </View>
              <Text style={styles.historyMeta}>
                {formatDate(r.receipt_date)} • {r.method_name}
              </Text>
              <Pressable style={styles.waInline} onPress={() => shareReceiptOnWhatsApp(r)}>
                <Text style={styles.waInlineText}>Share on WhatsApp</Text>
              </Pressable>
            </Pressable>
          ))
        )}
      </View>


      {/* 👉 NEW: Seat Selection Modal */}
            {/* 👉 Seat Selection Modal */}
      <Modal visible={showSeatModal} transparent animationType="slide" onRequestClose={() => setShowSeatModal(false)}>
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBg} onPress={() => setShowSeatModal(false)} />
          <View style={styles.bottomSheet}>
            <View style={styles.sheetHandle} />
            
            {/* 👉 Added Header with Close Button */}
            <View style={styles.sheetHeader}>
              <View>
                <Text style={styles.sheetTitle}>Select a Seat</Text>
                <Text style={styles.sheetSub}>Slot: {activeMembership?.slot_type.replace('_', ' ')}</Text>
              </View>
              <Pressable style={styles.closeButton} onPress={() => setShowSeatModal(false)}>
                <Text style={styles.closeText}>✕</Text>
              </Pressable>
            </View>

            {loadingSeats ? (
              <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 20 }} />
            ) : (
              <ScrollView style={{ maxHeight: 300, marginTop: 10 }}>
                <Pressable
                  style={[styles.seatItem, selectedSeatId === null && styles.seatItemActive]}
                  onPress={() => setSelectedSeatId(null)}
                >
                  <Text style={[styles.seatItemText, selectedSeatId === null && styles.seatItemTextActive]}>
                    No Seat / Unassigned
                  </Text>
                </Pressable>

                {availableSeats.map((seat) => (
                  <Pressable
                    key={seat.id}
                    style={[styles.seatItem, selectedSeatId === seat.id && styles.seatItemActive]}
                    onPress={() => setSelectedSeatId(seat.id)}
                  >
                    <Text style={[styles.seatItemText, selectedSeatId === seat.id && styles.seatItemTextActive]}>
                      Seat {seat.seat_number}
                    </Text>
                  </Pressable>
                ))}
                
                {availableSeats.length === 0 && (
                  <Text style={{ textAlign: 'center', color: COLORS.textSecondary, marginTop: 20 }}>
                    No other seats available for this slot.
                  </Text>
                )}
              </ScrollView>
            )}

            <Pressable style={styles.saveBtn} onPress={saveSeatChange}>
              <Text style={styles.saveBtnText}>Save Seat</Text>
            </Pressable>
          </View>
        </View>
      </Modal>


    </ScrollView>
  );
};

const Section = ({title, children}) => (
  <View style={styles.section}>
    {/* <Text style={styles.sectionTitle}>{title}</Text> */}
    <View style={styles.card}>{children}</View>
  </View>
);

const Info = ({label, value, highlight}) => (
  <View style={styles.info}>
    <Text style={styles.infoLabel}>{label}</Text>
    <Text style={[styles.infoValue, highlight && styles.highlight]} numberOfLines={3}>
      {value}
    </Text>
  </View>
);

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  content: {padding: 20, paddingBottom: 50},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  back: {color: COLORS.primary, fontSize: 15, fontWeight: '700', marginBottom: 22},
  profile: {alignItems: 'center', marginBottom: 20},
  avatar: {width: 76, height: 76, borderRadius: 25, backgroundColor: '#DBEAFE', alignItems: 'center', justifyContent: 'center'},
  avatarText: {color: COLORS.primary, fontSize: 28, fontWeight: '800'},
  name: {color: COLORS.text, fontSize: 24, fontWeight: '800', marginTop: 13},
  code: {color: COLORS.textSecondary, marginTop: 4},
  badge: {backgroundColor: COLORS.successBg, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, marginTop: 10},
  badgeInactive: {backgroundColor: COLORS.dangerBg},
  badgeText: {color: COLORS.success, fontSize: 11, fontWeight: '800'},
  badgeTextInactive: {color: COLORS.danger},
  statsRow: {flexDirection: 'row', gap: 10, marginBottom: 14},
  statBox: {flex: 1, backgroundColor: COLORS.white, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, padding: 12, alignItems: 'center'},
  statLabel: {color: COLORS.textSecondary, fontSize: 10, fontWeight: '600', marginBottom: 4},
  statValue: {fontSize: 15, fontWeight: '900', color: COLORS.text},
  actionsRow: {flexDirection: 'row', gap: 10, marginBottom: 12},
  actionButton: {flex: 1, height: 48, borderRadius: 13, alignItems: 'center', justifyContent: 'center'},
  actionPrimary: {backgroundColor: COLORS.primary},
  actionPrimaryText: {color: COLORS.white, fontWeight: '800', fontSize: 14},
  actionDanger: {backgroundColor: COLORS.dangerBg},
  actionDangerText: {color: COLORS.danger, fontWeight: '800', fontSize: 14},
  actionSecondary: {backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.primary},
  actionSecondaryText: {color: COLORS.primary, fontWeight: '800', fontSize: 13},
  section: {marginBottom: 20},
  sectionTitle: {fontSize: 17, color: COLORS.text, fontWeight: '800', marginBottom: 10},
  card: {backgroundColor: COLORS.white, borderRadius: 17, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 16},
  info: {minHeight: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#F1F1F1', paddingVertical: 10},
  infoLabel: {color: COLORS.textSecondary, fontSize: 13},
  infoValue: {color: COLORS.text, fontSize: 13, fontWeight: '700', maxWidth: '60%', textAlign: 'right'},
  highlight: {color: COLORS.danger},
  noData: {paddingVertical: 20, color: COLORS.textSecondary},
  historyCard: {backgroundColor: COLORS.white, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, padding: 13, marginBottom: 8},
  historyTop: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6},
  historyPlan: {color: COLORS.text, fontWeight: '800', fontSize: 13},
  historyMeta: {color: COLORS.textSecondary, fontSize: 11},
  historyAmounts: {flexDirection: 'row', gap: 12, marginTop: 8},
  historySmall: {fontSize: 11, color: COLORS.textSecondary},
  smallBadge: {paddingVertical: 3, paddingHorizontal: 8, borderRadius: 10},
  smallBadgeActive: {backgroundColor: COLORS.successBg},
  smallBadgeInactive: {backgroundColor: COLORS.dangerBg},
  smallBadgeText: {fontSize: 9, fontWeight: '800'},
  smallBadgeTextActive: {color: COLORS.success},
  smallBadgeTextInactive: {color: COLORS.danger},
  waInline: {marginTop: 8, alignSelf: 'flex-start', paddingVertical: 5, paddingHorizontal: 10, borderRadius: 20, backgroundColor: '#25D366'},
  waInlineText: {color: COLORS.white, fontSize: 10, fontWeight: '800'},
  modalOverlay: {flex: 1, justifyContent: 'flex-end'},
  modalBg: {...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.5)'},
  bottomSheet: {backgroundColor: COLORS.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40},
  sheetHandle: {width: 40, height: 4, backgroundColor: COLORS.border, borderRadius: 2, alignSelf: 'center', marginBottom: 16},
  sheetTitle: {fontSize: 20, fontWeight: '900', color: COLORS.text},
  sheetSub: {fontSize: 13, color: COLORS.textSecondary, marginBottom: 16},
  seatItem: {padding: 16, borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, marginBottom: 8, backgroundColor: COLORS.white},
  seatItemActive: {backgroundColor: COLORS.primary, borderColor: COLORS.primary},
  seatItemText: {fontSize: 15, fontWeight: '700', color: COLORS.text},
  seatItemTextActive: {color: COLORS.white},
  saveBtn: {backgroundColor: COLORS.primary, height: 52, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginTop: 16},
  saveBtnText: {color: COLORS.white, fontWeight: '800', fontSize: 15},
});

export default StudentDetailsScreen;


// import React, {useCallback, useState} from 'react';

// import {
//   ActivityIndicator,
//   Alert,
//   Pressable,
//   ScrollView,
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {
//   getStudentApi,
//   deleteStudentApi,
// } from '../../api/students';

// import {getMembershipsApi} from '../../api/fees';

// import {COLORS} from '../../constants/colors';

// const StudentDetailsScreen = ({route, navigation}) => {
//   const {studentId} = route.params;

//   const [student, setStudent] = useState(null);
//   const [membership, setMembership] = useState(null);
//   const [loading, setLoading] = useState(true);

//   const loadData = useCallback(async () => {
//     try {
//       const [studentRes, membershipRes] = await Promise.all([
//         getStudentApi(studentId),
//         getMembershipsApi(studentId),
//       ]);

//       if (studentRes?.status?.code === 200) {
//         setStudent(studentRes.data);
//       }

//       if (membershipRes?.status?.code === 200) {
//         setMembership(membershipRes.data?.[0] || null);
//       }
//     } catch (error) {
//       Alert.alert('Error', 'Unable to load student.');
//     } finally {
//       setLoading(false);
//     }
//   }, [studentId]);

//   useFocusEffect(
//     useCallback(() => {
//       loadData();
//     }, [loadData]),
//   );

//   const deactivate = () => {
//     Alert.alert(
//       'Deactivate student',
//       'Are you sure you want to deactivate this student?',
//       [
//         {text: 'Cancel', style: 'cancel'},
//         {
//           text: 'Deactivate',
//           style: 'destructive',
//           onPress: async () => {
//             try {
//               await deleteStudentApi(studentId);
//               navigation.goBack();
//             } catch (error) {
//               Alert.alert('Error', 'Unable to deactivate student.');
//             }
//           },
//         },
//       ],
//     );
//   };

//   if (loading) {
//     return (
//       <View style={styles.loader}>
//         <ActivityIndicator size="large" color={COLORS.primary} />
//       </View>
//     );
//   }

//   if (!student) return null;

//   const isActive = student.status === 'ACTIVE';

//   return (
//     <ScrollView
//       style={styles.screen}
//       contentContainerStyle={styles.content}>
//       <Pressable onPress={() => navigation.goBack()}>
//         <Text style={styles.back}>‹  Students</Text>
//       </Pressable>

//       <View style={styles.profile}>
//         <View style={styles.avatar}>
//           <Text style={styles.avatarText}>
//             {student.full_name?.charAt(0)?.toUpperCase()}
//           </Text>
//         </View>

//         <Text style={styles.name}>{student.full_name}</Text>
//         <Text style={styles.code}>{student.student_code}</Text>

//         <View
//           style={[
//             styles.badge,
//             !isActive && styles.badgeInactive,
//           ]}>
//           <Text
//             style={[
//               styles.badgeText,
//               !isActive && styles.badgeTextInactive,
//             ]}>
//             {student.status}
//           </Text>
//         </View>
//       </View>

//       {/* Actions */}
//       <View style={styles.actionsRow}>
//         <Pressable
//           style={[styles.actionButton, styles.actionPrimary]}
//           onPress={() =>
//             navigation.navigate('AddStudent', {studentId})
//           }>
//           <Text style={styles.actionPrimaryText}>Edit</Text>
//         </Pressable>

//         {isActive && (
//           <Pressable
//             style={[styles.actionButton, styles.actionDanger]}
//             onPress={deactivate}>
//             <Text style={styles.actionDangerText}>Deactivate</Text>
//           </Pressable>
//         )}
//       </View>

//       <Section title="Contact">
//         <Info label="Mobile" value={student.mobile} />
//         <Info
//           label="Alternate mobile"
//           value={student.alternate_mobile || '—'}
//         />
//         <Info label="Email" value={student.email || '—'} />
//       </Section>

//       <Section title="Personal">
//         <Info label="Gender" value={student.gender} />
//         <Info
//           label="Date of birth"
//           value={student.date_of_birth || '—'}
//         />
//         <Info
//           label="Aadhaar"
//           value={student.aadhar_number || '—'}
//         />
//       </Section>

//       <Section title="Family">
//         <Info
//           label="Father"
//           value={student.father_name || '—'}
//         />
//         <Info
//           label="Mother"
//           value={student.mother_name || '—'}
//         />
//       </Section>

//       <Section title="Address">
//         <Info
//           label="Address"
//           value={student.address || '—'}
//         />
//         <Info label="City" value={student.city || '—'} />
//         <Info label="State" value={student.state || '—'} />
//         <Info label="Pincode" value={student.pincode || '—'} />
//       </Section>

//       <Section title="Emergency contact">
//         <Info
//           label="Name"
//           value={student.emergency_contact_name || '—'}
//         />
//         <Info
//           label="Mobile"
//           value={student.emergency_contact_mobile || '—'}
//         />
//       </Section>

//       <Section title="Membership">
//         {membership ? (
//           <>
//             <Info label="Plan" value={membership.plan_name} />
//             <Info
//               label="Seat"
//               value={membership.seat_number || 'Not assigned'}
//             />
//             <Info label="Start" value={membership.start_date} />
//             <Info label="Expiry" value={membership.expiry_date} />
//             <Info
//               label="Final amount"
//               value={`₹${Number(membership.final_amount).toLocaleString('en-IN')}`}
//             />
//             <Info
//               label="Paid"
//               value={`₹${Number(membership.paid_amount).toLocaleString('en-IN')}`}
//             />
//             <Info
//               label="Due"
//               value={`₹${Number(membership.due_amount).toLocaleString('en-IN')}`}
//               highlight={Number(membership.due_amount) > 0}
//             />
//           </>
//         ) : (
//           <Text style={styles.noData}>No active membership.</Text>
//         )}
//       </Section>
//     </ScrollView>
//   );
// };

// const Section = ({title, children}) => (
//   <View style={styles.section}>
//     <Text style={styles.sectionTitle}>{title}</Text>
//     <View style={styles.card}>{children}</View>
//   </View>
// );

// const Info = ({label, value, highlight}) => (
//   <View style={styles.info}>
//     <Text style={styles.infoLabel}>{label}</Text>
//     <Text
//       style={[styles.infoValue, highlight && styles.highlight]}
//       numberOfLines={3}>
//       {value}
//     </Text>
//   </View>
// );

// const styles = StyleSheet.create({
//   screen: {flex: 1, backgroundColor: COLORS.background},
//   content: {padding: 20, paddingBottom: 50},
//   loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
//   back: {
//     color: COLORS.primary, fontSize: 15,
//     fontWeight: '700', marginBottom: 22,
//   },
//   profile: {alignItems: 'center', marginBottom: 20},
//   avatar: {
//     width: 76, height: 76, borderRadius: 25,
//     backgroundColor: '#DBEAFE',
//     alignItems: 'center', justifyContent: 'center',
//   },
//   avatarText: {color: COLORS.primary, fontSize: 28, fontWeight: '800'},
//   name: {color: COLORS.text, fontSize: 24, fontWeight: '800', marginTop: 13},
//   code: {color: COLORS.textSecondary, marginTop: 4},
//   badge: {
//     backgroundColor: COLORS.successBg,
//     paddingHorizontal: 12, paddingVertical: 6,
//     borderRadius: 20, marginTop: 10,
//   },
//   badgeInactive: {backgroundColor: COLORS.dangerBg},
//   badgeText: {color: COLORS.success, fontSize: 11, fontWeight: '800'},
//   badgeTextInactive: {color: COLORS.danger},
//   actionsRow: {
//     flexDirection: 'row', gap: 10, marginBottom: 24,
//   },
//   actionButton: {
//     flex: 1, height: 48, borderRadius: 13,
//     alignItems: 'center', justifyContent: 'center',
//   },
//   actionPrimary: {backgroundColor: COLORS.primary},
//   actionPrimaryText: {
//     color: COLORS.white, fontWeight: '800', fontSize: 14,
//   },
//   actionDanger: {backgroundColor: COLORS.dangerBg},
//   actionDangerText: {
//     color: COLORS.danger, fontWeight: '800', fontSize: 14,
//   },
//   section: {marginBottom: 20},
//   sectionTitle: {
//     fontSize: 17, color: COLORS.text,
//     fontWeight: '800', marginBottom: 10,
//   },
//   card: {
//     backgroundColor: COLORS.white, borderRadius: 17,
//     borderWidth: 1, borderColor: COLORS.border,
//     paddingHorizontal: 16,
//   },
//   info: {
//     minHeight: 52, flexDirection: 'row',
//     alignItems: 'center', justifyContent: 'space-between',
//     borderBottomWidth: 1, borderBottomColor: '#F1F1F1',
//     paddingVertical: 10,
//   },
//   infoLabel: {color: COLORS.textSecondary, fontSize: 13},
//   infoValue: {
//     color: COLORS.text, fontSize: 13, fontWeight: '700',
//     maxWidth: '60%', textAlign: 'right',
//   },
//   highlight: {color: COLORS.danger},
//   noData: {paddingVertical: 20, color: COLORS.textSecondary},
// });

// export default StudentDetailsScreen;