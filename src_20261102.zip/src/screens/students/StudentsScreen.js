// import React, {
//   useCallback,
//   useState,
// } from 'react';

// import {
//   ActivityIndicator,
//   FlatList,
//   Pressable,
//   RefreshControl,
//   StyleSheet,
//   Text,
//   TextInput,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {getStudentsApi} from '../../api/students';

// import {COLORS} from '../../constants/colors';

// const StudentsScreen = ({
//   navigation,
// }) => {
//   const [students, setStudents] =
//     useState([]);

//   const [search, setSearch] =
//     useState('');

//   const [loading, setLoading] =
//     useState(true);

//   const [refreshing, setRefreshing] =
//     useState(false);

//   const loadStudents = async (
//     searchValue = search,
//   ) => {
//     try {
//       const response =
//         await getStudentsApi({
//           search: searchValue,
//         });

//       if (
//         response?.status?.code === 200
//       ) {
//         setStudents(
//           response.data || [],
//         );
//       }
//     } catch (error) {
//       console.log(
//         'Students error:',
//         error,
//       );
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
//   };

//   useFocusEffect(
//     useCallback(() => {
//       loadStudents('');
//     }, []),
//   );

//   const handleSearch = value => {
//     setSearch(value);

//     loadStudents(value);
//   };

//   const renderStudent = ({
//     item,
//   }) => {
//     const initial =
//       item.full_name
//         ?.charAt(0)
//         ?.toUpperCase() || 'S';

//     return (
//       <Pressable
//         style={styles.card}
//         onPress={() =>
//           navigation.navigate(
//             'StudentDetails',
//             {
//               studentId: item.id,
//             },
//           )
//         }>
//         <View style={styles.avatar}>
//           <Text
//             style={
//               styles.avatarText
//             }>
//             {initial}
//           </Text>
//         </View>

//         <View style={styles.info}>
//           <Text
//             style={styles.name}
//             numberOfLines={1}>
//             {item.full_name}
//           </Text>

//           <Text style={styles.code}>
//             {item.student_code}
//           </Text>

//           <Text style={styles.mobile}>
//             {item.mobile}
//           </Text>
//         </View>

//         <View
//           style={[
//             styles.status,
//             item.status === 'ACTIVE'
//               ? styles.active
//               : styles.inactive,
//           ]}>
//           <Text
//             style={[
//               styles.statusText,
//               item.status ===
//                 'ACTIVE' &&
//                 styles.activeText,
//             ]}>
//             {item.status}
//           </Text>
//         </View>
//       </Pressable>
//     );
//   };

//   return (
//     <View style={styles.screen}>
//       <View style={styles.header}>
//         <View>
//           <Text style={styles.title}>
//             Students
//           </Text>

//           <Text style={styles.subtitle}>
//             Manage your study center
//             members
//           </Text>
//         </View>

//         <Pressable
//           style={styles.addButton}
//           onPress={() =>
//             navigation.navigate(
//               'AddStudent',
//             )
//           }>
//           <Text style={styles.addText}>
//             +
//           </Text>
//         </Pressable>
//       </View>

//       <View style={styles.searchBox}>
//         <Text style={styles.searchIcon}>
//           ⌕
//         </Text>

//         <TextInput
//           value={search}
//           onChangeText={
//             handleSearch
//           }
//           placeholder="Search students..."
//           placeholderTextColor={
//             COLORS.textLight
//           }
//           style={styles.searchInput}
//         />
//       </View>

//       {loading ? (
//         <View style={styles.loader}>
//           <ActivityIndicator
//             size="large"
//             color={COLORS.primary}
//           />
//         </View>
//       ) : (
//         <FlatList
//           data={students}
//           keyExtractor={item =>
//             String(item.id)
//           }
//           renderItem={
//             renderStudent
//           }
//           contentContainerStyle={
//             styles.list
//           }
//           refreshControl={
//             <RefreshControl
//               refreshing={
//                 refreshing
//               }
//               onRefresh={() => {
//                 setRefreshing(
//                   true,
//                 );
//                 loadStudents();
//               }}
//             />
//           }
//           ListEmptyComponent={
//             <View
//               style={
//                 styles.empty
//               }>
//               <Text
//                 style={
//                   styles.emptyTitle
//                 }>
//                 No students found
//               </Text>

//               <Text
//                 style={
//                   styles.emptyText
//                 }>
//                 Add your first student
//                 to get started.
//               </Text>
//             </View>
//           }
//         />
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   screen: {
//     flex: 1,
//     backgroundColor: COLORS.background,
//   },

//   header: {
//     paddingHorizontal: 20,
//     paddingTop: 20,
//     paddingBottom: 16,
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//   },

//   title: {
//     fontSize: 28,
//     fontWeight: '800',
//     color: COLORS.text,
//   },

//   subtitle: {
//     color: COLORS.textSecondary,
//     fontSize: 13,
//     marginTop: 4,
//   },

//   addButton: {
//     width: 46,
//     height: 46,
//     borderRadius: 14,
//     backgroundColor: COLORS.primary,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },

//   addText: {
//     color: COLORS.white,
//     fontSize: 28,
//     lineHeight: 30,
//     fontWeight: '400',
//   },

//   searchBox: {
//     marginHorizontal: 20,
//     marginBottom: 12,
//     height: 50,
//     backgroundColor: COLORS.white,
//     borderRadius: 14,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     flexDirection: 'row',
//     alignItems: 'center',
//     paddingHorizontal: 14,
//   },

//   searchIcon: {
//     color: COLORS.textSecondary,
//     fontSize: 23,
//     marginRight: 8,
//   },

//   searchInput: {
//     flex: 1,
//     color: COLORS.text,
//     fontSize: 14,
//   },

//   list: {
//     padding: 20,
//     paddingTop: 5,
//     paddingBottom: 40,
//   },

//   card: {
//     backgroundColor: COLORS.white,
//     borderRadius: 17,
//     padding: 14,
//     marginBottom: 10,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     flexDirection: 'row',
//     alignItems: 'center',
//   },

//   avatar: {
//     width: 48,
//     height: 48,
//     borderRadius: 15,
//     backgroundColor: '#DBEAFE',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },

//   avatarText: {
//     color: COLORS.primary,
//     fontSize: 18,
//     fontWeight: '800',
//   },

//   info: {
//     flex: 1,
//     marginLeft: 13,
//     marginRight: 8,
//   },

//   name: {
//     color: COLORS.text,
//     fontSize: 15,
//     fontWeight: '700',
//   },

//   code: {
//     color: COLORS.primary,
//     fontSize: 11,
//     fontWeight: '700',
//     marginTop: 3,
//   },

//   mobile: {
//     color: COLORS.textSecondary,
//     fontSize: 12,
//     marginTop: 3,
//   },

//   status: {
//     borderRadius: 20,
//     paddingHorizontal: 8,
//     paddingVertical: 5,
//   },

//   active: {
//     backgroundColor: COLORS.successBg,
//   },

//   inactive: {
//     backgroundColor: COLORS.dangerBg,
//   },

//   statusText: {
//     color: COLORS.danger,
//     fontSize: 9,
//     fontWeight: '800',
//   },

//   activeText: {
//     color: COLORS.success,
//   },

//   loader: {
//     flex: 1,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },

//   empty: {
//     alignItems: 'center',
//     paddingTop: 100,
//   },

//   emptyTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: COLORS.text,
//   },

//   emptyText: {
//     color: COLORS.textSecondary,
//     marginTop: 6,
//   },
// });

// export default StudentsScreen;
import React, {
  useCallback,
  useRef,
  useState,
} from 'react';

import {
  ActivityIndicator,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

import {useFocusEffect} from '@react-navigation/native';

import {getStudentsApi} from '../../api/students';

import {COLORS} from '../../constants/colors';

const DEBOUNCE_MS = 400;

const StudentsScreen = ({navigation}) => {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const debounceRef = useRef(null);
  const requestIdRef = useRef(0);

  const loadStudents = useCallback(
    async (searchValue = '', showLoader = false) => {
      const requestId = ++requestIdRef.current;

      if (showLoader) setLoading(true);

      try {
        const response = await getStudentsApi({
          search: searchValue,
        });

        // Ignore stale responses
        if (requestId !== requestIdRef.current) return;

        if (response?.status?.code === 200) {
          setStudents(response.data || []);
        }
      } catch (error) {
        console.log('Students error:', error);
      } finally {
        if (requestId === requestIdRef.current) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    },
    [],
  );

  // Reload on focus, preserving current search
  useFocusEffect(
    useCallback(() => {
      loadStudents(search, students.length === 0);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [search]),
  );

  const handleSearch = value => {
    setSearch(value);

    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    debounceRef.current = setTimeout(() => {
      loadStudents(value);
    }, DEBOUNCE_MS);
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadStudents(search);
  };

  const renderStudent = ({item}) => {
    const initial =
      item.full_name?.charAt(0)?.toUpperCase() || 'S';

    const isActive = item.status === 'ACTIVE';

    return (
      <Pressable
        style={styles.card}
        onPress={() =>
          navigation.navigate('StudentDetails', {
            studentId: item.id,
          })
        }>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{initial}</Text>
        </View>

        <View style={styles.info}>
          <Text style={styles.name} numberOfLines={1}>
            {item.full_name}
          </Text>

          <Text style={styles.code}>{item.student_code}</Text>

          <Text style={styles.mobile}>{item.mobile}</Text>
        </View>

        <View
          style={[
            styles.status,
            isActive ? styles.active : styles.inactive,
          ]}>
          <Text
            style={[
              styles.statusText,
              isActive && styles.activeText,
            ]}>
            {item.status}
          </Text>
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Students</Text>
          <Text style={styles.subtitle}>
            Manage your study center members
          </Text>
        </View>

        <Pressable
          style={styles.addButton}
          onPress={() => navigation.navigate('AddStudent')}>
          <Text style={styles.addText}>+</Text>
        </Pressable>
      </View>

      <View style={styles.searchBox}>
        <Text style={styles.searchIcon}>⌕</Text>
        <TextInput
          value={search}
          onChangeText={handleSearch}
          placeholder="Search students..."
          placeholderTextColor={COLORS.textLight}
          style={styles.searchInput}
          autoCorrect={false}
          autoCapitalize="none"
          returnKeyType="search"
        />
      </View>

      {loading ? (
        <View style={styles.loader}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : (
        <FlatList
          data={students}
          keyExtractor={item => String(item.id)}
          renderItem={renderStudent}
          contentContainerStyle={styles.list}
          keyboardShouldPersistTaps="handled"
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
            />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>
                No students found
              </Text>
              <Text style={styles.emptyText}>
                {search
                  ? 'Try a different search term.'
                  : 'Add your first student to get started.'}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: COLORS.background},
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
  addButton: {
    width: 46, height: 46, borderRadius: 14,
    backgroundColor: COLORS.primary,
    alignItems: 'center', justifyContent: 'center',
  },
  addText: {
    color: COLORS.white, fontSize: 28,
    lineHeight: 30, fontWeight: '400',
  },
  searchBox: {
    marginHorizontal: 20, marginBottom: 12,
    height: 50, backgroundColor: COLORS.white,
    borderRadius: 14, borderWidth: 1,
    borderColor: COLORS.border,
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 14,
  },
  searchIcon: {
    color: COLORS.textSecondary, fontSize: 23, marginRight: 8,
  },
  searchInput: {flex: 1, color: COLORS.text, fontSize: 14},
  list: {padding: 20, paddingTop: 5, paddingBottom: 40},
  card: {
    backgroundColor: COLORS.white, borderRadius: 17,
    padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: COLORS.border,
    flexDirection: 'row', alignItems: 'center',
  },
  avatar: {
    width: 48, height: 48, borderRadius: 15,
    backgroundColor: '#DBEAFE',
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: {color: COLORS.primary, fontSize: 18, fontWeight: '800'},
  info: {flex: 1, marginLeft: 13, marginRight: 8},
  name: {color: COLORS.text, fontSize: 15, fontWeight: '700'},
  code: {color: COLORS.primary, fontSize: 11, fontWeight: '700', marginTop: 3},
  mobile: {color: COLORS.textSecondary, fontSize: 12, marginTop: 3},
  status: {borderRadius: 20, paddingHorizontal: 8, paddingVertical: 5},
  active: {backgroundColor: COLORS.successBg},
  inactive: {backgroundColor: COLORS.dangerBg},
  statusText: {color: COLORS.danger, fontSize: 9, fontWeight: '800'},
  activeText: {color: COLORS.success},
  loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  empty: {alignItems: 'center', paddingTop: 100},
  emptyTitle: {fontSize: 18, fontWeight: '800', color: COLORS.text},
  emptyText: {
    color: COLORS.textSecondary, marginTop: 6,
    textAlign: 'center', paddingHorizontal: 40,
  },
});

export default StudentsScreen;