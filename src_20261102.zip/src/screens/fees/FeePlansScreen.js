// import React, {useEffect, useState} from 'react';
// import {
//   Alert,
//   Modal,
//   ScrollView,
//   StyleSheet,
//   Switch,
//   Text,
//   TouchableOpacity,
//   View,
// } from 'react-native';

// import ScreenHeader from '../../components/ScreenHeader';
// import Loading from '../../components/Loading';
// import AppInput from '../../components/AppInput';
// import AppButton from '../../components/AppButton';

// import {COLORS} from '../../constants/colors';
// import {
//   createFeePlanApi,
//   getFeePlansApi,
//   updateFeePlanApi,
// } from '../../api/fees';

// const FeePlansScreen = () => {
//   const [loading, setLoading] = useState(true);
//   const [plans, setPlans] = useState([]);

//   const [modalVisible, setModalVisible] = useState(false);
//   const [saving, setSaving] = useState(false);
//   const [editingPlan, setEditingPlan] = useState(null);

//   const [planName, setPlanName] = useState('');
//   const [durationDays, setDurationDays] = useState('');
//   const [amount, setAmount] = useState('');
//   const [description, setDescription] = useState('');
//   const [active, setActive] = useState(true);

//   useEffect(() => {
//     loadPlans();
//   }, []);

//   const loadPlans = async () => {
//     try {
//       setLoading(true);

//       const response = await getFeePlansApi();

//       if (response?.status?.code === 200) {
//         setPlans(response.data || []);
//       }
//     } catch (error) {
//       Alert.alert('Error', 'Unable to load fee plans.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const resetForm = () => {
//     setEditingPlan(null);
//     setPlanName('');
//     setDurationDays('');
//     setAmount('');
//     setDescription('');
//     setActive(true);
//   };

//   const openAdd = () => {
//     resetForm();
//     setModalVisible(true);
//   };

//   const openEdit = plan => {
//     setEditingPlan(plan);
//     setPlanName(plan.plan_name || '');
//     setDurationDays(String(plan.duration_days || ''));
//     setAmount(String(plan.amount || ''));
//     setDescription(plan.description || '');
//     setActive(plan.status === 'ACTIVE');
//     setModalVisible(true);
//   };

//   const savePlan = async () => {
//     if (!planName.trim()) {
//       Alert.alert('Required', 'Please enter plan name.');
//       return;
//     }

//     if (!durationDays || Number(durationDays) <= 0) {
//       Alert.alert('Required', 'Please enter valid duration.');
//       return;
//     }

//     if (Number(amount) < 0) {
//       Alert.alert('Invalid amount', 'Amount cannot be negative.');
//       return;
//     }

//     try {
//       setSaving(true);

//       const payload = {
//         plan_name: planName.trim(),
//         duration_days: Number(durationDays),
//         amount: Number(amount || 0),
//         description: description.trim() || null,
//         status: active ? 'ACTIVE' : 'INACTIVE',
//       };

//       let response;

//       if (editingPlan) {
//         response = await updateFeePlanApi(editingPlan.id, payload);
//       } else {
//         response = await createFeePlanApi(payload);
//       }

//       if (response?.status?.code !== 200) {
//         throw new Error(
//           response?.status?.message || 'Unable to save plan.',
//         );
//       }

//       setModalVisible(false);
//       resetForm();
//       await loadPlans();
//     } catch (error) {
//       Alert.alert(
//         'Error',
//         error.message || 'Unable to save fee plan.',
//       );
//     } finally {
//       setSaving(false);
//     }
//   };

//   if (loading) {
//     return <Loading fullScreen text="Loading fee plans..." />;
//   }

//   return (
//     <View style={styles.container}>
//       <ScreenHeader
//         title="Fee Plans"
//         subtitle={`${plans.length} plans configured`}
//         rightAction="+ Add"
//         onRightAction={openAdd}
//       />

//       <ScrollView
//         contentContainerStyle={styles.content}
//         showsVerticalScrollIndicator={false}>
//         <View style={styles.infoCard}>
//           <View style={styles.infoIcon}>
//             <Text style={styles.infoIconText}>₹</Text>
//           </View>

//           <View style={styles.infoText}>
//             <Text style={styles.infoTitle}>Flexible pricing</Text>
//             <Text style={styles.infoSubtitle}>
//               Change prices anytime without affecting previous memberships.
//             </Text>
//           </View>
//         </View>

//         {plans.length === 0 ? (
//           <View style={styles.empty}>
//             <Text style={styles.emptyTitle}>No fee plans</Text>
//             <Text style={styles.emptyText}>
//               Create your first membership plan.
//             </Text>
//           </View>
//         ) : (
//           plans.map((plan, index) => (
//             <TouchableOpacity
//               key={plan.id}
//               activeOpacity={0.8}
//               onPress={() => openEdit(plan)}
//               style={styles.planCard}>
//               <View style={styles.topRow}>
//                 <View style={styles.planIcon}>
//                   <Text style={styles.planIconText}>
//                     {String(index + 1).padStart(2, '0')}
//                   </Text>
//                 </View>

//                 <View style={styles.planMain}>
//                   <Text style={styles.planName}>{plan.plan_name}</Text>

//                   <Text style={styles.duration}>
//                     {plan.duration_days} days
//                   </Text>
//                 </View>

//                 <View
//                   style={[
//                     styles.status,
//                     plan.status === 'ACTIVE'
//                       ? styles.statusActive
//                       : styles.statusInactive,
//                   ]}>
//                   <Text
//                     style={[
//                       styles.statusText,
//                       plan.status === 'ACTIVE'
//                         ? styles.statusActiveText
//                         : styles.statusInactiveText,
//                     ]}>
//                     {plan.status}
//                   </Text>
//                 </View>
//               </View>

//               <View style={styles.divider} />

//               <View style={styles.bottomRow}>
//                 <View>
//                   <Text style={styles.priceLabel}>PLAN PRICE</Text>
//                   <Text style={styles.price}>
//                     ₹{Number(plan.amount || 0).toLocaleString('en-IN')}
//                   </Text>
//                 </View>

//                 <View style={styles.editButton}>
//                   <Text style={styles.editText}>Edit</Text>
//                 </View>
//               </View>

//               {plan.description ? (
//                 <Text style={styles.description}>
//                   {plan.description}
//                 </Text>
//               ) : null}
//             </TouchableOpacity>
//           ))
//         )}
//       </ScrollView>

//       <Modal
//         visible={modalVisible}
//         transparent
//         animationType="slide"
//         onRequestClose={() => setModalVisible(false)}>
//         <View style={styles.modalOverlay}>
//           <View style={styles.modal}>
//             <View style={styles.modalHeader}>
//               <View>
//                 <Text style={styles.modalTitle}>
//                   {editingPlan ? 'Edit Fee Plan' : 'New Fee Plan'}
//                 </Text>
//                 <Text style={styles.modalSubtitle}>
//                   Configure membership pricing
//                 </Text>
//               </View>

//               <TouchableOpacity onPress={() => setModalVisible(false)}>
//                 <Text style={styles.close}>×</Text>
//               </TouchableOpacity>
//             </View>

//             <ScrollView showsVerticalScrollIndicator={false}>
//               <AppInput
//                 label="Plan Name"
//                 placeholder="Example: 1 Month"
//                 value={planName}
//                 onChangeText={setPlanName}
//               />

//               <AppInput
//                 label="Duration (Days)"
//                 placeholder="Example: 30"
//                 value={durationDays}
//                 onChangeText={setDurationDays}
//                 keyboardType="number-pad"
//               />

//               <AppInput
//                 label="Amount"
//                 placeholder="Example: 1500"
//                 value={amount}
//                 onChangeText={setAmount}
//                 keyboardType="decimal-pad"
//               />

//               <AppInput
//                 label="Description"
//                 placeholder="Optional description"
//                 value={description}
//                 onChangeText={setDescription}
//                 multiline
//               />

//               <View style={styles.switchRow}>
//                 <View>
//                   <Text style={styles.switchTitle}>Active Plan</Text>
//                   <Text style={styles.switchSubtitle}>
//                     Available for new memberships
//                   </Text>
//                 </View>

//                 <Switch
//                   value={active}
//                   onValueChange={setActive}
//                   trackColor={{
//                     false: COLORS.border,
//                     true: COLORS.primary,
//                   }}
//                 />
//               </View>

//               <AppButton
//                 title={saving ? 'Saving...' : editingPlan ? 'Update Plan' : 'Create Plan'}
//                 onPress={savePlan}
//                 loading={saving}
//               />

//               <View style={{height: 20}} />
//             </ScrollView>
//           </View>
//         </View>
//       </Modal>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: COLORS.background,
//   },
//   content: {
//     padding: 16,
//   },
//   infoCard: {
//     backgroundColor: COLORS.primary,
//     borderRadius: 18,
//     padding: 16,
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginBottom: 16,
//   },
//   infoIcon: {
//     width: 46,
//     height: 46,
//     borderRadius: 14,
//     backgroundColor: 'rgba(255,255,255,0.18)',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   infoIconText: {
//     color: COLORS.white,
//     fontSize: 22,
//     fontWeight: '900',
//   },
//   infoText: {
//     flex: 1,
//     marginLeft: 12,
//   },
//   infoTitle: {
//     color: COLORS.white,
//     fontSize: 15,
//     fontWeight: '800',
//   },
//   infoSubtitle: {
//     color: '#DDE8FF',
//     fontSize: 11,
//     lineHeight: 17,
//     marginTop: 3,
//   },
//   planCard: {
//     backgroundColor: COLORS.surface,
//     borderRadius: 18,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     padding: 16,
//     marginBottom: 12,
//   },
//   topRow: {
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   planIcon: {
//     width: 44,
//     height: 44,
//     borderRadius: 14,
//     backgroundColor: COLORS.purpleBg,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   planIconText: {
//     color: COLORS.purple,
//     fontWeight: '900',
//     fontSize: 12,
//   },
//   planMain: {
//     flex: 1,
//     marginLeft: 12,
//   },
//   planName: {
//     fontSize: 15,
//     fontWeight: '800',
//     color: COLORS.text,
//   },
//   duration: {
//     fontSize: 11,
//     color: COLORS.textSecondary,
//     marginTop: 3,
//   },
//   status: {
//     paddingHorizontal: 9,
//     paddingVertical: 5,
//     borderRadius: 20,
//   },
//   statusActive: {
//     backgroundColor: COLORS.successBg,
//   },
//   statusInactive: {
//     backgroundColor: COLORS.dangerBg,
//   },
//   statusText: {
//     fontSize: 9,
//     fontWeight: '900',
//   },
//   statusActiveText: {
//     color: COLORS.success,
//   },
//   statusInactiveText: {
//     color: COLORS.danger,
//   },
//   divider: {
//     height: 1,
//     backgroundColor: COLORS.border,
//     marginVertical: 14,
//   },
//   bottomRow: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//   },
//   priceLabel: {
//     fontSize: 9,
//     color: COLORS.textLight,
//     fontWeight: '800',
//   },
//   price: {
//     fontSize: 24,
//     fontWeight: '900',
//     color: COLORS.text,
//     marginTop: 2,
//   },
//   editButton: {
//     paddingHorizontal: 14,
//     paddingVertical: 9,
//     borderRadius: 10,
//     backgroundColor: COLORS.background,
//   },
//   editText: {
//     color: COLORS.primary,
//     fontSize: 12,
//     fontWeight: '800',
//   },
//   description: {
//     color: COLORS.textSecondary,
//     fontSize: 11,
//     marginTop: 12,
//     lineHeight: 17,
//   },
//   empty: {
//     alignItems: 'center',
//     padding: 50,
//   },
//   emptyTitle: {
//     fontSize: 17,
//     fontWeight: '800',
//     color: COLORS.text,
//   },
//   emptyText: {
//     color: COLORS.textSecondary,
//     marginTop: 5,
//   },
//   modalOverlay: {
//     flex: 1,
//     backgroundColor: 'rgba(0,0,0,0.45)',
//     justifyContent: 'flex-end',
//   },
//   modal: {
//     backgroundColor: COLORS.background,
//     borderTopLeftRadius: 26,
//     borderTopRightRadius: 26,
//     padding: 20,
//     maxHeight: '90%',
//   },
//   modalHeader: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 18,
//   },
//   modalTitle: {
//     fontSize: 20,
//     fontWeight: '900',
//     color: COLORS.text,
//   },
//   modalSubtitle: {
//     color: COLORS.textSecondary,
//     fontSize: 11,
//     marginTop: 3,
//   },
//   close: {
//     fontSize: 30,
//     color: COLORS.textSecondary,
//     lineHeight: 30,
//   },
//   switchRow: {
//     backgroundColor: COLORS.surface,
//     borderRadius: 14,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     padding: 14,
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     marginBottom: 18,
//   },
//   switchTitle: {
//     color: COLORS.text,
//     fontSize: 14,
//     fontWeight: '800',
//   },
//   switchSubtitle: {
//     color: COLORS.textSecondary,
//     fontSize: 11,
//     marginTop: 3,
//   },
// });

// export default FeePlansScreen;
import React, {useEffect, useState} from 'react';
import {
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import ScreenHeader from '../../components/ScreenHeader';
import Loading from '../../components/Loading';
import AppInput from '../../components/AppInput';
import AppButton from '../../components/AppButton';

import {COLORS} from '../../constants/colors';
import {
  createFeePlanApi,
  getFeePlansApi,
  updateFeePlanApi,
} from '../../api/fees';

const SLOTS = [
  {key: 'FULL_TIME', label: 'Full Time'},
  {key: 'HALF_MORNING', label: 'Half Morning'},
  {key: 'HALF_EVENING', label: 'Half Evening'},
];

const FeePlansScreen = () => {
  const [loading, setLoading] = useState(true);
  const [plans, setPlans] = useState([]);

  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);

  const [planName, setPlanName] = useState('');
  const [durationDays, setDurationDays] = useState('');
  const [slotType, setSlotType] = useState('FULL_TIME'); // 👈 NEW
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [active, setActive] = useState(true);

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    try {
      setLoading(true);
      const response = await getFeePlansApi();
      if (response?.status?.code === 200) {
        setPlans(response.data || []);
      }
    } catch (error) {
      Alert.alert('Error', 'Unable to load fee plans.');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEditingPlan(null);
    setPlanName('');
    setDurationDays('');
    setSlotType('FULL_TIME');
    setAmount('');
    setDescription('');
    setActive(true);
  };

  const openAdd = () => {
    resetForm();
    setModalVisible(true);
  };

  const openEdit = plan => {
    setEditingPlan(plan);
    setPlanName(plan.plan_name || '');
    setDurationDays(String(plan.duration_days || ''));
    setSlotType(plan.slot_type || 'FULL_TIME');
    setAmount(String(plan.amount || ''));
    setDescription(plan.description || '');
    setActive(plan.status === 'ACTIVE');
    setModalVisible(true);
  };

  const savePlan = async () => {
    if (!planName.trim()) {
      Alert.alert('Required', 'Please enter plan name.');
      return;
    }

    if (!durationDays || Number(durationDays) <= 0) {
      Alert.alert('Required', 'Please enter valid duration.');
      return;
    }

    if (Number(amount) < 0) {
      Alert.alert('Invalid amount', 'Amount cannot be negative.');
      return;
    }

    try {
      setSaving(true);

      const payload = {
        plan_name: planName.trim(),
        duration_days: Number(durationDays),
        slot_type: slotType, // 👈 Sending slot_type
        amount: Number(amount || 0),
        description: description.trim() || null,
        status: active ? 'ACTIVE' : 'INACTIVE',
      };

      let response;
      if (editingPlan) {
        response = await updateFeePlanApi(editingPlan.id, payload);
      } else {
        response = await createFeePlanApi(payload);
      }

      if (response?.status?.code !== 200) {
        throw new Error(response?.status?.message || 'Unable to save plan.');
      }

      setModalVisible(false);
      resetForm();
      await loadPlans();
    } catch (error) {
      Alert.alert('Error', error.message || 'Unable to save fee plan.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loading fullScreen text="Loading fee plans..." />;

  return (
    <View style={styles.container}>
      <ScreenHeader
        title="Fee Plans"
        subtitle={`${plans.length} plans configured`}
        rightAction="+ Add"
        onRightAction={openAdd}
      />

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {plans.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>No fee plans</Text>
            <Text style={styles.emptyText}>Create your first membership plan.</Text>
          </View>
        ) : (
          plans.map((plan, index) => (
            <TouchableOpacity
              key={plan.id}
              activeOpacity={0.8}
              onPress={() => openEdit(plan)}
              style={styles.planCard}>
              <View style={styles.topRow}>
                <View style={styles.planIcon}>
                  <Text style={styles.planIconText}>{String(index + 1).padStart(2, '0')}</Text>
                </View>
                <View style={styles.planMain}>
                  <Text style={styles.planName}>{plan.plan_name}</Text>
                  <Text style={styles.duration}>
                    {plan.duration_days} days • {plan.slot_type?.replace('_', ' ')}
                  </Text>
                </View>
                <View style={[styles.status, plan.status === 'ACTIVE' ? styles.statusActive : styles.statusInactive]}>
                  <Text style={[styles.statusText, plan.status === 'ACTIVE' ? styles.statusActiveText : styles.statusInactiveText]}>
                    {plan.status}
                  </Text>
                </View>
              </View>
              <View style={styles.divider} />
              <View style={styles.bottomRow}>
                <View>
                  <Text style={styles.priceLabel}>PLAN PRICE</Text>
                  <Text style={styles.price}>₹{Number(plan.amount || 0).toLocaleString('en-IN')}</Text>
                </View>
                <View style={styles.editButton}>
                  <Text style={styles.editText}>Edit</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      <Modal visible={modalVisible} transparent animationType="slide" onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>{editingPlan ? 'Edit Fee Plan' : 'New Fee Plan'}</Text>
                <Text style={styles.modalSubtitle}>Configure membership pricing</Text>
              </View>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={styles.close}>×</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <AppInput label="Plan Name" placeholder="Example: 1 Month" value={planName} onChangeText={setPlanName} />
              <AppInput label="Duration (Days)" placeholder="Example: 30" value={durationDays} onChangeText={setDurationDays} keyboardType="number-pad" />

              {/* 👉 NEW: Slot Type Selector */}
              <Text style={{fontSize: 13, fontWeight: '600', color: COLORS.text, marginBottom: 8, marginTop: 4}}>Slot Type</Text>
              <View style={{flexDirection: 'row', gap: 8, marginBottom: 16}}>
                {SLOTS.map(s => (
                  <Pressable
                    key={s.key}
                    onPress={() => setSlotType(s.key)}
                    style={[{
                      flex: 1, paddingVertical: 12, borderRadius: 10, borderWidth: 1,
                      borderColor: COLORS.border, backgroundColor: COLORS.white,
                      alignItems: 'center'
                    }, slotType === s.key && {borderColor: COLORS.primary, backgroundColor: '#DBEAFE'}]}
                  >
                    <Text style={{fontSize: 11, fontWeight: '700', color: slotType === s.key ? COLORS.primary : COLORS.textSecondary}}>
                      {s.label}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <AppInput label="Amount" placeholder="Example: 1500" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" />
              <AppInput label="Description" placeholder="Optional description" value={description} onChangeText={setDescription} multiline />

              <View style={styles.switchRow}>
                <View>
                  <Text style={styles.switchTitle}>Active Plan</Text>
                  <Text style={styles.switchSubtitle}>Available for new memberships</Text>
                </View>
                <Switch value={active} onValueChange={setActive} trackColor={{ false: COLORS.border, true: COLORS.primary }} />
              </View>

              <AppButton title={saving ? 'Saving...' : editingPlan ? 'Update Plan' : 'Create Plan'} onPress={savePlan} loading={saving} />
              <View style={{height: 20}} />
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 16 },
  empty: { alignItems: 'center', padding: 50 },
  emptyTitle: { fontSize: 17, fontWeight: '800', color: COLORS.text },
  emptyText: { color: COLORS.textSecondary, marginTop: 5 },
  planCard: { backgroundColor: COLORS.surface, borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, padding: 16, marginBottom: 12 },
  topRow: { flexDirection: 'row', alignItems: 'center' },
  planIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: COLORS.purpleBg, alignItems: 'center', justifyContent: 'center' },
  planIconText: { color: COLORS.purple, fontWeight: '900', fontSize: 12 },
  planMain: { flex: 1, marginLeft: 12 },
  planName: { fontSize: 15, fontWeight: '800', color: COLORS.text },
  duration: { fontSize: 11, color: COLORS.textSecondary, marginTop: 3 },
  status: { paddingHorizontal: 9, paddingVertical: 5, borderRadius: 20 },
  statusActive: { backgroundColor: COLORS.successBg },
  statusInactive: { backgroundColor: COLORS.dangerBg },
  statusText: { fontSize: 9, fontWeight: '900' },
  statusActiveText: { color: COLORS.success },
  statusInactiveText: { color: COLORS.danger },
  divider: { height: 1, backgroundColor: COLORS.border, marginVertical: 14 },
  bottomRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  priceLabel: { fontSize: 9, color: COLORS.textLight, fontWeight: '800' },
  price: { fontSize: 24, fontWeight: '900', color: COLORS.text, marginTop: 2 },
  editButton: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10, backgroundColor: COLORS.background },
  editText: { color: COLORS.primary, fontSize: 12, fontWeight: '800' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' },
  modal: { backgroundColor: COLORS.background, borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 20, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 18 },
  modalTitle: { fontSize: 20, fontWeight: '900', color: COLORS.text },
  modalSubtitle: { color: COLORS.textSecondary, fontSize: 11, marginTop: 3 },
  close: { fontSize: 30, color: COLORS.textSecondary, lineHeight: 30 },
  switchRow: { backgroundColor: COLORS.surface, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, padding: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 },
  switchTitle: { color: COLORS.text, fontSize: 14, fontWeight: '800' },
  switchSubtitle: { color: COLORS.textSecondary, fontSize: 11, marginTop: 3 },
});

export default FeePlansScreen;