// import React, {useCallback, useMemo, useState} from 'react';

// import {
//   ActivityIndicator,
//   Alert,
//   Modal,
//   Pressable,
//   RefreshControl,
//   ScrollView,
//   StyleSheet,
//   Text,
//   View,
// } from 'react-native';

// import {useFocusEffect} from '@react-navigation/native';

// import {getSeatsApi, updateSeatApi} from '../../api/seats';

// import {COLORS} from '../../constants/colors';

// const SLOT_FILTERS = [
//   {key: 'ALL', label: 'All slots'},
//   {key: 'FULL_TIME', label: 'Full Time'},
//   {key: 'HALF_MORNING', label: 'Morning'},
//   {key: 'HALF_EVENING', label: 'Evening'},
// ];

// const STATUS_FILTERS = [
//   {key: 'ALL', label: 'All'},
//   {key: 'AVAILABLE', label: 'Free'},
//   {key: 'OCCUPIED', label: 'Occupied'},
//   {key: 'PARTIALLY_OCCUPIED', label: 'Partial'},
//   {key: 'MAINTENANCE', label: 'Maintenance'},
//   {key: 'BLOCKED', label: 'Blocked'},
// ];

// const STATUS_COLORS = {
//   AVAILABLE: {bg: COLORS.successBg, fg: COLORS.success},
//   OCCUPIED: {bg: '#DBEAFE', fg: COLORS.primary},
//   PARTIALLY_OCCUPIED: {bg: COLORS.purpleBg, fg: COLORS.purple},
//   MAINTENANCE: {bg: COLORS.warningBg, fg: COLORS.warning},
//   BLOCKED: {bg: COLORS.dangerBg, fg: COLORS.danger},
// };

// const OCCUPANT_LABELS = {
//   FULL_TIME: 'FULL',
//   HALF_MORNING: 'AM',
//   HALF_EVENING: 'PM',
// };

// // const SeatsScreen = () => {
// const SeatsScreen = ({navigation}) => { 
//   const [seats, setSeats] = useState([]);
//   const [slotFilter, setSlotFilter] = useState('ALL');
//   const [statusFilter, setStatusFilter] = useState('ALL');
//   const [loading, setLoading] = useState(true);
//   const [refreshing, setRefreshing] = useState(false);

//   // State for bottom sheet
//   const [selectedSeat, setSelectedSeat] = useState(null);

//   // const loadSeats = useCallback(async (showLoader = false) => {
//   //   if (showLoader) setLoading(true);
//   //   try {
//   //     const response = await getSeatsApi();
//   //     if (response?.status?.code === 200) {
//   //       setSeats(response.data || []);
//   //     }
//   //   } catch (error) {
//   //     console.log('Seats load error:', error);
//   //   } finally {
//   //     setLoading(false);
//   //     setRefreshing(false);
//   //   }
//   // }, []);

//   // useFocusEffect(
//   //   useCallback(() => {
//   //     loadSeats(seats.length === 0);
//   //     // eslint-disable-next-line react-hooks/exhaustive-deps
//   //   }, []),
//   // );

//   // Add this to your SeatsScreen's loadSeats function:
// const loadSeats = useCallback(async (showLoader = false) => {
//     if (showLoader) setLoading(true);
//     try {
//       // 👉 Pass the selected slot to the API! (defaults to ALL)
//       const response = await getSeatsApi(slotFilter === 'ALL' ? {} : {slot: slotFilter});
//       if (response?.status?.code === 200) {
//         setSeats(response.data || []);
//       }
//     } catch (error) {
//       console.log('Seats load error:', error);
//     } finally {
//       setLoading(false);
//       setRefreshing(false);
//     }
// }, [slotFilter]); // 👈 Add slotFilter as a dependency

// // ... then in your useEffect:
// useFocusEffect(
//     useCallback(() => {
//       loadSeats(true); // Always show loader when filter changes
//     }, [loadSeats]),
// );

// // ... inside renderBottomSheet, add this to allow changing the seat's slot:
// {/* <Text style={styles.sheetSectionTitle}>Seat Slot Restriction</Text>
// <View style={styles.actionGrid}>
//   {['ANY', 'FULL_TIME', 'HALF_MORNING', 'HALF_EVENING'].map(sl => (
//     <Pressable
//       key={sl}
//       style={[styles.actionBtn, (seat.slot_type || 'ANY') === sl && styles.actionBtnActive]}
//       onPress={() => changeSlot(seat, sl)}>
//       <Text style={[styles.actionBtnText, (seat.slot_type || 'ANY') === sl && styles.actionBtnActiveText]}>
//         {sl.replace('_', ' ')}
//       </Text>
//     </Pressable>
//   ))}
// </View> */}

// // And add the handler:
// const changeSlot = async (seat, slot) => {
//     setSelectedSeat(null);
//     try {
//       await updateSeatApi(seat.id, {slot_type: slot});
//       loadSeats();
//     } catch (e) {
//       Alert.alert('Error', 'Could not update seat slot.');
//     }
// };

//   const onRefresh = () => {
//     setRefreshing(true);
//     loadSeats();
//   };

//   const counts = useMemo(() => {
//     const r = {
//       total: seats.length,
//       AVAILABLE: 0,
//       OCCUPIED: 0,
//       PARTIALLY_OCCUPIED: 0,
//       MAINTENANCE: 0,
//       BLOCKED: 0,
//     };
//     seats.forEach(s => {
//       if (r[s.status] !== undefined) r[s.status] += 1;
//       else r.OCCUPIED += 1; // fallback
//     });
//     return r;
//   }, [seats]);

//   const visibleSeats = useMemo(() => {
//     let result = seats;
//     if (statusFilter !== 'ALL') {
//       result = result.filter(s => s.status === statusFilter);
//     }
//     return result;
//   }, [seats, statusFilter]);

//   const changeStatus = async (seat, newStatus) => {
//     setSelectedSeat(null); // close sheet immediately
//     try {
//       const res = await updateSeatApi(seat.id, {status: newStatus});
//       if (res?.status?.code === 200) {
//         loadSeats();
//       } else {
//         Alert.alert('Failed', res?.status?.message || 'Could not update seat');
//       }
//     } catch (e) {
//       Alert.alert('Error', e?.response?.data?.status?.message || 'Could not update');
//     }
//   };

//   const changeGender = async (seat, gender) => {
//     setSelectedSeat(null); // close sheet
//     try {
//       await updateSeatApi(seat.id, {gender_preference: gender});
//       loadSeats();
//     } catch (e) {
//       Alert.alert('Error', 'Could not update seat.');
//     }
//   };

//   const renderSeat = seat => {
//     const colors = STATUS_COLORS[seat.status] || STATUS_COLORS.AVAILABLE;
//     const occupants = seat.occupants || [];

//     return (
//       <Pressable
//         key={seat.id}
//         style={[
//           styles.seat,
//           {backgroundColor: colors.bg, borderColor: colors.fg},
//         ]}
//         onPress={() => setSelectedSeat(seat)}>
//         <Text style={[styles.seatNumber, {color: colors.fg}]}>
//           {seat.seat_number}
//         </Text>

//         {occupants.length > 0 ? (
//           <View style={styles.occupantRow}>
//             {occupants.map(o => (
//               <Text key={o} style={[styles.occupantTag, {color: colors.fg}]}>
//                 {OCCUPANT_LABELS[o]}
//               </Text>
//             ))}
//           </View>
//         ) : (
//           <Text style={[styles.seatStatus, {color: colors.fg}]}>
//             {seat.status === 'AVAILABLE' ? 'FREE' : '—'}
//           </Text>
//         )}

//         {seat.gender_preference !== 'ANY' && (
//           <Text style={[styles.seatGender, {color: colors.fg}]}>
//             {seat.gender_preference === 'MALE' ? '♂' : '♀'}
//           </Text>
//         )}
//       </Pressable>
//     );
//   };

//   // const renderBottomSheet = () => {
//   //   if (!selectedSeat) return null;
//   //   const seat = selectedSeat;

//   //   return (
//   //     <Modal
//   //       visible={!!selectedSeat}
//   //       transparent
//   //       animationType="slide"
//   //       onRequestClose={() => setSelectedSeat(null)}>
//   //       <View style={styles.modalOverlay}>
//   //         <Pressable
//   //           style={styles.modalBg}
//   //           onPress={() => setSelectedSeat(null)}
//   //         />
//   //         <View style={styles.bottomSheet}>
//   //           <View style={styles.sheetHandle} />
            
//   //           <View style={styles.sheetHeader}>
//   //             <Text style={styles.sheetTitle}>Seat {seat.seat_number}</Text>
//   //             <Pressable
//   //               style={styles.closeButton}
//   //               onPress={() => setSelectedSeat(null)}>
//   //               <Text style={styles.closeText}>✕</Text>
//   //             </Pressable>
//   //           </View>

//   //           <Text style={styles.sheetSub}>
//   //             Status: {seat.status} • Gender: {seat.gender_preference}
//   //           </Text>
//   // Replace your renderBottomSheet with this:
//   const renderBottomSheet = () => {
//     if (!selectedSeat) return null;
//     const seat = selectedSeat;

//     return (
//       <Modal
//         visible={!!selectedSeat}
//         transparent
//         animationType="slide"
//         onRequestClose={() => setSelectedSeat(null)}>
//         <View style={styles.modalOverlay}>
//           <Pressable
//             style={styles.modalBg}
//             onPress={() => setSelectedSeat(null)}
//           />

//           <View style={styles.bottomSheet}>
//             <View style={styles.sheetHandle} />
            
//             <View style={styles.sheetHeader}>
//               <Text style={styles.sheetTitle}>Seat {seat.seat_number}</Text>
//               <Pressable
//                 style={styles.closeButton}
//                 onPress={() => setSelectedSeat(null)}>
//                 <Text style={styles.closeText}>✕</Text>
//               </Pressable>
//             </View>

//             <Text style={styles.sheetSub}>
//               Status: {seat.status} • Gender: {seat.gender_preference}
//             </Text>

//             {/* 👉 NEW: Direct assignment button */}
//             {seat.status === 'AVAILABLE' && (
//               <Pressable
//                 style={{
//                   backgroundColor: COLORS.primary,
//                   padding: 16,
//                   borderRadius: 12,
//                   alignItems: 'center',
//                   marginBottom: 20,
//                 }}
//                 onPress={() => {
//                   setSelectedSeat(null);
//                   // Navigate to AddStudent screen with the seatId
//                   navigation.navigate('Students', {
//                     screen: 'AddStudent',
//                     params: { seatId: seat.id, seatNumber: seat.seat_number },
//                   });
//                 }}>
//                 <Text style={{color: COLORS.white, fontWeight: '800', fontSize: 15}}>
//                   + Assign to New Student
//                 </Text>
//               </Pressable>
//             )}

//             <Text style={styles.sheetSectionTitle}>Seat Slot Restriction</Text>
// <View style={styles.actionGrid}>
//   {['ANY', 'FULL_TIME', 'HALF_MORNING', 'HALF_EVENING'].map(sl => (
//     <Pressable
//       key={sl}
//       style={[styles.actionBtn, (seat.slot_type || 'ANY') === sl && styles.actionBtnActive]}
//       onPress={() => changeSlot(seat, sl)}>
//       <Text style={[styles.actionBtnText, (seat.slot_type || 'ANY') === sl && styles.actionBtnActiveText]}>
//         {sl.replace('_', ' ')}
//       </Text>
//     </Pressable>
//   ))}
// </View>

//             <Text style={styles.sheetSectionTitle}>Change Status</Text>
            
//             {/* ... rest of your action grid ... */}

//             {/* <Text style={styles.sheetSectionTitle}>Change Status</Text> */}
//             <View style={styles.actionGrid}>
//               {seat.status !== 'AVAILABLE' && (
//                 <Pressable
//                   style={styles.actionBtn}
//                   onPress={() => changeStatus(seat, 'AVAILABLE')}>
//                   <Text style={styles.actionBtnText}>Mark Available</Text>
//                 </Pressable>
//               )}
//               {seat.status !== 'MAINTENANCE' && (
//                 <Pressable
//                   style={styles.actionBtn}
//                   onPress={() => changeStatus(seat, 'MAINTENANCE')}>
//                   <Text style={styles.actionBtnText}>Maintenance</Text>
//                 </Pressable>
//               )}
//               {seat.status !== 'BLOCKED' && (
//                 <Pressable
//                   style={[styles.actionBtn, styles.actionBtnDanger]}
//                   onPress={() => changeStatus(seat, 'BLOCKED')}>
//                   <Text style={[styles.actionBtnText, styles.actionBtnDangerText]}>
//                     Block Seat
//                   </Text>
//                 </Pressable>
//               )}
//             </View>

//             <Text style={styles.sheetSectionTitle}>Gender Preference</Text>
//             <View style={styles.actionGrid}>
//               {['ANY', 'MALE', 'FEMALE'].map(g => (
//                 <Pressable
//                   key={g}
//                   style={[
//                     styles.actionBtn,
//                     seat.gender_preference === g && styles.actionBtnActive,
//                   ]}
//                   onPress={() => changeGender(seat, g)}>
//                   <Text
//                     style={[
//                       styles.actionBtnText,
//                       seat.gender_preference === g && styles.actionBtnActiveText,
//                     ]}>
//                     {g}
//                   </Text>
//                 </Pressable>
//               ))}
//             </View>
//           </View>
//         </View>
//       </Modal>
//     );
//   };

//   return (
//     <View style={styles.screen}>
//       <View style={styles.header}>
//         <View>
//           <Text style={styles.title}>Seats</Text>
//           <Text style={styles.subtitle}>Tap a seat to change status</Text>
//         </View>
//       </View>

//       <View style={styles.summaryRow}>
//         <View style={[styles.summaryBox, {backgroundColor: COLORS.white}]}>
//           <Text style={styles.summaryValue}>{counts.total}</Text>
//           <Text style={styles.summaryLabel}>Total</Text>
//         </View>
//         <View style={[styles.summaryBox, {backgroundColor: COLORS.successBg}]}>
//           <Text style={[styles.summaryValue, {color: COLORS.success}]}>
//             {counts.AVAILABLE}
//           </Text>
//           <Text style={[styles.summaryLabel, {color: COLORS.success}]}>Free</Text>
//         </View>
//         <View style={[styles.summaryBox, {backgroundColor: '#DBEAFE'}]}>
//           <Text style={[styles.summaryValue, {color: COLORS.primary}]}>
//             {counts.OCCUPIED}
//           </Text>
//           <Text style={[styles.summaryLabel, {color: COLORS.primary}]}>Occupied</Text>
//         </View>
//         <View style={[styles.summaryBox, {backgroundColor: COLORS.purpleBg}]}>
//           <Text style={[styles.summaryValue, {color: COLORS.purple}]}>
//             {counts.PARTIALLY_OCCUPIED}
//           </Text>
//           <Text style={[styles.summaryLabel, {color: COLORS.purple}]}>Partial</Text>
//         </View>
//       </View>

//       <Text style={styles.filterLabel}>Slot</Text>
//       <View style={styles.chipScrollWrapper}>
//         <ScrollView
//           horizontal
//           showsHorizontalScrollIndicator={false}
//           contentContainerStyle={styles.chipRow}>
//           {SLOT_FILTERS.map(f => {
//             const active = slotFilter === f.key;
//             return (
//               <Pressable
//                 key={f.key}
//                 style={[styles.chip, active && styles.chipActive]}
//                 onPress={() => setSlotFilter(f.key)}>
//                 <Text style={[styles.chipText, active && styles.chipTextActive]}>
//                   {f.label}
//                 </Text>
//               </Pressable>
//             );
//           })}
//         </ScrollView>
//       </View>

//       <Text style={styles.filterLabel}>Status</Text>
//       <View style={styles.chipScrollWrapper}>
//         <ScrollView
//           horizontal
//           showsHorizontalScrollIndicator={false}
//           contentContainerStyle={styles.chipRow}>
//           {STATUS_FILTERS.map(f => {
//             const active = statusFilter === f.key;
//             return (
//               <Pressable
//                 key={f.key}
//                 style={[styles.chip, active && styles.chipActive]}
//                 onPress={() => setStatusFilter(f.key)}>
//                 <Text style={[styles.chipText, active && styles.chipTextActive]}>
//                   {f.label}
//                 </Text>
//               </Pressable>
//             );
//           })}
//         </ScrollView>
//       </View>

//       {loading ? (
//         <View style={styles.loader}>
//           <ActivityIndicator size="large" color={COLORS.primary} />
//         </View>
//       ) : (
//         <ScrollView
//           contentContainerStyle={styles.grid}
//           refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
//           <View style={styles.gridRow}>
//             {visibleSeats.map(renderSeat)}
//           </View>
//           {visibleSeats.length === 0 && (
//             <View style={styles.empty}>
//               <Text style={styles.emptyTitle}>No seats match this filter</Text>
//             </View>
//           )}
//         </ScrollView>
//       )}

//       {renderBottomSheet()}
//     </View>
//   );

// }

// const styles = StyleSheet.create({
//   screen: {flex: 1, backgroundColor: COLORS.background},
//   header: {
//     paddingHorizontal: 20,
//     paddingTop: 20,
//     paddingBottom: 12,
//   },
//   title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
//   subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},

//   summaryRow: {
//     flexDirection: 'row',
//     gap: 8,
//     paddingHorizontal: 20,
//     marginBottom: 14,
//   },
//   summaryBox: {
//     flex: 1,
//     borderRadius: 12,
//     padding: 10,
//     alignItems: 'center',
//     borderWidth: 1,
//     borderColor: COLORS.border,
//   },
//   summaryValue: {fontSize: 18, fontWeight: '900', color: COLORS.text},
//   summaryLabel: {
//     fontSize: 10,
//     fontWeight: '700',
//     color: COLORS.textSecondary,
//     marginTop: 2,
//   },

//   filterLabel: {
//     paddingHorizontal: 20,
//     fontSize: 10,
//     fontWeight: '800',
//     color: COLORS.textLight,
//     letterSpacing: 1,
//     marginBottom: 6,
//   },
  
//   chipScrollWrapper: {
//     height: 42, 
//     marginBottom: 10,
//   },
//   chipRow: {
//     paddingHorizontal: 20,
//     alignItems: 'center', 
//     gap: 8,
//   },
//   chip: {
//     height: 34,
//     paddingHorizontal: 16,
//     borderRadius: 17,
//     backgroundColor: COLORS.white,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     justifyContent: 'center',
//   },
//   chipActive: {
//     backgroundColor: COLORS.primary,
//     borderColor: COLORS.primary,
//   },
//   chipText: {
//     fontSize: 12, 
//     fontWeight: '700', 
//     color: COLORS.textSecondary,
//   },
//   chipTextActive: {color: COLORS.white},

//   grid: {padding: 20, paddingTop: 4, paddingBottom: 40},
//   gridRow: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
//   seat: {
//     width: '18%',
//     aspectRatio: 1,
//     borderRadius: 12,
//     borderWidth: 1.5,
//     alignItems: 'center',
//     justifyContent: 'center',
//     padding: 3,
//     position: 'relative',
//   },
//   seatNumber: {fontSize: 12, fontWeight: '900'},
//   seatStatus: {fontSize: 8, fontWeight: '700', marginTop: 2},
//   occupantRow: {
//     flexDirection: 'row',
//     gap: 2,
//     marginTop: 2,
//     flexWrap: 'wrap',
//     justifyContent: 'center',
//   },
//   occupantTag: {fontSize: 7, fontWeight: '900', letterSpacing: 0.3},
//   seatGender: {
//     position: 'absolute',
//     top: 3,
//     right: 4,
//     fontSize: 10,
//     fontWeight: '900',
//   },

//   loader: {flex: 1, alignItems: 'center', justifyContent: 'center'},
//   empty: {alignItems: 'center', paddingTop: 60},
//   emptyTitle: {fontSize: 16, fontWeight: '800', color: COLORS.text},

//   // ----- Modal Styles -----
//   modalOverlay: {
//     flex: 1,
//     justifyContent: 'flex-end',
//   },
//   modalBg: {
//     ...StyleSheet.absoluteFillObject,
//     backgroundColor: 'rgba(0,0,0,0.5)',
//   },
//   bottomSheet: {
//     backgroundColor: COLORS.white,
//     borderTopLeftRadius: 24,
//     borderTopRightRadius: 24,
//     padding: 24,
//     paddingBottom: 40, // safe area buffer
//   },
//   sheetHandle: {
//     width: 40,
//     height: 4,
//     backgroundColor: COLORS.border,
//     borderRadius: 2,
//     alignSelf: 'center',
//     marginBottom: 16,
//   },
//   sheetHeader: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     marginBottom: 4,
//   },
//   sheetTitle: {
//     fontSize: 20,
//     fontWeight: '900',
//     color: COLORS.text,
//   },
//   closeButton: {
//     width: 32,
//     height: 32,
//     borderRadius: 16,
//     backgroundColor: COLORS.background,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   closeText: {
//     fontSize: 16,
//     fontWeight: '800',
//     color: COLORS.textSecondary,
//   },
//   sheetSub: {
//     fontSize: 13,
//     color: COLORS.textSecondary,
//     marginBottom: 20,
//   },
//   sheetSectionTitle: {
//     fontSize: 12,
//     fontWeight: '800',
//     color: COLORS.textLight,
//     textTransform: 'uppercase',
//     letterSpacing: 1,
//     marginBottom: 10,
//   },
//   actionGrid: {
//     flexDirection: 'row',
//     flexWrap: 'wrap',
//     gap: 10,
//     marginBottom: 20,
//   },
//   actionBtn: {
//     paddingVertical: 12,
//     paddingHorizontal: 16,
//     borderRadius: 12,
//     borderWidth: 1,
//     borderColor: COLORS.border,
//     backgroundColor: COLORS.white,
//     minWidth: '30%',
//     alignItems: 'center',
//   },
//   actionBtnActive: {
//     backgroundColor: COLORS.primary,
//     borderColor: COLORS.primary,
//   },
//   actionBtnText: {
//     fontSize: 13,
//     fontWeight: '700',
//     color: COLORS.text,
//   },
//   actionBtnActiveText: {
//     color: COLORS.white,
//   },
//   actionBtnDanger: {
//     borderColor: COLORS.dangerBg,
//     backgroundColor: COLORS.dangerBg,
//   },
//   actionBtnDangerText: {
//     color: COLORS.danger,
//   },
// });

// export default SeatsScreen;
import React, {useCallback, useMemo, useState} from 'react';
import {
  ActivityIndicator, Modal, Pressable, RefreshControl,
  ScrollView, StyleSheet, Text, View,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import {getSeatsApi, updateSeatApi} from '../../api/seats';
import {COLORS} from '../../constants/colors';

const SLOT_FILTERS = [
  {key: 'ALL', label: 'All slots'},
  {key: 'FULL_TIME', label: 'Full Time'},
  {key: 'HALF_MORNING', label: 'Morning'},
  {key: 'HALF_EVENING', label: 'Evening'},
];

const STATUS_FILTERS = [
  {key: 'ALL', label: 'All'},
  {key: 'AVAILABLE', label: 'Free'},
  {key: 'OCCUPIED', label: 'Occupied'},
  {key: 'PARTIALLY_OCCUPIED', label: 'Partial'},
  {key: 'MAINTENANCE', label: 'Maintenance'},
];

const STATUS_COLORS = {
  AVAILABLE: {bg: COLORS.successBg, fg: COLORS.success},
  OCCUPIED: {bg: '#DBEAFE', fg: COLORS.primary},
  PARTIALLY_OCCUPIED: {bg: COLORS.purpleBg, fg: COLORS.purple},
  MAINTENANCE: {bg: COLORS.warningBg, fg: COLORS.warning},
  BLOCKED: {bg: COLORS.dangerBg, fg: COLORS.danger},
};

const SLOT_ICONS = {
  FULL_TIME: '📅',
  HALF_MORNING: '☀️',
  HALF_EVENING: '🌙',
};

const SeatsScreen = ({navigation}) => {
  const [seats, setSeats] = useState([]);
  const [slotFilter, setSlotFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedSeat, setSelectedSeat] = useState(null);

  const loadSeats = useCallback(async (showLoader = false) => {
    if (showLoader) setLoading(true);
    try {
      const response = await getSeatsApi(slotFilter === 'ALL' ? {} : {slot: slotFilter});
      if (response?.status?.code === 200) setSeats(response.data || []);
    } catch (error) {
      console.log('Seats error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [slotFilter]);

  useFocusEffect(useCallback(() => { loadSeats(seats.length === 0); }, [loadSeats]));

  const counts = useMemo(() => {
    const r = { total: seats.length, AVAILABLE: 0, OCCUPIED: 0, PARTIALLY_OCCUPIED: 0, MAINTENANCE: 0, BLOCKED: 0 };
    seats.forEach(s => { if (r[s.status] !== undefined) r[s.status] += 1; });
    return r;
  }, [seats]);

  const visibleSeats = useMemo(() => {
    if (statusFilter === 'ALL') return seats;
    return seats.filter(s => s.status === statusFilter);
  }, [seats, statusFilter]);

  const updateSeat = async (id, newStatus) => {
    setSelectedSeat(null);
    try {
      await updateSeatApi(id, {status: newStatus});
      loadSeats();
    } catch (e) { alert('Error updating seat'); }
  };

  const renderSeat = seat => {
    const colors = STATUS_COLORS[seat.status] || STATUS_COLORS.AVAILABLE;
    const occupants = seat.occupants || [];
    const icons = occupants.map(o => SLOT_ICONS[o.slot_type]).filter(Boolean);

    return (
      <Pressable
        key={seat.id}
        style={[styles.seat, {backgroundColor: colors.bg, borderColor: colors.fg}]}
        onPress={() => setSelectedSeat(seat)}>
        <Text style={[styles.seatNumber, {color: colors.fg}]}>{seat.seat_number}</Text>
        
        {icons.length > 0 ? (
          <View style={styles.iconRow}>
            {icons.map((ic, i) => <Text key={i} style={{fontSize: 10}}>{ic}</Text>)}
          </View>
        ) : (
          <Text style={[styles.seatStatus, {color: colors.fg}]}>FREE</Text>
        )}
      </Pressable>
    );
  };

  const renderBottomSheet = () => {
    if (!selectedSeat) return null;
    const seat = selectedSeat;
    const occupants = seat.occupants || [];

    // 🧠 Smart logic to detect what slots are missing
    const hasMorning = occupants.some(o => o.slot_type === 'HALF_MORNING');
    const hasEvening = occupants.some(o => o.slot_type === 'HALF_EVENING');
    const hasFull = occupants.some(o => o.slot_type === 'FULL_TIME');

    let suggestedSlot = null;
    if (hasMorning && !hasEvening) suggestedSlot = 'HALF_EVENING';
    if (hasEvening && !hasMorning) suggestedSlot = 'HALF_MORNING';

    return (
      <Modal visible={!!selectedSeat} transparent animationType="slide" onRequestClose={() => setSelectedSeat(null)}>
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalBg} onPress={() => setSelectedSeat(null)} />
          <View style={styles.bottomSheet}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>Seat {seat.seat_number}</Text>
              <Pressable style={styles.closeButton} onPress={() => setSelectedSeat(null)}>
                <Text style={styles.closeText}>✕</Text>
              </Pressable>
            </View>

            <Text style={styles.sheetSectionTitle}>Currently Occupied By</Text>
            {occupants.length === 0 ? (
              <Text style={styles.emptyText}>Seat is empty (Available for all slots)</Text>
            ) : (
              occupants.map((occ, idx) => (
                <View key={idx} style={styles.occupantCard}>
                  <View>
                    <Text style={styles.occupantName}>{occ.full_name}</Text>
                    <Text style={styles.occupantDetail}>{occ.student_code} • {occ.gender}</Text>
                  </View>
                  <View style={[styles.slotChip, {backgroundColor: '#E5E7EB'}]}>
                    <Text style={{fontSize: 10, fontWeight: '800'}}>{occ.slot_type.replace('_',' ')}</Text>
                  </View>
                </View>
              ))
            )}

            {/* 👉 Smart Bookings */}
            {seat.status === 'AVAILABLE' && (
              <Pressable
                style={styles.actionBtnPrimary}
                onPress={() => {
                  setSelectedSeat(null);
                  navigation.navigate('Students', { 
                    screen: 'AddStudent', 
                    params: { seatId: seat.id, seatNumber: seat.seat_number } 
                  });
                }}>
                <Text style={styles.actionBtnPrimaryText}>+ Assign to New Student</Text>
              </Pressable>
            )}

            {suggestedSlot && (
              <Pressable
                style={[styles.actionBtnPrimary, {backgroundColor: COLORS.purple}]}
                onPress={() => {
                  setSelectedSeat(null);
                  navigation.navigate('Students', { 
                    screen: 'AddStudent', 
                    params: { 
                      seatId: seat.id, 
                      seatNumber: seat.seat_number,
                      suggestedSlot: suggestedSlot // Pass the missing slot!
                    } 
                  });
                }}>
                <Text style={styles.actionBtnPrimaryText}>
                  + Book {suggestedSlot === 'HALF_MORNING' ? 'Morning' : 'Evening'} Slot
                </Text>
              </Pressable>
            )}

            <Text style={styles.sheetSectionTitle}>Mark as Unusable</Text>
            <View style={styles.actionGrid}>
              <Pressable style={styles.actionBtn} onPress={() => updateSeat(seat.id, 'MAINTENANCE')}>
                <Text style={styles.actionBtnText}>Maintenance</Text>
              </Pressable>
              {seat.status !== 'AVAILABLE' && (
                <Pressable style={[styles.actionBtn, {backgroundColor: COLORS.success}]} onPress={() => updateSeat(seat.id, 'AVAILABLE')}>
                  <Text style={[styles.actionBtnText, {color: COLORS.white}]}>Mark Free</Text>
                </Pressable>
              )}
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  return (
    <View style={styles.screen}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Seats</Text>
            <Text style={styles.subtitle}>Tap a seat to view details</Text>
          </View>
        </View>

        <View style={styles.summaryRow}>
          <View style={[styles.summaryBox, {backgroundColor: COLORS.white}]}><Text style={styles.summaryValue}>{counts.total}</Text><Text style={styles.summaryLabel}>Total</Text></View>
          <View style={[styles.summaryBox, {backgroundColor: COLORS.successBg}]}><Text style={[styles.summaryValue, {color: COLORS.success}]}>{counts.AVAILABLE}</Text><Text style={[styles.summaryLabel, {color: COLORS.success}]}>Free</Text></View>
          <View style={[styles.summaryBox, {backgroundColor: '#DBEAFE'}]}><Text style={[styles.summaryValue, {color: COLORS.primary}]}>{counts.OCCUPIED}</Text><Text style={[styles.summaryLabel, {color: COLORS.primary}]}>Occupied</Text></View>
          <View style={[styles.summaryBox, {backgroundColor: COLORS.purpleBg}]}><Text style={[styles.summaryValue, {color: COLORS.purple}]}>{counts.PARTIALLY_OCCUPIED}</Text><Text style={styles.summaryLabel}>Partial</Text></View>
        </View>

        <Text style={styles.filterLabel}>Slot</Text>
        <View style={styles.chipScrollWrapper}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
            {SLOT_FILTERS.map(f => {
              const active = slotFilter === f.key;
              return <Pressable key={f.key} style={[styles.chip, active && styles.chipActive]} onPress={() => setSlotFilter(f.key)}><Text style={[styles.chipText, active && styles.chipTextActive]}>{f.label}</Text></Pressable>;
            })}
          </ScrollView>
        </View>

        <Text style={styles.filterLabel}>Status</Text>
        <View style={styles.chipScrollWrapper}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
            {STATUS_FILTERS.map(f => {
              const active = statusFilter === f.key;
              return <Pressable key={f.key} style={[styles.chip, active && styles.chipActive]} onPress={() => setStatusFilter(f.key)}><Text style={[styles.chipText, active && styles.chipTextActive]}>{f.label}</Text></Pressable>;
            })}
          </ScrollView>
        </View>

        {loading ? <View style={styles.loader}><ActivityIndicator size="large" color={COLORS.primary} /></View> : (
          <ScrollView contentContainerStyle={styles.grid} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => loadSeats(false)} />}>
            <View style={styles.gridRow}>{visibleSeats.map(renderSeat)}</View>
          </ScrollView>
        )}

        {renderBottomSheet()}
    </View>
  );
};

const styles = StyleSheet.create({
  // Keep your existing styles, just add these two:
  actionBtnPrimary: { backgroundColor: COLORS.primary, padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 10, marginBottom: 10 },
  actionBtnPrimaryText: { color: COLORS.white, fontWeight: '800', fontSize: 15 },
  
  // ... all your other styles remain the same
  screen: {flex: 1, backgroundColor: COLORS.background},
  header: {paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12},
  title: {fontSize: 28, fontWeight: '800', color: COLORS.text},
  subtitle: {color: COLORS.textSecondary, fontSize: 13, marginTop: 4},
  summaryRow: {flexDirection: 'row', gap: 8, paddingHorizontal: 20, marginBottom: 14},
  summaryBox: {flex: 1, borderRadius: 12, padding: 10, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border},
  summaryValue: {fontSize: 18, fontWeight: '900', color: COLORS.text},
  summaryLabel: {fontSize: 10, fontWeight: '700', color: COLORS.textSecondary, marginTop: 2},
  filterLabel: {paddingHorizontal: 20, fontSize: 10, fontWeight: '800', color: COLORS.textLight, letterSpacing: 1, marginBottom: 6},
  chipScrollWrapper: {height: 42, marginBottom: 10},
  chipRow: {paddingHorizontal: 20, alignItems: 'center', gap: 8},
  chip: {height: 34, paddingHorizontal: 16, borderRadius: 17, backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.border, justifyContent: 'center'},
  chipActive: {backgroundColor: COLORS.primary, borderColor: COLORS.primary},
  chipText: {fontSize: 12, fontWeight: '700', color: COLORS.textSecondary},
  chipTextActive: {color: COLORS.white},
  grid: {padding: 20, paddingTop: 4, paddingBottom: 40},
  gridRow: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
  seat: {width: '18%', aspectRatio: 1, borderRadius: 12, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', padding: 3, position: 'relative'},
  seatNumber: {fontSize: 12, fontWeight: '900'},
  seatStatus: {fontSize: 8, fontWeight: '700', marginTop: 2},
  iconRow: {flexDirection: 'row', gap: 2, marginTop: 4},
  modalOverlay: {flex: 1, justifyContent: 'flex-end'},
  modalBg: {...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.5)'},
  bottomSheet: {backgroundColor: COLORS.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40},
  sheetHandle: {width: 40, height: 4, backgroundColor: COLORS.border, borderRadius: 2, alignSelf: 'center', marginBottom: 16},
  sheetHeader: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4},
  sheetTitle: {fontSize: 20, fontWeight: '900', color: COLORS.text},
  closeButton: {width: 32, height: 32, borderRadius: 16, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center'},
  closeText: {fontSize: 16, fontWeight: '800', color: COLORS.textSecondary},
  sheetSectionTitle: {fontSize: 12, fontWeight: '800', color: COLORS.textLight, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10, marginTop: 15},
  occupantCard: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#F9FAFB', padding: 12, borderRadius: 10, marginBottom: 8, borderWidth: 1, borderColor: COLORS.border},
  occupantName: {fontSize: 14, fontWeight: '800', color: COLORS.text},
  occupantDetail: {fontSize: 11, color: COLORS.textSecondary, marginTop: 2},
  slotChip: {paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6},
  emptyText: {color: COLORS.textLight, fontSize: 13, fontStyle: 'italic', marginBottom: 15},
  actionGrid: {flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 10},
  actionBtn: {paddingVertical: 12, paddingHorizontal: 16, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.white, minWidth: '30%', alignItems: 'center'},
  actionBtnText: {fontSize: 13, fontWeight: '700', color: COLORS.text},
});

export default SeatsScreen;