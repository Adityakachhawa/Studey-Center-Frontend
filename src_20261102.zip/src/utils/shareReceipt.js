// import {Alert, Linking} from 'react-native';

// const LIBRARY_NAME = 'GYAN GANGA LIBRARY';
// const LIBRARY_ADDRESS = 'Near Canara Bank, Main Road , Gangashahr';
// const LIBRARY_PHONE = '+91 99502 34464';
// const LIBRARY_TIMING = '08:00 AM – 10:00 PM';

// const formatMoney = value => {
//   const number = Number(value || 0);

//   return `₹${number.toLocaleString('en-IN')}`;
// };

// const formatDate = value => {
//   if (!value) return '—';

//   const date = new Date(value);

//   if (isNaN(date.getTime())) return String(value).slice(0, 10);

//   return date.toLocaleDateString('en-IN', {
//     day: '2-digit',
//     month: 'short',
//     year: 'numeric',
//   });
// };

// const buildReceiptMessage = receipt => {
//   return (
//     `*${LIBRARY_NAME}*\n` +
//     `${LIBRARY_ADDRESS}\n` +
//     `--------------------------------\n` +
//     `*PAYMENT RECEIPT*\n` +
//     `Receipt No: ${receipt.receipt_number}\n` +
//     `Payment No: ${receipt.payment_number}\n` +
//     `Date: ${formatDate(receipt.receipt_date)}\n` +
//     `--------------------------------\n` +
//     `Student: ${receipt.full_name}\n` +
//     `Code: ${receipt.student_code}\n` +
//     `--------------------------------\n` +
//     `Amount Paid: *${formatMoney(receipt.amount)}*\n` +
//     `Method: ${receipt.method_name}\n` +
//     `--------------------------------\n` +
//     `Thank you for choosing ${LIBRARY_NAME}.\n` +
//     `Timing: ${LIBRARY_TIMING}\n` +
//     `Contact: ${LIBRARY_PHONE}`
//   );
// };

// export const shareReceiptOnWhatsApp = (receipt, mobileOverride) => {
//   const mobile = mobileOverride || receipt?.mobile;

//   if (!mobile) {
//     Alert.alert(
//       'No mobile number',
//       'This student does not have a mobile number saved.',
//     );

//     return;
//   }

//   const clean = String(mobile).replace(/\D/g, '');

//   const phone = clean.length === 10 ? `91${clean}` : clean;

//   const message = buildReceiptMessage(receipt);

//   const url = `whatsapp://send?phone=${phone}&text=${encodeURIComponent(
//     message,
//   )}`;

//   Linking.canOpenURL(url)
//     .then(supported => {
//       if (supported) {
//         return Linking.openURL(url);
//       }

//       return Linking.openURL(
//         `https://wa.me/${phone}?text=${encodeURIComponent(message)}`,
//       );
//     })
//     .catch(() => {
//       Linking.openURL(
//         `https://wa.me/${phone}?text=${encodeURIComponent(message)}`,
//       ).catch(() =>
//         Alert.alert('Error', 'Could not open WhatsApp.'),
//       );
//     });
// };
import {Alert} from 'react-native';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';
import api from '../api/api'; // 👈 Import your api instance

export const shareReceiptOnWhatsApp = async (receipt) => {
  if (!receipt.payment_id) {
    return Alert.alert('Error', 'Payment ID missing.');
  }

  const phone = `91${receipt.mobile}`;
  
  const message = 
    `*GYAN GANGA LIBRARY*\n` +
    `Receipt: ${receipt.receipt_number}\n` +
    `Amount Paid: *₹${receipt.amount}*\n` +
    `Thank you!`;

  try {
    // 1. Fetch the image from the backend
    const res = await api.get(`/api/receipts/${receipt.payment_id}/image`);
    
    if (res.data?.status?.code !== 200 || !res.data?.data?.image_base64) {
      throw new Error('Could not generate image');
    }

    const base64Data = res.data.data.image_base64.replace('data:image/png;base64,', '');
    
    // 2. Save to cache
    const filePath = `${RNFS.CachesDirectoryPath}/${receipt.receipt_number}.png`;
    await RNFS.writeFile(filePath, base64Data, 'base64');

    // 3. Share via WhatsApp
    await Share.open({
      title: 'Share Receipt',
      message: message,
      url: `file://${filePath}`,
      type: 'image/png',
      social: Share.Social.WHATSAPP,
      whatsAppNumber: phone,
      failOnCancel: false,
    });

  } catch (error) {
    console.log('Share error:', error);
    Alert.alert('Error', 'Could not share image.');
  }
};